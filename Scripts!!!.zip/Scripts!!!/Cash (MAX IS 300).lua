getglobal game
getfield -1 ReplicatedStorage
getfield -1 Pay
getfield -1 FireServer
pushvalue -2
pushstring -amount of money dont remove the "-"
pushstring Buy
pcall 3 1 0
emptystack