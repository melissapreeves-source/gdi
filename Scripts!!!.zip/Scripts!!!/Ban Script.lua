getglobal game
getfield -1 Players
getfield -1 NAMEHERE
getfield -1 leaderstat
getfield -1 Banned
pushstring true
setfield -2 Value
emptystack