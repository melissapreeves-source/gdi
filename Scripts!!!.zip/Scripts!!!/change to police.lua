getglobal game
getfield -1 Workspace
getfield -1 resources
getfield -1 RemoteFunction
getfield -1 InvokeServer
pushvalue -2
pushstring requestTeam
pushstring police
pcall 3 0 0