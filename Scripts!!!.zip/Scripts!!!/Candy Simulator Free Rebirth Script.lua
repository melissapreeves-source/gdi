while true do
wait()
game:GetService("ReplicatedStorage").Events.RebirthEvent:FireServer(1073790)
end