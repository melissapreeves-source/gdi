-- DISCORD: https://discord.gg/mcByeWv
-- Created by Peyton @ V3rmillion
-- https://v3rmillion.net/showthread.php?tid=879260
-- SET SENSITIVITY TO MINIMUM IF HAVING ISSUES
loadstring(game:HttpGet('https://pastebin.com/raw/0X0ecbmH'))()
