_G.running = true


while running do
game.ReplicatedStorage.Input.Lollipop:FireServer()
end