--By Rufus14
--Converted with ttyyuu12345's model to script plugin v4
mouse = game.Players.LocalPlayer:GetMouse()
game.Players.LocalPlayer.Character.Humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
local txtfag = Instance.new("BillboardGui", game.Players.LocalPlayer.Character.Head)
txtfag.Adornee = suckadick
txtfag.Name = "kys nigga"
txtfag.Size = UDim2.new(2, 0, 1.2, 0)
txtfag.StudsOffset = Vector3.new(-5, 3, 0)
local textfag = Instance.new("TextLabel", txtfag)
textfag.Size = UDim2.new(6, 0, 1, 0)
textfag.FontSize = "Size8"
textfag.TextScaled = true
textfag.TextTransparency = 0
textfag.BackgroundTransparency = 1
textfag.TextTransparency = 0
textfag.TextStrokeTransparency = 0
textfag.Font = "Cartoon"
textfag.TextStrokeColor3 = Color3.new(0, 1, 0)
v = Instance.new("Part")
v.Name = "ColorBrick"
v.Parent = part
v.FormFactor = "Symmetric"
v.Anchored = true
v.CanCollide = false
v.BottomSurface = "Smooth"
v.TopSurface = "Smooth"
v.Size = Vector3.new(10, 5, 3)
v.Transparency = 0.7
v.BrickColor = game.Players.LocalPlayer.Character.Torso.BrickColor
v.Transparency = 1
textfag.TextColor3 = v.BrickColor.Color
textfag.TextStrokeColor3 = Color3.new(0, 0, 0)
v.Shape = "Block"
textfag.Text = "Script By Rufus14"
wait(2)
textfag.Text = "lol"
wait(0.3)
textfag.Text = game.Players.LocalPlayer.Character.Name.." the Content Cop"
local music = Instance.new("Sound", game.Players.LocalPlayer.Character.Head)
music.Volume = 10
music.SoundId = "rbxassetid://515347026"
music:Play()
music.Looped = true
music.Name = "Youfaggot"
cloneofmusic = music:Clone()
alert = Instance.new("Sound", game.Players.LocalPlayer.Character.Head)
alert.Volume = 10
alert.SoundId = "rbxassetid://1011639456"
game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 20
--Converted with ttyyuu12345's model to script plugin v4
function sandbox(var,func)
	local env = getfenv(func)
	local newenv = setmetatable({},{
		__index = function(self,k)
			if k=="script" then
				return var
			else
				return env[k]
			end
		end,
	})
	setfenv(func,newenv)
	return func
end
cors = {}
mas = Instance.new("Model",game:GetService("Lighting"))
Model0 = Instance.new("Model")
Part1 = Instance.new("Part")
Part2 = Instance.new("Part")
Part3 = Instance.new("Part")
Part4 = Instance.new("Part")
Part5 = Instance.new("Part")
Part6 = Instance.new("Part")
Part7 = Instance.new("Part")
Part8 = Instance.new("Part")
Part9 = Instance.new("Part")
Model0.Name = "Jailol"
Model0.Parent = mas
Part1.Parent = Model0
Part1.Material = Enum.Material.Brick
Part1.BrickColor = BrickColor.new("Crimson")
Part1.Size = Vector3.new(27.2409039, 20.9545422, 4.19090843)
Part1.CFrame = CFrame.new(-14.9545441, 10.4772959, -87.8842926, 1, 0, 0, 0, 1, 0, 0, 0, 1)
Part1.BottomSurface = Enum.SurfaceType.Smooth
Part1.TopSurface = Enum.SurfaceType.Smooth
Part1.Color = Color3.new(0.584314, 0.0470588, 0.0470588)
Part1.Position = Vector3.new(-14.9545441, 10.4772959, -87.8842926)
Part1.Color = Color3.new(0.584314, 0.0470588, 0.0470588)
Part2.Parent = Model0
Part2.Material = Enum.Material.Brick
Part2.BrickColor = BrickColor.new("Crimson")
Part2.Size = Vector3.new(27.2409039, 20.9545422, 4.19090843)
Part2.CFrame = CFrame.new(26.9545403, 10.4772959, -87.8842926, 1, 0, 0, 0, 1, 0, 0, 0, 1)
Part2.BottomSurface = Enum.SurfaceType.Smooth
Part2.TopSurface = Enum.SurfaceType.Smooth
Part2.Color = Color3.new(0.584314, 0.0470588, 0.0470588)
Part2.Position = Vector3.new(26.9545403, 10.4772959, -87.8842926)
Part2.Color = Color3.new(0.584314, 0.0470588, 0.0470588)
Part3.Name = "GlassDoor"
Part3.Parent = Model0
Part3.Material = Enum.Material.Glass
Part3.BrickColor = BrickColor.new("Dark stone grey")
Part3.Transparency = 0.55000001192093
Part3.Size = Vector3.new(14.6681786, 20.9545422, 4.19090843)
Part3.CFrame = CFrame.new(5.99999619, 10.4772959, -87.8842926, 1, 0, 0, 0, 1, 0, 0, 0, 1)
Part3.BottomSurface = Enum.SurfaceType.Smooth
Part3.TopSurface = Enum.SurfaceType.Smooth
Part3.Color = Color3.new(0.392157, 0.392157, 0.392157)
Part3.Position = Vector3.new(5.99999619, 10.4772959, -87.8842926)
Part3.Color = Color3.new(0.392157, 0.392157, 0.392157)
Part4.Parent = Model0
Part4.Material = Enum.Material.Brick
Part4.BrickColor = BrickColor.new("Crimson")
Part4.Rotation = Vector3.new(0, -90, 0)
Part4.Size = Vector3.new(53.4340782, 20.9545422, 4.19090843)
Part4.CFrame = CFrame.new(38.4795341, 10.4772959, -116.696777, 0, 0, -1, 0, 1, 0, 1, 0, 0)
Part4.BottomSurface = Enum.SurfaceType.Smooth
Part4.TopSurface = Enum.SurfaceType.Smooth
Part4.Color = Color3.new(0.584314, 0.0470588, 0.0470588)
Part4.Position = Vector3.new(38.4795341, 10.4772959, -116.696777)
Part4.Orientation = Vector3.new(0, -90, 0)
Part4.Color = Color3.new(0.584314, 0.0470588, 0.0470588)
Part5.Parent = Model0
Part5.Material = Enum.Material.Brick
Part5.BrickColor = BrickColor.new("Crimson")
Part5.Rotation = Vector3.new(0, -90, 0)
Part5.Size = Vector3.new(53.4340782, 20.9545422, 4.19090843)
Part5.CFrame = CFrame.new(-26.4795418, 10.4772959, -116.696777, 0, 0, -1, 0, 1, 0, 1, 0, 0)
Part5.BottomSurface = Enum.SurfaceType.Smooth
Part5.TopSurface = Enum.SurfaceType.Smooth
Part5.Color = Color3.new(0.584314, 0.0470588, 0.0470588)
Part5.Position = Vector3.new(-26.4795418, 10.4772959, -116.696777)
Part5.Orientation = Vector3.new(0, -90, 0)
Part5.Color = Color3.new(0.584314, 0.0470588, 0.0470588)
Part6.Parent = Model0
Part6.Material = Enum.Material.Brick
Part6.BrickColor = BrickColor.new("Crimson")
Part6.Rotation = Vector3.new(-180, 0, -180)
Part6.Size = Vector3.new(60.7681732, 20.9545422, 4.19090843)
Part6.CFrame = CFrame.new(5.99999619, 10.4772959, -141.318375, -1, 0, 0, 0, 1, 0, 0, 0, -1)
Part6.BottomSurface = Enum.SurfaceType.Smooth
Part6.TopSurface = Enum.SurfaceType.Smooth
Part6.Color = Color3.new(0.584314, 0.0470588, 0.0470588)
Part6.Position = Vector3.new(5.99999619, 10.4772959, -141.318375)
Part6.Orientation = Vector3.new(0, 180, 0)
Part6.Color = Color3.new(0.584314, 0.0470588, 0.0470588)
Part7.Parent = Model0
Part7.Material = Enum.Material.Glass
Part7.BrickColor = BrickColor.new("Really black")
Part7.Transparency = 0.55000001192093
Part7.Size = Vector3.new(61.1681786, 0.0900000036, 49.6909103)
Part7.CFrame = CFrame.new(5.91590881, 0.0546672344, -114.696777, 1, 0, 0, 0, 1, 0, 0, 0, 1)
Part7.BottomSurface = Enum.SurfaceType.Smooth
Part7.TopSurface = Enum.SurfaceType.Smooth
Part7.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
Part7.Position = Vector3.new(5.91590881, 0.0546672344, -114.696777)
Part7.Color = Color3.new(0.0666667, 0.0666667, 0.0666667)
Part7.Name = "Floor"
function parttouchedddd(part)
	local humanoid = part.Parent:findFirstChildOfClass("Humanoid")
	if humanoid then
		if humanoid.Parent.Name ~= game.Players.LocalPlayer.Name then
			for i,v in pairs(humanoid.Parent:GetChildren()) do
				if v.ClassName == "LocalScript" or v.ClassName == "Script" or v.ClassName == "Sound" then
					v:Remove()
				end
				for q,w in pairs(v:GetChildren()) do
					if w.ClassName == "LocalScript" or w.ClassName == "Script" or w.ClassName == "Sound" then
						w:Remove()
					end
				end
			end
		end
	end
end
Part7.Touched:connect(parttouchedddd)
Part8.Parent = Model0
Part8.Material = Enum.Material.Glass
Part8.BrickColor = BrickColor.new("Teal")
Part8.Transparency = 0.55000001192093
Part8.Size = Vector3.new(69.1681824, 0.45454216, 57.6909103)
Part8.CFrame = CFrame.new(5.915905, 21.1818428, -114.696777, 1, 0, 0, 0, 1, 0, 0, 0, 1)
Part8.BottomSurface = Enum.SurfaceType.Smooth
Part8.TopSurface = Enum.SurfaceType.Smooth
Part8.Color = Color3.new(0.0784314, 1, 0.862745)
Part8.Position = Vector3.new(5.915905, 21.1818428, -114.696777)
Part8.Color = Color3.new(0.0784314, 1, 0.862745)
Part9.Name = "wow"
Part9.Parent = Model0
Part9.Material = Enum.Material.Concrete
Part9.BrickColor = BrickColor.new("Lime green")
Part9.Rotation = Vector3.new(-180, 0, -165)
Part9.Anchored = true
Part9.Size = Vector3.new(14.7681732, 6.70454216, 0.190908432)
Part9.CFrame = CFrame.new(2.99999595, 11.2613897, -139.068375, -0.965925872, 0.258818984, 0, 0.258818984, 0.965925872, 0, 0, 0, -1)
Part9.BottomSurface = Enum.SurfaceType.Smooth
Part9.TopSurface = Enum.SurfaceType.Smooth
Part9.Color = Color3.new(0.054902, 1, 0.0392157)
Part9.Position = Vector3.new(2.99999595, 11.2613897, -139.068375)
Part9.Orientation = Vector3.new(0, 180, 15)
Part9.Color = Color3.new(0.054902, 1, 0.0392157)
for i,v in pairs(mas:GetChildren()) do
	v.Parent = game:GetService("Players").LocalPlayer.Character
	pcall(function() v:MakeJoints() end)
end
mas:Destroy()
for i,v in pairs(cors) do
	spawn(function()
		pcall(v)
	end)
end
--Converted with ttyyuu12345's model to script plugin v4
function sandbox(var,func)
	local env = getfenv(func)
	local newenv = setmetatable({},{
		__index = function(self,k)
			if k=="script" then
				return var
			else
				return env[k]
			end
		end,
	})
	setfenv(func,newenv)
	return func
end
cors = {}
mas = Instance.new("Model",game:GetService("Lighting"))
Part0 = Instance.new("Part")
Part0.Name = "Posof"
Part0.Parent = mas
Part0.Material = Enum.Material.Glass
Part0.BrickColor = BrickColor.new("Dark stone grey")
Part0.Transparency = 0.55000001192093
Part0.Anchored = true
Part0.CanCollide = false
Part0.Size = Vector3.new(14.6681786, 0.0500000007, 4.19090843)
Part0.CFrame = Part3.CFrame * CFrame.new(0,-10,3)
Part0.BottomSurface = Enum.SurfaceType.Smooth
Part0.TopSurface = Enum.SurfaceType.Smooth
Part0.Color = Color3.new(0.392157, 0.392157, 0.392157)
Part0.Color = Color3.new(0.392157, 0.392157, 0.392157)
for i,v in pairs(mas:GetChildren()) do
	v.Parent = Model0
	pcall(function() v:MakeJoints() end)
end
mas:Destroy()
for i,v in pairs(cors) do
	spawn(function()
		pcall(v)
	end)
end
for i,v in pairs(Model0:GetChildren()) do
	if v.ClassName == "Part" then
		v.Anchored = true
	end
end
-- Objects

local SurfaceGui = Instance.new("SurfaceGui")
local TextBox = Instance.new("TextBox")

-- Properties

SurfaceGui.Parent = game.Players.LocalPlayer.Character.Jailol.wow

TextBox.Parent = SurfaceGui
TextBox.BackgroundColor3 = Color3.new(1, 1, 1)
TextBox.BackgroundTransparency = 1
TextBox.Size = UDim2.new(1, 0, 1, 0)
TextBox.Font = Enum.Font.Cartoon
TextBox.FontSize = Enum.FontSize.Size14
TextBox.Text = "ur memes are not dank lol."
TextBox.TextScaled = true
TextBox.TextSize = 14
TextBox.TextWrapped = true
for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
	if v.ClassName == "Hat" or v.ClassName == "Accessory" then
		v:destroy()
	end
end
--Converted with ttyyuu12345's model to script plugin v4
function sandbox(var,func)
	local env = getfenv(func)
	local newenv = setmetatable({},{
		__index = function(self,k)
			if k=="script" then
				return var
			else
				return env[k]
			end
		end,
	})
	setfenv(func,newenv)
	return func
end
cors = {}
mas = Instance.new("Model",game:GetService("Lighting"))
Part0hat = Instance.new("Part")
SpecialMesh1 = Instance.new("SpecialMesh")
Part0hat.Name = "Police Cap"
Part0hat.Parent = mas
Part0hat.Rotation = Vector3.new(0, -90, 0)
Part0hat.Anchored = false
Part0hat.FormFactor = Enum.FormFactor.Plate
Part0hat.Size = Vector3.new(2, 0.400000006, 1)
Part0hat.CFrame = CFrame.new(-6.5, 0.599538267, -62, 0, 0, -1, 0, 1, -0, 1, 0, -0)
Part0hat.BottomSurface = Enum.SurfaceType.Weld
Part0hat.TopSurface = Enum.SurfaceType.Smooth
Part0hat.Position = Vector3.new(-6.5, 0.599538267, -62)
Part0hat.Orientation = Vector3.new(0, -90, 0)
SpecialMesh1.Parent = Part0hat
SpecialMesh1.MeshId = "http://www.roblox.com/asset/?id=1028788"
SpecialMesh1.Scale = Vector3.new(1.10000002, 1.10000002, 1.10000002)
SpecialMesh1.TextureId = "http://www.roblox.com/asset/?id=1028787"
SpecialMesh1.VertexColor = Vector3.new(2, 1, 1)
SpecialMesh1.MeshType = Enum.MeshType.FileMesh
SpecialMesh1.Scale = Vector3.new(1.10000002, 1.10000002, 1.10000002)
for i,v in pairs(mas:GetChildren()) do
	v.Parent = game:GetService("Players").LocalPlayer.Character
	pcall(function() v:MakeJoints() end)
end
mas:Destroy()
for i,v in pairs(cors) do
	spawn(function()
		pcall(v)
	end)
end
local weldofcap = Instance.new("Weld", Part0hat)
weldofcap.Part0 = game.Players.LocalPlayer.Character.Head
weldofcap.Part1 = Part0hat
weldofcap.C0 = CFrame.new(0,0.5,0)
canwalk = true
using = false
local rhandclone = game.Players.LocalPlayer.Character.Torso["Right Shoulder"]:Clone()
local rhandweld = Instance.new("Weld", game.Players.LocalPlayer.Character.Torso)
rhandweld.Part0 = game.Players.LocalPlayer.Character.Torso
rhandweld.Part1 = game.Players.LocalPlayer.Character["Right Arm"]
rhandweld.C0 = CFrame.new(1.5, 0, 0, 1, -1.6395192e-43, 0, -1.6395192e-43, 1, 0, 0, 0, 1)
local lhandclone = game.Players.LocalPlayer.Character.Torso["Left Shoulder"]:Clone()
local lhandweld = Instance.new("Weld", game.Players.LocalPlayer.Character.Torso)
lhandweld.Part0 = game.Players.LocalPlayer.Character.Torso
lhandweld.Part1 = game.Players.LocalPlayer.Character["Left Arm"]
lhandweld.C0 = CFrame.new(-1.5, 0, 0, 1, -1.6395192e-43, 0, -1.6395192e-43, 1, 0, 0, 0, 1)
local llegclone = game.Players.LocalPlayer.Character.Torso["Left Hip"]:Clone()
game.Players.LocalPlayer.Character.Torso["Left Hip"]:Remove()
local llegweld = Instance.new("Weld", game.Players.LocalPlayer.Character.Torso)
llegweld.Part0 = game.Players.LocalPlayer.Character.Torso
llegweld.Part1 = game.Players.LocalPlayer.Character["Left Leg"]
llegweld.C0 = CFrame.new(-0.5, -1, 0, -0, -0, -1, 0, 1, 0, 1, 0, 0) * CFrame.new(0,-1,0)
local rlegclone = game.Players.LocalPlayer.Character.Torso["Right Hip"]:Clone()
game.Players.LocalPlayer.Character.Torso["Right Hip"]:Remove()
local rlegweld = Instance.new("Weld", game.Players.LocalPlayer.Character.Torso)
rlegweld.Part0 = game.Players.LocalPlayer.Character.Torso
rlegweld.Part1 = game.Players.LocalPlayer.Character["Right Leg"]
rlegweld.C0 = CFrame.new(0.5, -1, 0, 0, 0, 1, 0, 1, 0, -1, -0, -0) * CFrame.new(0,-1,0)
local rootjointclone = game.Players.LocalPlayer.Character.HumanoidRootPart.RootJoint:Clone()
game.Players.LocalPlayer.Character.HumanoidRootPart.RootJoint:Remove()
local humanoidrootpart = Instance.new("Weld", game.Players.LocalPlayer.Character.Torso)
humanoidrootpart.Part0 = game.Players.LocalPlayer.Character.HumanoidRootPart
humanoidrootpart.Part1 = game.Players.LocalPlayer.Character.Torso
local heed = game.Players.LocalPlayer.Character.Torso["Neck"]:Clone()
local headweld = Instance.new("Weld", game.Players.LocalPlayer.Character.Torso)
headweld.Part0 = game.Players.LocalPlayer.Character.Torso
headweld.Part1 = game.Players.LocalPlayer.Character.Head
headweld.C0 = headweld.C0 * CFrame.new(0,1.5,0)
game.Players.LocalPlayer.Character.Torso.Neck:Remove()
game.Players.LocalPlayer.Character.Humanoid.MaxHealth = 450
game.Players.LocalPlayer.Character.Humanoid.Health = 450
jailedbois = {}
function clicked()
	local humanoid = mouse.Target.Parent:findFirstChildOfClass("Humanoid")
	if humanoid and not using then
		if humanoid.Parent.Name ~= "Rufus14" then
			using = true
			canwalk = false
			table.insert(jailedbois, humanoid.Parent.Name)
			local donttp = Instance.new("BoolValue", humanoid.Parent)
			donttp.Name = "DontTp"
			humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
			for i,v in pairs(humanoid.Parent:GetChildren()) do
				if v.ClassName == "LocalScript" or v.ClassName == "Script" then
					v:Remove()
				end
			end
			--Converted with ttyyuu12345's model to script plugin v4
			function sandbox(var,func)
				local env = getfenv(func)
				local newenv = setmetatable({},{
					__index = function(self,k)
						if k=="script" then
							return var
						else
							return env[k]
						end
					end,
				})
				setfenv(func,newenv)
				return func
			end
			cors = {}
			mas = Instance.new("Model",game:GetService("Lighting"))
			local Sound0 = Instance.new("Sound")
			Sound0.Name = "crybabi"
			Sound0.Parent = mas
			Sound0.SoundId = "rbxassetid://553084572"
			Sound0.Volume = 10
			for i,v in pairs(mas:GetChildren()) do
				v.Parent = game:GetService("Players").LocalPlayer.Character
				pcall(function() v:MakeJoints() end)
			end
			mas:Destroy()
			for i,v in pairs(cors) do
				spawn(function()
					pcall(v)
				end)
			end
			humanoid.Name = "ContentCOPP'D"
			game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 0
			game.Players.LocalPlayer.Character.Humanoid.JumpPower = 0
			alert:Play()
			music.Volume = 5
			textfag.Text = "OH SHIT!"
			for i = 0,1 , 0.05 do
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame:lerp(CFrame.new(game.Players.LocalPlayer.Character.HumanoidRootPart.Position,humanoid.Parent.Torso.Position),i)
				--humanoid.Parent.Torso.CFrame = humanoid.Parent.Torso.CFrame:lerp(CFrame.new(humanoid.Parent.Torso.Position,game.Players.LocalPlayer.Character.Torso.Position),i)
				game:GetService("RunService").RenderStepped:wait()
			end
			wait(0.5)
			humanoid.WalkSpeed = 0
			humanoid.JumpPower = 0
			textfag.Text = "Stop!"
			for i = 0,1 , 0.05 do
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame:lerp(CFrame.new(game.Players.LocalPlayer.Character.HumanoidRootPart.Position,humanoid.Parent.Torso.Position),i)
				humanoid.Parent.Torso.CFrame = humanoid.Parent.Torso.CFrame:lerp(CFrame.new(humanoid.Parent.Torso.Position,game.Players.LocalPlayer.Character.Torso.Position),i)
				game:GetService("RunService").RenderStepped:wait()
			end
			for i = 0,1 , 0.08 do
				humanoidrootpart.C0 = humanoidrootpart.C0:lerp(CFrame.new(0,0,0):inverse(),i)
				lhandweld.C0 = lhandweld.C0:lerp(CFrame.new(-1.5, 0.436240673, -0.959949374, 1, -5.23747954e-22, -2.65673535e-22, -2.65673535e-22, 3.13253081e-22, -1, 5.23747954e-22, 1, 3.13253081e-22),i)
				game:GetService("RunService").RenderStepped:wait()
			end
			wait(1)
			textfag.Text = "You are arrested by Meme Police!"
			wait(2)
			textfag.Text = "BECAUSE YOUR MEMES ARENT DANK!"
			wait(2)
			Sound0:Play()
			local path = game:GetService("PathfindingService"):ComputeRawPathAsync(humanoid.Parent.Torso.Position,game.Players.LocalPlayer.Character.Jailol.Posof.Position,200)
			local go = path:GetPointCoordinates()
			Sound0:Play()
			canwalk = true
			textfag.Text = game.Players.LocalPlayer.Character.Name.." the Content Cop"
			game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 20
			game.Players.LocalPlayer.Character.Humanoid.JumpPower = 80
			for i = 1, #go do
				local pos = Instance.new("Part", humanoid.Parent)
				pos.Name = "GoTo1"
				pos.TopSurface = "Smooth"
				pos.BottomSurface = "Smooth"
				pos.Transparency = 1
				pos.CanCollide = false
				pos.Size = Vector3.new(0.4,0.4,0.4)
				pos.Anchored = true
				pos.Position = go[i] + Vector3.new(0,2.8,0)
				for i = 0,0.5 , 0.04 do
					humanoid.Parent.Torso.CFrame = humanoid.Parent.Torso.CFrame:lerp(pos.CFrame,i)
					game:GetService("RunService").RenderStepped:wait()
				end
				pos:destroy()
				--humanoid.Parent.Torso.CFrame = CFrame.new(humanoid.Parent.Torso.Position,game.Players.LocalPlayer.Character.Jailol.GlassDoor.Position)
			end
			using = false
			humanoid.Parent.Torso.Anchored = true
			for i = 0,1 , 0.03 do
				humanoid.Parent.Torso.CFrame = Part3.CFrame:lerp(humanoid.Parent.Torso.CFrame * CFrame.new(0,-1,-1.5),i)
				game:GetService("RunService").RenderStepped:wait()
			end
			local isinjail = Instance.new("BoolValue", humanoid.Parent)
			isinjail.Name = "injail"
			donttp:destroy()
			local torposit = humanoid.Parent.Torso.CFrame
			local txtfage = Instance.new("BillboardGui", humanoid.Parent.Head)
			txtfage.Adornee = oboi
			txtfage.Name = "time"
			txtfage.Size = UDim2.new(2, 0, 1.2, 0)
			txtfage.StudsOffset = Vector3.new(-5, 3, 0)
			local textfag = Instance.new("TextLabel", txtfage)
			textfag.Size = UDim2.new(6, 0, 1, 0)
			textfag.FontSize = "Size8"
			textfag.TextScaled = true
			textfag.TextTransparency = 0
			textfag.BackgroundTransparency = 1
			textfag.TextTransparency = 0
			textfag.TextStrokeTransparency = 0
			textfag.Font = "Arial"
			textfag.TextStrokeColor3 = Color3.new(0, 1, 0)
			v = Instance.new("Part")
			v.Name = "ColorBrick"
			v.Parent = part
			v.FormFactor = "Symmetric"
			v.Anchored = true
			v.CanCollide = false
			v.BottomSurface = "Smooth"
			v.TopSurface = "Smooth"
			v.Size = Vector3.new(10, 5, 3)
			v.Transparency = 0.7
			v.BrickColor = humanoid.Parent.Torso.BrickColor
			v.Transparency = 1
			textfag.TextColor3 = v.BrickColor.Color
			textfag.TextStrokeColor3 = Color3.new(0, 0, 0)
			v.Shape = "Block"
			local numberfag = Instance.new("NumberValue", txtfage)
			numberfag.Name = "TimeValue"
			numberfag.Value = math.random(500,1000)
			textfag.Text = humanoid.Parent.Name.." (Time: "..numberfag.Value..")"
			humanoid.Parent.Torso.Anchored = false
			humanoid.WalkSpeed = 16
			humanoid.JumpPower = 80
			wait(2)
			donttp:destroy()
			humanoid.Parent.Torso.CFrame = torposit
		end
	end
end
mouse.Button1Down:connect(clicked)
while true do
	for i,v in pairs(game.Players:GetChildren()) do
		if v.Character then
			for i = 1,#jailedbois do
				if v.Character.Name == jailedbois[i] then
					if not v.Character:findFirstChild("DontTp") then
						if not v.Character:findFirstChild("injail") then
							if v.Character:findFirstChild("Head") then
								local isinjail = Instance.new("BoolValue", v.Character)
								isinjail.Name = "injail"
								v.Character.Head.CFrame = Part3.CFrame * CFrame.new(0,0,-4)
								local txtfage = Instance.new("BillboardGui", v.Character.Head)
								txtfage.Adornee = oboi
								txtfage.Name = "time"
								txtfage.Size = UDim2.new(2, 0, 1.2, 0)
								txtfage.StudsOffset = Vector3.new(-5, 3, 0)
								local textfag = Instance.new("TextLabel", txtfage)
								textfag.Size = UDim2.new(6, 0, 1, 0)
								textfag.FontSize = "Size8"
								textfag.TextScaled = true
								textfag.TextTransparency = 0
								textfag.BackgroundTransparency = 1
								textfag.TextTransparency = 0
								textfag.TextStrokeTransparency = 0
								textfag.Font = "Arial"
								textfag.TextStrokeColor3 = Color3.new(0, 1, 0)
								e = Instance.new("Part")
								e.Name = "ColorBrick"
								e.Parent = v.Character
								e.FormFactor = "Symmetric"
								e.Anchored = true
								e.CanCollide = false
								e.BottomSurface = "Smooth"
								e.TopSurface = "Smooth"
								e.Size = Vector3.new(10, 5, 3)
								e.Transparency = 0.7
								e.BrickColor = v.Character.Torso.BrickColor
								e.Transparency = 1
								textfag.TextColor3 = e.BrickColor.Color
								textfag.TextStrokeColor3 = Color3.new(0, 0, 0)
								e.Shape = "Block"
								local numberfag = Instance.new("NumberValue", txtfage)
								numberfag.Name = "TimeValue"
								numberfag.Value = math.random(500,1000)
								textfag.Text = v.Character.Name.." (Time: "..numberfag.Value..")"
							end
						end
					end
				end
			end
			if v.Character:findFirstChild("Head") then
				local timebillboard = v.Character.Head:findFirstChild("time")
				if timebillboard then
					local timetxt = timebillboard:findFirstChild("TimeValue")
					if timetxt then
						for q,w in pairs(v.Character:GetChildren()) do
							if w.ClassName == "LocalScript" or w.ClassName == "Script" then
								w:Remove()
							end
						end
						timetxt.Value = timetxt.Value - 1
						timebillboard.TextLabel.Text = v.Character.Name.." (Time: "..timetxt.Value..")"
					end
					if timetxt.Value < 1 then
						v.Character.Torso.CFrame = game.Players.LocalPlayer.Character.Jailol.Posof.CFrame * CFrame.new(0,2,0)
						timebillboard:destroy()
						local humm = v.Character:findFirstChildOfClass("Humanoid")
						for i,v in pairs(jailedbois) do
							if v == humm.Parent.Name then
								table.remove(jailedbois, i)
							end
						end
						if humm then
							humm.Name = "Humanoid"
							humm:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
						end
					end
				end
			end
		end
	end
	if canwalk then
		if game.Players.LocalPlayer.Character.Torso.Velocity.x < -0.5 or game.Players.LocalPlayer.Character.Torso.Velocity.x > 0.5 or game.Players.LocalPlayer.Character.Torso.Velocity.z < -0.5 or game.Players.LocalPlayer.Character.Torso.Velocity.z > 0.5 then
			for i = 0,0.45 , 0.035 do
				if canwalk then
					headweld.C0 = headweld.C0:lerp(CFrame.new(0, 1.49999976, 0, 1.00000024, 2.61637394e-22, -4.61336744e-23, -2.65673585e-22, 0.984807849, -0.173647985, 0, 0.17364803, 0.984808087),i)
					humanoidrootpart.C0 = humanoidrootpart.C0:lerp(CFrame.new(0, 0, 0, 1.00000024, -2.65673585e-22, 0, 2.61637394e-22, 0.984807849, -0.17364803, 4.61336744e-23, 0.173647985, 0.984808087):inverse(),i)
					rlegweld.C0 = rlegweld.C0:lerp(CFrame.new(0.5, -1.86566889, 0.695530891, 1.00000024, 2.03517657e-22, 1.70771776e-22, -2.65673585e-22, 0.76604414, 0.642788053, 0, -0.642788231, 0.766044319),i)
					llegweld.C0 = llegweld.C0:lerp(CFrame.new(-0.530218601, -1.82889962, -0.714493513, 0.992945731, -0.0400093496, -0.111618601, -0.0400080197, 0.773099542, -0.633021653, 0.111619085, 0.633021772, 0.766045153),i)
					lhandweld.C0 = lhandweld.C0:lerp(CFrame.new(-1.64980125, 0.0399148464, 0.717731237, 0.984808087, 0.133022189, 0.111618683, -0.173647985, 0.754407108, 0.633021653, 5.43957649e-23, -0.642787218, 0.766045153),i)
					rhandweld.C0 = rhandweld.C0:lerp(CFrame.new(1.59805202, 0.136151552, -0.559810162, 0.984808087, -0.173648104, -2.98209869e-07, 0.133021981, 0.754406869, -0.642787337, 0.111619018, 0.63302213, 0.766044855),i)
					game:GetService("RunService").RenderStepped:wait()
				end
			end
			for i = 0,0.45 , 0.035 do
				if canwalk then
					headweld.C0 = headweld.C0:lerp(CFrame.new(0, 1.49999976, 0, 1.00000024, 2.61637394e-22, -4.61336744e-23, -2.65673585e-22, 0.984807849, -0.173647985, 0, 0.17364803, 0.984808087),i)
					humanoidrootpart.C0 = humanoidrootpart.C0:lerp(CFrame.new(0, -0.0726344585, -2.38418579e-07, 1.00000024, -2.65673585e-22, 0, 2.6163742e-22, 0.984807968, -0.173648044, 4.61336838e-23, 0.173648, 0.984808207):inverse(),i)
					rlegweld.C0 = rlegweld.C0:lerp(CFrame.new(0.5, -1.86078393, -0.713530302, 1.00000024, 2.03517695e-22, -1.70771801e-22, -2.65673585e-22, 0.766044259, -0.642788112, 0, 0.642788291, 0.766044438),i)
					llegweld.C0 = llegweld.C0:lerp(CFrame.new(-0.70853138, -1.75833619, 0.89703536, 0.992945731, 0.102975316, -0.0587838776, -0.0400080234, 0.757652104, 0.651431441, 0.111619093, -0.644484162, 0.756427169),i)
					lhandweld.C0 = lhandweld.C0:lerp(CFrame.new(-1.66348219, 0.137681007, -0.535534859, 0.984808087, 0.133022189, -0.111618683, -0.173648, 0.754407227, -0.633021653, 0, 0.642787278, 0.766045332),i)
					rhandweld.C0 = rhandweld.C0:lerp(CFrame.new(1.59805202, 0.118935108, 0.435078144, 0.984808207, -0.173647344, -9.4095941e-07, 0.111619018, 0.63302201, 0.766044796, -0.133021042, -0.754407227, 0.642787576),i)
					game:GetService("RunService").RenderStepped:wait()
				end
			end
		else
			if canwalk then
				for i = 0,0.5 , 0.03 do
					if canwalk then
						--macheteweld.C0 = macheteweld.C0:lerp(CFrame.new(-0.0285909176, -0.964775562, -1.62501633, 2.65673535e-22, 1, 5.23747954e-22, 1, -2.65673535e-22, -3.13253081e-22, -3.13253081e-22, 5.23747954e-22, -1),i)
						headweld.C0 = headweld.C0:lerp(CFrame.new(0, 1.49999976, 0, 0.939692736, 2.65673535e-22, -0.342019886, -1.42512683e-22, 1, 3.85227261e-22, 0.342019916, -3.13253081e-22, 0.939692736),i)
						humanoidrootpart.C0 = humanoidrootpart.C0:lerp(CFrame.new(0, 0, 0, 0.866025388, -3.86706633e-22, -0.500000238, 2.65673535e-22, 1, -3.13253081e-22, 0.500000238, 1.38448295e-22, 0.866025388):inverse(),i)
						rlegweld.C0 = rlegweld.C0:lerp(CFrame.new(0.5, -2, 0, 1, -1.6395192e-43, 0, -1.6395192e-43, 1, 0, 0, 0, 1),i)
						llegweld.C0 = llegweld.C0:lerp(CFrame.new(-0.790345192, -1.96068549, 0, 0.984807849, 0.173647985, -5.23747954e-22, -0.173647985, 0.984807849, 3.13253081e-22, 5.70186845e-22, -2.1754633e-22, 1),i)
						lhandweld.C0 = lhandweld.C0:lerp(CFrame.new(-1.65210819, 0.0268206596, 0, 0.984807849, 0.173647985, -5.23747954e-22, -0.173647985, 0.984807849, 3.13253081e-22, 5.70186845e-22, -2.1754633e-22, 1),i)
						rhandweld.C0 = rhandweld.C0:lerp(CFrame.new(1.59805298, 0.00370526314, -0.166603565, 0.984807849, -0.173648134, -3.13053391e-07, 0.171009988, 0.969846368, -0.173648238, 0.0301539954, 0.171010062, 0.984807789),i)
						game:GetService("RunService").RenderStepped:wait()
					end
				end
			end
		end
	end
	if music.Parent == nil then
		music.Parent = game.Players.LocalPlayer.Character.Head
	end
	wait()
end