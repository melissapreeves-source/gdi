getglobal game
getfield -1 ReplicatedStorage
getfield -1 YourNameHereMembership
pushstring Admin
setfield -2 Value