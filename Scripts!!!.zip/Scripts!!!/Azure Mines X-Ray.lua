--Azure Mines XRay Script
--By 3dsboy08

loadstring(game:GetObjects("rbxassetid://500383547")[1].Source)()