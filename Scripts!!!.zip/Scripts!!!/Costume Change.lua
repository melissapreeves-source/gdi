NOTE: YOU NEED RESET IF U WANT CHANGE YOUR COSTUME
NOTE: YOU NEED RESET IF U WANT CHANGE YOUR COSTUME


Custom Costumes:

getglobal game
getfield -1 Players
getfield -1 NAME HERE
getfield -1 Data
getfield -1 cBody
pushnumber Number Here
setfield -2 Value



Costumes:

Creator Clothes:29
Peterme:21
Kiriakashi:22
Beerus:50



Race KaioShin (God):

getglobal game
getfield -1 Players
getfield -1 Name Here
getfield -1 Data
getfield -1 cRace
pushnumber 10
setfield -2 Value
