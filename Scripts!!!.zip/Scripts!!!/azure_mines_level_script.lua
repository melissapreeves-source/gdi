getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Level
pushnumber 11
setfield -2 Value
