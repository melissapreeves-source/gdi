getglobal game
getfield -1 ReplicatedStorage
getfield -1 Connection
getfield -1 InvokeServer
pushvalue -2
pushnumber 82
pushnumber WALLPAPERIDHERE
pushnumber 1
pcall 4 0 0

------ID LIST------
https://pastebin.com/9wsuSFe6