while true do
local tbl_main = 
{
}
game:GetService("ReplicatedStorage").Input.Lollipop:FireServer(unpack(tbl_main))
wait(1)
end