-- Farewell Infortality.
-- Version: 2.82
-- Instances:
local Shitbabiesmustdie = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local BabyFucker = Instance.new("TextLabel")
local KillBabies = Instance.new("TextButton")
local Inf = Instance.new("TextButton")
local Info = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local AF = Instance.new("TextButton")
local Inf_2 = Instance.new("TextButton")
local Info2 = Instance.new("Frame")
local TextLabel_2 = Instance.new("TextLabel")
local join = Instance.new("TextButton")
--Properties:
Shitbabiesmustdie.Name = "Shit babies must die"
Shitbabiesmustdie.Parent = game.CoreGui
Shitbabiesmustdie.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = Shitbabiesmustdie
Frame.BackgroundColor3 = Color3.new(0, 0.631373, 1)
Frame.BorderColor3 = Color3.new(0, 0.529412, 0.835294)
Frame.BorderSizePixel = 5
Frame.Position = UDim2.new(0, 428, 0, 186)
Frame.Size = UDim2.new(0, 199, 0, 299)

BabyFucker.Name = "BabyFucker"
BabyFucker.Parent = Frame
BabyFucker.BackgroundColor3 = Color3.new(1, 1, 1)
BabyFucker.BackgroundTransparency = 1
BabyFucker.Size = UDim2.new(0, 199, 0, 50)
BabyFucker.Font = Enum.Font.Cartoon
BabyFucker.Text = "Baby Fucker"
BabyFucker.TextColor3 = Color3.new(0, 0.368627, 0.580392)
BabyFucker.TextScaled = true
BabyFucker.TextSize = 14
BabyFucker.TextWrapped = true

KillBabies.Name = "KillBabies"
KillBabies.Parent = Frame
KillBabies.BackgroundColor3 = Color3.new(0, 0.368627, 0.580392)
KillBabies.BorderSizePixel = 0
KillBabies.Position = UDim2.new(0, 0, 0, 74)
KillBabies.Size = UDim2.new(0, 66, 0, 37)
KillBabies.Font = Enum.Font.Cartoon
KillBabies.Text = "Kill all babies"
KillBabies.TextColor3 = Color3.new(0, 0.65098, 1)
KillBabies.TextScaled = true
KillBabies.TextSize = 14
KillBabies.TextWrapped = true

Inf.Name = "Inf"
Inf.Parent = Frame
Inf.BackgroundColor3 = Color3.new(0, 0.368627, 0.580392)
Inf.BorderSizePixel = 0
Inf.Position = UDim2.new(0, 0, 0, 112)
Inf.Size = UDim2.new(0, 28, 0, 30)
Inf.Font = Enum.Font.Cartoon
Inf.Text = "<"
Inf.TextColor3 = Color3.new(0, 0.65098, 1)
Inf.TextScaled = true
Inf.TextSize = 14
Inf.TextWrapped = true

Info.Name = "Info"
Info.Parent = Frame
Info.BackgroundColor3 = Color3.new(0, 0.631373, 1)
Info.BorderColor3 = Color3.new(0, 0.529412, 0.835294)
Info.BorderSizePixel = 5
Info.Position = UDim2.new(0, -239, 0, 0)
Info.Size = UDim2.new(0, 199, 0, 300)
Info.Visible = false

TextLabel.Parent = Info
TextLabel.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel.BackgroundTransparency = 1
TextLabel.Size = UDim2.new(0, 199, 0, 300)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.Text = "Equip your attack [ press 1 ] then press 'Kill all babies' after that just start swinging at all those little cunts. if you die re'press 'Kill all babies' enjoy ( script made by Not a Trap#6258 ) "
TextLabel.TextColor3 = Color3.new(0, 0.415686, 0.654902)
TextLabel.TextScaled = true
TextLabel.TextSize = 14
TextLabel.TextWrapped = true
TextLabel.TextXAlignment = Enum.TextXAlignment.Left
TextLabel.TextYAlignment = Enum.TextYAlignment.Top

AF.Name = "AF"
AF.Parent = Frame
AF.BackgroundColor3 = Color3.new(0, 0.368627, 0.580392)
AF.BorderSizePixel = 0
AF.Position = UDim2.new(0, 132, 0, 74)
AF.Size = UDim2.new(0, 66, 0, 37)
AF.Font = Enum.Font.Cartoon
AF.Text = "Auto-Farm"
AF.TextColor3 = Color3.new(0, 0.65098, 1)
AF.TextScaled = true
AF.TextSize = 14
AF.TextWrapped = true

Inf_2.Name = "Inf"
Inf_2.Parent = Frame
Inf_2.BackgroundColor3 = Color3.new(0, 0.368627, 0.580392)
Inf_2.BorderSizePixel = 0
Inf_2.Position = UDim2.new(0, 170, 0, 112)
Inf_2.Size = UDim2.new(0, 28, 0, 30)
Inf_2.Font = Enum.Font.Cartoon
Inf_2.Text = ">"
Inf_2.TextColor3 = Color3.new(0, 0.65098, 1)
Inf_2.TextScaled = true
Inf_2.TextSize = 14
Inf_2.TextWrapped = true

Info2.Name = "Info2"
Info2.Parent = Frame
Info2.BackgroundColor3 = Color3.new(0, 0.631373, 1)
Info2.BorderColor3 = Color3.new(0, 0.529412, 0.835294)
Info2.BorderSizePixel = 5
Info2.Position = UDim2.new(0, 239, 0, 0)
Info2.Size = UDim2.new(0, 199, 0, 300)
Info2.Visible = false

TextLabel_2.Parent = Info2
TextLabel_2.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_2.BackgroundTransparency = 1
TextLabel_2.Size = UDim2.new(0, 199, 0, 300)
TextLabel_2.Font = Enum.Font.SourceSans
TextLabel_2.Text = "Equip the item you want to farm with e.g press 3 or 4 etc then press 'Auto-Farm' let it do the work for you)"
TextLabel_2.TextColor3 = Color3.new(0, 0.415686, 0.654902)
TextLabel_2.TextScaled = true
TextLabel_2.TextSize = 14
TextLabel_2.TextWrapped = true
TextLabel_2.TextXAlignment = Enum.TextXAlignment.Left
TextLabel_2.TextYAlignment = Enum.TextYAlignment.Top

join.Name = "join"
join.Parent = Frame
join.BackgroundColor3 = Color3.new(0, 0.368627, 0.580392)
join.BorderSizePixel = 0
join.Position = UDim2.new(0, 0, 0, 261)
join.Size = UDim2.new(0, 199, 0, 37)
join.Font = Enum.Font.Cartoon
join.Text = "Join the discord"
join.TextColor3 = Color3.new(0, 0.65098, 1)
join.TextScaled = true
join.TextSize = 14
join.TextWrapped = true
-- Scripts:
function SCRIPT_QYHM89_FAKESCRIPT() -- KillBabies.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = KillBabies
	
	local on = false
	script.Parent.MouseButton1Click:Connect(function()
		on = not on 
	repeat
		wait()
	
	
		for _,v in pairs(game.Players:GetChildren()) do 
		if v.Name ~= game.Players.LocalPlayer.Name then 
			if game.Workspace:FindFirstChild(v.Name) ~= nil and game.Workspace:FindFirstChild(v.Name):FindFirstChild("HumanoidRootPart") ~= nil then 
					repeat
						wait()
						game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.Character.HumanoidRootPart.CFrame + - v.Character.HumanoidRootPart.CFrame.lookVector
					until v.Character.Humanoid.Health == 0  or v.Character == nil or game.Workspace:FindFirstChild(game.Players.LocalPlayer.Name) == nil or v.Character:FindFirstChild("HumanoidRootPart") == nil or game.Players.LocalPlayer.Character.Humanoid.Health == 0 
		end;end;end
	until on == false
	end)

end
coroutine.resume(coroutine.create(SCRIPT_QYHM89_FAKESCRIPT))
function SCRIPT_QNWG70_FAKESCRIPT() -- Inf.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = Inf
	
	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Info.Visible = not script.Parent.Parent.Info.Visible
	end)

end
coroutine.resume(coroutine.create(SCRIPT_QNWG70_FAKESCRIPT))
function SCRIPT_KSCI66_FAKESCRIPT() -- AF.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = AF
	local on = false
	script.Parent.MouseButton1Click:Connect(function()
		on = not on 
		repeat
			wait()
			if game.Workspace:WaitForChild(game.Players.LocalPlayer.Name):FindFirstChildOfClass("Tool") ~= nil then
				local A_1 = game.Workspace:WaitForChild(game.Players.LocalPlayer.Name):FindFirstChildOfClass("Tool")
				local Event = game:GetService("ReplicatedStorage").Remotes.Input
				Event:FireServer(A_1)
	
		end
			
		until on == false
	end)

end
coroutine.resume(coroutine.create(SCRIPT_KSCI66_FAKESCRIPT))
function SCRIPT_BBBQ76_FAKESCRIPT() -- Inf_2.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = Inf_2
	
	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Info2.Visible = not script.Parent.Parent.Info2.Visible
	end)

end
coroutine.resume(coroutine.create(SCRIPT_BBBQ76_FAKESCRIPT))
function SCRIPT_BRBN76_FAKESCRIPT() -- Frame.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = Frame
	script.Parent.Active = true
	script.Parent.Draggable = true

end
coroutine.resume(coroutine.create(SCRIPT_BRBN76_FAKESCRIPT))
function SCRIPT_GDHO70_FAKESCRIPT() -- join.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = join
	local set = setreadonly or make_writeable
	local discordlink = 'https://discord.gg/JpRgQRK'
	
	
	script.Parent.MouseButton1Click:Connect(function()
	
	if not set then
	    script.Parent.Text = 'Sorry your exploit cannot handle this function but the discord link is '..discordlink
		wait(30)
		script.Parent.Text = 'Join the discord'
	
	else
		syn.write_clipboard(discordlink)
		script.Parent.Text = 'Copied to clipboard'
		wait(1)
		script.Parent.Text=  'Join the discord'
	
	end
	end)

end
coroutine.resume(coroutine.create(SCRIPT_GDHO70_FAKESCRIPT))