getglobal game
getfield -1 Workspace
getfield -1 Player1
getfield -1 HumanoidRootPart
getglobal game
getfield -1 Workspace
getfield -1 Player2
getfield -1 Torso
getfield -1 CFrame
setfield -6 CFrame
emptystack