getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring classicalienpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring dominusinfernuspet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring dominusfrigiduspet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring classicteapotpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring penguinpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring epicduckpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring moonmanpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring spookypumpinpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring epicbananapet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring snowmanpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring scifinoobpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring dominocrownpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring advancedalienpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring holidaydogepet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring dominuspet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring floatingteddypet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring raignoobpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring froggopet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring yepet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring dogepet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring lolwutpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring lolhoopet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring lolhowpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring squidpet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring datboipet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring eyepet
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring harambepet
pcall 3 1 0