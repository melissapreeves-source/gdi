--Commands Found By Jabrika123--

Z - To run

X - To bring your Baseball Bat

E - To hit with Big Baseball bat

M - To say "I Win"

C - To bring the Giant Noob Hammer (Press x First)

V - To bring out the Mr.Noobington (Hold left mouse button to eat things)

; - To spawn Giant Noob

K - To spawn standing noob

I - To spawn ragdoll noob (or L)

P - To clear all the noobs in the map

F - To fling hit

[ ] - To spawn a noob called Nooraph