wait(0.3)
-- Objects
-- CREDIT TO xFunnieuss / Timeless for partial (short) names.

OPFinality = Instance.new("ScreenGui")
MainFrame = Instance.new("Frame")
TopFrame = Instance.new("Frame")
CloseGUI = Instance.new("TextButton")
MenuEnterFrame = Instance.new("Frame")
Title = Instance.new("TextLabel")
OpenMenu = Instance.new("ImageButton")
Pages = Instance.new("Frame")
Information = Instance.new("Frame")
Image_FE_ENABLED = Instance.new("ImageLabel")
Text_FE_ENABLED = Instance.new("TextLabel")
WhatIsOPFinality = Instance.new("TextLabel")
Text_FE_DISABLED = Instance.new("TextLabel")
OPFin_Description = Instance.new("TextLabel")
OPFin_Warning = Instance.new("TextLabel")
Info_Bar = Instance.new("Frame")
Info_Background = Instance.new("Frame")
Warning_Bar = Instance.new("Frame")
Warning_Background = Instance.new("Frame")
Info_Image = Instance.new("ImageLabel")
Image_FE_DISABLED = Instance.new("ImageLabel")
Warn_Image = Instance.new("ImageLabel")
Others_1 = Instance.new("Frame")
OthersTitle = Instance.new("TextLabel")
Char_Image = Instance.new("ImageLabel")
OthersText = Instance.new("TextLabel")
TXTBOX_PlrName = Instance.new("TextBox")
othersBaseBackground = Instance.new("Frame")
TeleportTo = Instance.new("TextButton")
Annoy = Instance.new("TextButton")
Follow = Instance.new("TextButton")
View = Instance.new("TextButton")
Orbit = Instance.new("TextButton")
HeadWalk = Instance.new("TextButton")
Stick = Instance.new("TextButton")
Spam = Instance.new("TextButton")
Carpet = Instance.new("TextButton")
Others_toPAGE2 = Instance.new("TextButton")
Character_toPAGE2_IMAGE = Instance.new("ImageLabel")
Character_2 = Instance.new("Frame")
CharacterTitle = Instance.new("TextLabel")
CharacterText = Instance.new("TextLabel")
Animations_SPOOKY = Instance.new("Frame")
spookytitle = Instance.new("TextLabel")
headthrow = Instance.new("TextButton")
armsoff = Instance.new("TextButton")
loophead = Instance.new("TextButton")
levitate = Instance.new("TextButton")
headfloat = Instance.new("TextButton")
Character_backPAGE1 = Instance.new("TextButton")
Character_toPAGE1_IMAGE = Instance.new("ImageLabel")
Animations_DANCE = Instance.new("Frame")
dancetitle = Instance.new("TextLabel")
normal = Instance.new("TextButton")
movingdance = Instance.new("TextButton")
insane = Instance.new("TextButton")
happy = Instance.new("TextButton")
spindance = Instance.new("TextButton")
Animations_HEROIC = Instance.new("Frame")
heroictitle = Instance.new("TextLabel")
swordstrike = Instance.new("TextButton")
jumpland = Instance.new("TextButton")
punches = Instance.new("TextButton")
swing = Instance.new("TextButton")
crawl = Instance.new("TextButton")
Char2_Image = Instance.new("ImageLabel")
Character_1 = Instance.new("Frame")
CharacterTitle_2 = Instance.new("TextLabel")
Char_Image_2 = Instance.new("ImageLabel")
CharacterText_2 = Instance.new("TextLabel")
TXTBOX_Stats = Instance.new("TextBox")
BackGroundChar = Instance.new("Frame")
HipHeight = Instance.new("TextButton")
JumpHeight = Instance.new("TextButton")
Speed = Instance.new("TextButton")
TXTBOX_Chat = Instance.new("TextBox")
BackGroundChar2 = Instance.new("Frame")
Chat = Instance.new("TextButton")
Spam_2 = Instance.new("TextButton")
BackGroundChar3 = Instance.new("Frame")
Noclip = Instance.new("TextButton")
Fly = Instance.new("TextButton")
Character_toPAGE2 = Instance.new("TextButton")
Character_toPAGE2_IMAGE_2 = Instance.new("ImageLabel")
Others_2 = Instance.new("Frame")
OthersTitle_2 = Instance.new("TextLabel")
Other_Image2 = Instance.new("ImageLabel")
OthersText_2 = Instance.new("TextLabel")
TXTBOX_PlrName2 = Instance.new("TextBox")
othersBaseBackground2 = Instance.new("Frame")
Flatten = Instance.new("TextButton")
AimHead = Instance.new("TextButton")
Float = Instance.new("TextButton")
Multiple = Instance.new("TextButton")
Animated = Instance.new("TextButton")
SlowAttract = Instance.new("TextButton")
WeirdOrbit = Instance.new("TextButton")
Violent = Instance.new("TextButton")
Max = Instance.new("TextButton")
Others_toPAGE3 = Instance.new("TextButton")
Character_toPAGE3_IMAGE = Instance.new("ImageLabel")
Others_backPAGE1 = Instance.new("TextButton")
Character_toPAGE1_IMAGE_2 = Instance.new("ImageLabel")
Extra_1 = Instance.new("Frame")
Extra_Image = Instance.new("ImageLabel")
ExtraText = Instance.new("TextLabel")
ExtraBaseBackGround1 = Instance.new("Frame")
CrouchRocket = Instance.new("TextButton")
ExtraBaseBackGround1Side = Instance.new("Frame")
CloneIllusion = Instance.new("TextButton")
CoolSpin = Instance.new("TextButton")
JumpRocket = Instance.new("TextButton")
Extra_toPAGE2 = Instance.new("TextButton")
Character_toPAGE2_IMAGE_3 = Instance.new("ImageLabel")
Extra_Title = Instance.new("TextLabel")
ExtraBaseBackGround2 = Instance.new("Frame")
NoLimbs = Instance.new("TextButton")
FEGodmode = Instance.new("TextButton")
BrickHats = Instance.new("TextButton")
RapidPunch = Instance.new("TextButton")
ExtraBaseBackGround2Side = Instance.new("Frame")
ExtraBaseBackGround3 = Instance.new("Frame")
PunchFollow = Instance.new("TextButton")
ArmFollow = Instance.new("TextButton")
Spin = Instance.new("TextButton")
Faint = Instance.new("TextButton")
ExtraBaseBackGround3Side = Instance.new("Frame")
Extra_2 = Instance.new("Frame")
Extra_Image_2 = Instance.new("ImageLabel")
ExtraText_2 = Instance.new("TextLabel")
Extra_Title_2 = Instance.new("TextLabel")
ExtraBaseBackGround2_2 = Instance.new("Frame")
CrouchAttack = Instance.new("TextButton")
WalkThrough = Instance.new("TextButton")
CreepyWatch = Instance.new("TextButton")
SpinAttack = Instance.new("TextButton")
ExtraBaseBackGround2Side_2 = Instance.new("Frame")
TXTBOX_PlrNameEXTRA = Instance.new("TextBox")
_18 = Instance.new("TextButton")
SlamPropulsion = Instance.new("TextButton")
Extra_backPAGE1 = Instance.new("TextButton")
Character_toPAGE1_IMAGE_3 = Instance.new("ImageLabel")
Others_3 = Instance.new("Frame")
OthersTitle_3 = Instance.new("TextLabel")
Other_Image3 = Instance.new("ImageLabel")
OthersText_3 = Instance.new("TextLabel")
TXTBOX_PlrNameOTHER3 = Instance.new("TextBox")
othersBaseBackground3 = Instance.new("Frame")
FreeFall = Instance.new("TextButton")
Attach = Instance.new("TextButton")
Bring = Instance.new("TextButton")
SafeKill = Instance.new("TextButton")
SuperSpin = Instance.new("TextButton")
Kill = Instance.new("TextButton")
Others_backPAGE2 = Instance.new("TextButton")
Character_toPAGE1_IMAGE_4 = Instance.new("ImageLabel")
Games = Instance.new("Frame")
Games_IMAGE = Instance.new("ImageLabel")
GamesText = Instance.new("TextLabel")
Games_TITLE = Instance.new("TextLabel")
Games_IMAGE2 = Instance.new("ImageLabel")
SwordFightingTournament = Instance.new("TextButton")
PlatesOfFateMayhem = Instance.new("TextButton")
GamesText2 = Instance.new("TextLabel")
Frappe = Instance.new("TextButton")
Frappe_2 = Instance.new("TextButton")
MenuFrame = Instance.new("Frame")
Welcome = Instance.new("TextLabel")
NameOfPlayer = Instance.new("TextLabel")
T_Information = Instance.new("TextButton")
T_InfoImage = Instance.new("ImageLabel")
T_Character = Instance.new("TextButton")
T_CharImage = Instance.new("ImageLabel")
T_Games = Instance.new("TextButton")
T_GameImage = Instance.new("ImageLabel")
T_Others = Instance.new("TextButton")
T_OtherImage = Instance.new("ImageLabel")
T_Extra = Instance.new("TextButton")
T_ExtraImage = Instance.new("ImageLabel")
DeleteGUI = Instance.new("TextButton")
DELETEIMAGE = Instance.new("ImageLabel")
Darkness = Instance.new("TextButton")

-- Properties

OPFinality.Name = "OPFinality"
OPFinality.Parent = game.CoreGui

MainFrame.Name = "MainFrame"
MainFrame.Parent = OPFinality
MainFrame.Active = true
MainFrame.BackgroundColor3 = Color3.new(1, 1, 1)
MainFrame.BackgroundTransparency = 1
MainFrame.BorderSizePixel = 0
MainFrame.ClipsDescendants = true
MainFrame.Draggable = true
MainFrame.Position = UDim2.new(0, 402, 0, 162)
MainFrame.Size = UDim2.new(0, 442, 0, 293)

TopFrame.Name = "TopFrame"
TopFrame.Parent = MainFrame
TopFrame.BackgroundColor3 = Color3.new(0.752941, 0.223529, 0.168627)
TopFrame.BorderColor3 = Color3.new(0.145098, 0.184314, 0.223529)
TopFrame.BorderSizePixel = 0
TopFrame.Size = UDim2.new(1, 0, 0.0741975307, 0)
TopFrame.ZIndex = 7

CloseGUI.Parent = TopFrame
CloseGUI.BackgroundColor3 = Color3.new(1, 1, 1)
CloseGUI.BackgroundTransparency = 1
CloseGUI.Position = UDim2.new(0.951219499, 0, 0, 0)
CloseGUI.Size = UDim2.new(0.048780486, 0, 1.00166667, 0)
CloseGUI.Font = Enum.Font.Cartoon
CloseGUI.FontSize = Enum.FontSize.Size28
CloseGUI.Text = "X"
CloseGUI.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
CloseGUI.TextSize = 25
CloseGUI.ZIndex = 8

MenuEnterFrame.Name = "MenuEnterFrame"
MenuEnterFrame.Parent = MainFrame
MenuEnterFrame.BackgroundColor3 = Color3.new(0.905882, 0.298039, 0.235294)
MenuEnterFrame.BorderColor3 = Color3.new(0.145098, 0.184314, 0.223529)
MenuEnterFrame.BorderSizePixel = 0
MenuEnterFrame.Position = UDim2.new(0, 0, 0.0741975307, 0)
MenuEnterFrame.Size = UDim2.new(1, 0, 0.148395061, 0)
MenuEnterFrame.ZIndex = 5

Title.Name = "Title"
Title.Parent = MenuEnterFrame
Title.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Title.BackgroundTransparency = 1
Title.Position = UDim2.new(0.341463417, 0, 0, 0)
Title.Size = UDim2.new(0.292682916, 0, 1.00166667, 0)
Title.Font = Enum.Font.SourceSansLight
Title.FontSize = Enum.FontSize.Size32
Title.Text = "OPFinality"
Title.TextColor3 = Color3.new(0.933333, 0.933333, 0.933333)
Title.TextSize = 30
Title.ZIndex = 6

OpenMenu.Name = "OpenMenu"
OpenMenu.Parent = MenuEnterFrame
OpenMenu.BackgroundColor3 = Color3.new(1, 1, 1)
OpenMenu.BackgroundTransparency = 1
OpenMenu.Size = UDim2.new(0.0909999982, 0, 1.01999998, 0)
OpenMenu.Image = "http://www.roblox.com/asset/?id=1280184088"
OpenMenu.ZIndex = 6

Pages.Name = "Pages"
Pages.Parent = MainFrame
Pages.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Pages.BorderSizePixel = 0
Pages.Position = UDim2.new(0, 0, 0.222592592, 0)
Pages.Size = UDim2.new(1, 0, 0.779074073, 0)

Information.Name = "Information"
Information.Parent = Pages
Information.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Information.BorderSizePixel = 0
Information.Size = UDim2.new(1, 0, 1, 0)

Image_FE_ENABLED.Name = "Image_FE_ENABLED"
Image_FE_ENABLED.Parent = Information
Image_FE_ENABLED.BackgroundColor3 = Color3.new(1, 1, 1)
Image_FE_ENABLED.BackgroundTransparency = 1
Image_FE_ENABLED.Position = UDim2.new(0.0227242485, 0, 0.0454809628, 0)
Image_FE_ENABLED.Size = UDim2.new(0.136345491, 0, 0.263394117, 0)
Image_FE_ENABLED.Visible = false
Image_FE_ENABLED.Image = "http://www.roblox.com/asset/?id=1281289312"

Text_FE_ENABLED.Name = "Text_FE_ENABLED"
Text_FE_ENABLED.Parent = Information
Text_FE_ENABLED.BackgroundColor3 = Color3.new(1, 1, 1)
Text_FE_ENABLED.BackgroundTransparency = 1
Text_FE_ENABLED.Position = UDim2.new(0.158999994, 0, 0.0670000017, 0)
Text_FE_ENABLED.Size = UDim2.new(0.795348704, 0, 0.227404833, 0)
Text_FE_ENABLED.Visible = false
Text_FE_ENABLED.Font = Enum.Font.SourceSansItalic
Text_FE_ENABLED.FontSize = Enum.FontSize.Size24
Text_FE_ENABLED.Text = "This game is Filtering Enabled! Enjoy using OPFinality."
Text_FE_ENABLED.TextSize = 19

WhatIsOPFinality.Name = "WhatIsOPFinality"
WhatIsOPFinality.Parent = Information
WhatIsOPFinality.BackgroundColor3 = Color3.new(1, 1, 1)
WhatIsOPFinality.BackgroundTransparency = 1
WhatIsOPFinality.Position = UDim2.new(0.249966726, 0, 0.227404833, 0)
WhatIsOPFinality.Size = UDim2.new(0.522657692, 0, 0.1364429, 0)
WhatIsOPFinality.Font = Enum.Font.SourceSansBold
WhatIsOPFinality.FontSize = Enum.FontSize.Size28
WhatIsOPFinality.Text = "What is OPFinality?"
WhatIsOPFinality.TextSize = 25

Text_FE_DISABLED.Name = "Text_FE_DISABLED"
Text_FE_DISABLED.Parent = Information
Text_FE_DISABLED.BackgroundColor3 = Color3.new(1, 1, 1)
Text_FE_DISABLED.BackgroundTransparency = 1
Text_FE_DISABLED.Position = UDim2.new(0.158999994, 0, 0.0670000017, 0)
Text_FE_DISABLED.Size = UDim2.new(0.545381963, 0, 0.227404833, 0)
Text_FE_DISABLED.Font = Enum.Font.SourceSansItalic
Text_FE_DISABLED.FontSize = Enum.FontSize.Size24
Text_FE_DISABLED.Text = "Oh! This game is Filtering Disabled..."
Text_FE_DISABLED.TextSize = 19

OPFin_Description.Name = "OPFin_Description"
OPFin_Description.Parent = Information
OPFin_Description.BackgroundColor3 = Color3.new(1, 1, 1)
OPFin_Description.BackgroundTransparency = 1
OPFin_Description.Position = UDim2.new(0.204999998, 0, 0.388000011, 0)
OPFin_Description.Size = UDim2.new(0.772624433, 0, 0.181923851, 0)
OPFin_Description.ZIndex = 3
OPFin_Description.Font = Enum.Font.SourceSans
OPFin_Description.FontSize = Enum.FontSize.Size18
OPFin_Description.Text = "OPFinality is an FE GUI developed by illremember made for giving you power in Filtering Enabled games."
OPFin_Description.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
OPFin_Description.TextSize = 18
OPFin_Description.TextWrapped = true

OPFin_Warning.Name = "OPFin_Warning"
OPFin_Warning.Parent = Information
OPFin_Warning.BackgroundColor3 = Color3.new(1, 1, 1)
OPFin_Warning.BackgroundTransparency = 1
OPFin_Warning.Position = UDim2.new(0.0227242485, 0, 0.636733532, 0)
OPFin_Warning.Size = UDim2.new(0.659003198, 0, 0.272885799, 0)
OPFin_Warning.ZIndex = 2
OPFin_Warning.Font = Enum.Font.SourceSans
OPFin_Warning.FontSize = Enum.FontSize.Size18
OPFin_Warning.Text = "If this game is detected as Filtering Disabled, this GUI wont work as well as other scripts would. Consider using a different script."
OPFin_Warning.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
OPFin_Warning.TextSize = 18
OPFin_Warning.TextWrapped = true

Info_Bar.Name = "Info_Bar"
Info_Bar.Parent = Information
Info_Bar.BackgroundColor3 = Color3.new(0.160784, 0.501961, 0.72549)
Info_Bar.BorderSizePixel = 0
Info_Bar.Position = UDim2.new(0.159069732, 0, 0.363847703, 0)
Info_Bar.Size = UDim2.new(0.0227242485, 0, 0.227404833, 0)

Info_Background.Name = "Info_Background"
Info_Background.Parent = Information
Info_Background.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
Info_Background.BorderSizePixel = 0
Info_Background.Position = UDim2.new(0.181793988, 0, 0.363847703, 0)
Info_Background.Size = UDim2.new(0.819999993, 0, 0.226999998, 0)
Info_Background.ZIndex = 2

Warning_Bar.Name = "Warning_Bar"
Warning_Bar.Parent = Information
Warning_Bar.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
Warning_Bar.BorderSizePixel = 0
Warning_Bar.Position = UDim2.new(0.70445168, 0, 0.636733532, 0)
Warning_Bar.Size = UDim2.new(0.0227242485, 0, 0.272885799, 0)

Warning_Background.Name = "Warning_Background"
Warning_Background.Parent = Information
Warning_Background.BackgroundColor3 = Color3.new(0.945098, 0.768628, 0.0588235)
Warning_Background.BorderSizePixel = 0
Warning_Background.Position = UDim2.new(0, 0, 0.636733532, 0)
Warning_Background.Size = UDim2.new(0.70445168, 0, 0.272885799, 0)

Info_Image.Name = "Info_Image"
Info_Image.Parent = Information
Info_Image.BackgroundColor3 = Color3.new(1, 1, 1)
Info_Image.BackgroundTransparency = 1
Info_Image.Position = UDim2.new(0.0454484969, 0, 0.395091146, 0)
Info_Image.Size = UDim2.new(0.0908969939, 0, 0.175596073, 0)
Info_Image.Image = "http://www.roblox.com/asset/?id=1281284684"

Image_FE_DISABLED.Name = "Image_FE_DISABLED"
Image_FE_DISABLED.Parent = Information
Image_FE_DISABLED.BackgroundColor3 = Color3.new(1, 1, 1)
Image_FE_DISABLED.BackgroundTransparency = 1
Image_FE_DISABLED.Position = UDim2.new(0.0227242485, 0, 0.0454809628, 0)
Image_FE_DISABLED.Size = UDim2.new(0.136345491, 0, 0.263394117, 0)
Image_FE_DISABLED.Image = "http://www.roblox.com/asset/?id=1281290326"

Warn_Image.Name = "Warn_Image"
Warn_Image.Parent = Information
Warn_Image.BackgroundColor3 = Color3.new(1, 1, 1)
Warn_Image.BackgroundTransparency = 1
Warn_Image.Position = UDim2.new(0.763000011, 0, 0.677999973, 0)
Warn_Image.Size = UDim2.new(0.0908969939, 0, 0.175596073, 0)
Warn_Image.Image = "http://www.roblox.com/asset/?id=1281286925"

Others_1.Name = "Others_1"
Others_1.Parent = Pages
Others_1.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Others_1.BorderSizePixel = 0
Others_1.Position = UDim2.new(1.00752497, 0, 0, 0)
Others_1.Size = UDim2.new(1, 0, 1, 0)

OthersTitle.Name = "OthersTitle"
OthersTitle.Parent = Others_1
OthersTitle.BackgroundColor3 = Color3.new(1, 1, 1)
OthersTitle.BackgroundTransparency = 1
OthersTitle.Position = UDim2.new(0.226410091, 0, 0.0439298227, 0)
OthersTitle.Size = UDim2.new(0.522657692, 0, 0.1364429, 0)
OthersTitle.Font = Enum.Font.SourceSansBold
OthersTitle.FontSize = Enum.FontSize.Size28
OthersTitle.Text = "Others"
OthersTitle.TextSize = 25

Char_Image.Name = "Char_Image"
Char_Image.Parent = Others_1
Char_Image.BackgroundColor3 = Color3.new(1, 1, 1)
Char_Image.BackgroundTransparency = 1
Char_Image.Position = UDim2.new(0.0113205044, 0, 0.153754383, 0)
Char_Image.Size = UDim2.new(0.0908969939, 0, 0.175596073, 0)
Char_Image.Image = "http://www.roblox.com/asset/?id=1281476978"

OthersText.Name = "OthersText"
OthersText.Parent = Others_1
OthersText.BackgroundColor3 = Color3.new(1, 1, 1)
OthersText.BackgroundTransparency = 1
OthersText.Position = UDim2.new(0.101884536, 0, 0.153754383, 0)
OthersText.Size = UDim2.new(0.781114817, 0, 0.175719291, 0)
OthersText.Font = Enum.Font.SourceSansItalic
OthersText.FontSize = Enum.FontSize.Size24
OthersText.Text = "Use a set of basic commands on other players! Enter a name into the textbox, supports partial names."
OthersText.TextSize = 19
OthersText.TextWrapped = true

TXTBOX_PlrName.Name = "TXTBOX_PlrName"
TXTBOX_PlrName.Parent = Others_1
TXTBOX_PlrName.BackgroundColor3 = Color3.new(0.956863, 0.968628, 0.972549)
TXTBOX_PlrName.BorderColor3 = Color3.new(0.152941, 0.682353, 0.376471)
TXTBOX_PlrName.BorderSizePixel = 0
TXTBOX_PlrName.Position = UDim2.new(0.249051109, 0, 0.395368397, 0)
TXTBOX_PlrName.Size = UDim2.new(0.520743191, 0, 0.0878596455, 0)
TXTBOX_PlrName.ZIndex = 2
TXTBOX_PlrName.Font = Enum.Font.SourceSans
TXTBOX_PlrName.FontSize = Enum.FontSize.Size14
TXTBOX_PlrName.Text = "Player"
TXTBOX_PlrName.TextScaled = true
TXTBOX_PlrName.TextSize = 14
TXTBOX_PlrName.TextWrapped = true

othersBaseBackground.Name = "othersBaseBackground"
othersBaseBackground.Parent = Others_1
othersBaseBackground.BackgroundColor3 = Color3.new(0.160784, 0.501961, 0.72549)
othersBaseBackground.BorderSizePixel = 0
othersBaseBackground.Position = UDim2.new(0.124525554, 0, 0.351438582, 0)
othersBaseBackground.Size = UDim2.new(0.769999981, 0, 0.649999976, 0)

TeleportTo.Name = "TeleportTo"
TeleportTo.Parent = othersBaseBackground
TeleportTo.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
TeleportTo.BorderSizePixel = 0
TeleportTo.Position = UDim2.new(0.0294333119, 0, 0.27070269, 0)
TeleportTo.Size = UDim2.new(0, 92, 0, 25)
TeleportTo.Font = Enum.Font.SourceSans
TeleportTo.FontSize = Enum.FontSize.Size24
TeleportTo.Text = "Teleport To"
TeleportTo.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
TeleportTo.TextSize = 22

Annoy.Name = "Annoy"
Annoy.Parent = othersBaseBackground
Annoy.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
Annoy.BorderSizePixel = 0
Annoy.Position = UDim2.new(0.0294333119, 0, 0.507567585, 0)
Annoy.Size = UDim2.new(0, 92, 0, 25)
Annoy.Font = Enum.Font.SourceSans
Annoy.FontSize = Enum.FontSize.Size24
Annoy.Text = "Annoy"
Annoy.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Annoy.TextSize = 22

Follow.Name = "Follow"
Follow.Parent = othersBaseBackground
Follow.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
Follow.BorderSizePixel = 0
Follow.Position = UDim2.new(0.0294333119, 0, 0.744432449, 0)
Follow.Size = UDim2.new(0, 92, 0, 25)
Follow.Font = Enum.Font.SourceSans
Follow.FontSize = Enum.FontSize.Size24
Follow.Text = "Follow"
Follow.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Follow.TextSize = 22

View.Name = "View"
View.Parent = othersBaseBackground
View.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
View.BorderSizePixel = 0
View.Position = UDim2.new(0.367916405, 0, 0.27070269, 0)
View.Size = UDim2.new(0, 92, 0, 25)
View.Font = Enum.Font.SourceSans
View.FontSize = Enum.FontSize.Size24
View.Text = "View"
View.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
View.TextSize = 22

Orbit.Name = "Orbit"
Orbit.Parent = othersBaseBackground
Orbit.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
Orbit.BorderSizePixel = 0
Orbit.Position = UDim2.new(0.367916405, 0, 0.507567585, 0)
Orbit.Size = UDim2.new(0, 92, 0, 25)
Orbit.Font = Enum.Font.SourceSans
Orbit.FontSize = Enum.FontSize.Size24
Orbit.Text = "Orbit"
Orbit.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Orbit.TextSize = 22

HeadWalk.Name = "HeadWalk"
HeadWalk.Parent = othersBaseBackground
HeadWalk.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
HeadWalk.BorderSizePixel = 0
HeadWalk.Position = UDim2.new(0.367916405, 0, 0.744432449, 0)
HeadWalk.Size = UDim2.new(0, 92, 0, 25)
HeadWalk.Font = Enum.Font.SourceSans
HeadWalk.FontSize = Enum.FontSize.Size24
HeadWalk.Text = "Head Walk"
HeadWalk.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
HeadWalk.TextSize = 22

Stick.Name = "Stick"
Stick.Parent = othersBaseBackground
Stick.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
Stick.BorderSizePixel = 0
Stick.Position = UDim2.new(0.7063995, 0, 0.27070269, 0)
Stick.Size = UDim2.new(0, 92, 0, 25)
Stick.Font = Enum.Font.SourceSans
Stick.FontSize = Enum.FontSize.Size24
Stick.Text = "Stick"
Stick.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Stick.TextSize = 22

Spam.Name = "Spam"
Spam.Parent = othersBaseBackground
Spam.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
Spam.BorderSizePixel = 0
Spam.Position = UDim2.new(0.7063995, 0, 0.507567585, 0)
Spam.Size = UDim2.new(0, 92, 0, 25)
Spam.Font = Enum.Font.SourceSans
Spam.FontSize = Enum.FontSize.Size24
Spam.Text = "Spam"
Spam.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Spam.TextSize = 22

Carpet.Name = "Carpet"
Carpet.Parent = othersBaseBackground
Carpet.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
Carpet.BorderSizePixel = 0
Carpet.Position = UDim2.new(0.7063995, 0, 0.744432449, 0)
Carpet.Size = UDim2.new(0, 92, 0, 25)
Carpet.Font = Enum.Font.SourceSans
Carpet.FontSize = Enum.FontSize.Size24
Carpet.Text = "Carpet"
Carpet.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Carpet.TextSize = 22

Others_toPAGE2.Name = "Others_toPAGE2"
Others_toPAGE2.Parent = Others_1
Others_toPAGE2.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Others_toPAGE2.BorderSizePixel = 0
Others_toPAGE2.Position = UDim2.new(0.819999993, 0, 0.0439999998, 0)
Others_toPAGE2.Size = UDim2.new(0.113205045, 0, 0.109824568, 0)
Others_toPAGE2.Font = Enum.Font.SourceSansLight
Others_toPAGE2.FontSize = Enum.FontSize.Size24
Others_toPAGE2.Text = "Next"
Others_toPAGE2.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Others_toPAGE2.TextSize = 22

Character_toPAGE2_IMAGE.Name = "Character_toPAGE2_IMAGE"
Character_toPAGE2_IMAGE.Parent = Others_toPAGE2
Character_toPAGE2_IMAGE.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Character_toPAGE2_IMAGE.BorderSizePixel = 0
Character_toPAGE2_IMAGE.Position = UDim2.new(0.900659323, 0, 0, 0)
Character_toPAGE2_IMAGE.Size = UDim2.new(0, 25, 0, 25)
Character_toPAGE2_IMAGE.Image = "http://www.roblox.com/asset/?id=1282737326"

Character_2.Name = "Character_2"
Character_2.Parent = Pages
Character_2.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Character_2.BorderSizePixel = 0
Character_2.Position = UDim2.new(1, 0, 0, 0)
Character_2.Size = UDim2.new(1, 0, 1, 0)

CharacterTitle.Name = "CharacterTitle"
CharacterTitle.Parent = Character_2
CharacterTitle.BackgroundColor3 = Color3.new(1, 1, 1)
CharacterTitle.BackgroundTransparency = 1
CharacterTitle.Position = UDim2.new(0.226410091, 0, 0, 0)
CharacterTitle.Size = UDim2.new(0.522657692, 0, 0.1364429, 0)
CharacterTitle.Font = Enum.Font.SourceSansBold
CharacterTitle.FontSize = Enum.FontSize.Size28
CharacterTitle.Text = "Character"
CharacterTitle.TextSize = 25

CharacterText.Name = "CharacterText"
CharacterText.Parent = Character_2
CharacterText.BackgroundColor3 = Color3.new(1, 1, 1)
CharacterText.BackgroundTransparency = 1
CharacterText.Position = UDim2.new(0.158487067, 0, 0.109824568, 0)
CharacterText.Size = UDim2.new(0.679230273, 0, 0.0878596455, 0)
CharacterText.Font = Enum.Font.SourceSansItalic
CharacterText.FontSize = Enum.FontSize.Size24
CharacterText.Text = "Apply cool animations to your player!"
CharacterText.TextSize = 19
CharacterText.TextWrapped = true

Animations_SPOOKY.Name = "Animations_SPOOKY"
Animations_SPOOKY.Parent = Character_2
Animations_SPOOKY.BackgroundColor3 = Color3.new(0.827451, 0.329412, 0)
Animations_SPOOKY.BorderSizePixel = 0
Animations_SPOOKY.Position = UDim2.new(0.101884536, 0, 0.263578951, 0)
Animations_SPOOKY.Size = UDim2.new(0.200000003, 0, 0.735000014, 0)

spookytitle.Name = "spookytitle"
spookytitle.Parent = Animations_SPOOKY
spookytitle.BackgroundColor3 = Color3.new(1, 1, 1)
spookytitle.BackgroundTransparency = 1
spookytitle.Position = UDim2.new(0, 0, 0.0298095234, 0)
spookytitle.Size = UDim2.new(0.96661669, 0, 0.149047628, 0)
spookytitle.Font = Enum.Font.SourceSansLight
spookytitle.FontSize = Enum.FontSize.Size28
spookytitle.Text = "Spooky"
spookytitle.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
spookytitle.TextSize = 25

headthrow.Name = "headthrow"
headthrow.Parent = Animations_SPOOKY
headthrow.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
headthrow.BorderSizePixel = 0
headthrow.Position = UDim2.new(0, 0, 0.238476187, 0)
headthrow.Size = UDim2.new(1, 0, 0.119000003, 0)
headthrow.Font = Enum.Font.SourceSans
headthrow.FontSize = Enum.FontSize.Size14
headthrow.Text = "Head Throw"
headthrow.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
headthrow.TextScaled = true
headthrow.TextSize = 14
headthrow.TextWrapped = true

armsoff.Name = "armsoff"
armsoff.Parent = Animations_SPOOKY
armsoff.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
armsoff.BorderSizePixel = 0
armsoff.Position = UDim2.new(0, 0, 0.3875238, 0)
armsoff.Size = UDim2.new(1, 0, 0.119000003, 0)
armsoff.Font = Enum.Font.SourceSans
armsoff.FontSize = Enum.FontSize.Size14
armsoff.Text = "Arms Off"
armsoff.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
armsoff.TextScaled = true
armsoff.TextSize = 14
armsoff.TextWrapped = true

loophead.Name = "loophead"
loophead.Parent = Animations_SPOOKY
loophead.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
loophead.BorderSizePixel = 0
loophead.Position = UDim2.new(0, 0, 0.536571383, 0)
loophead.Size = UDim2.new(1, 0, 0.119000003, 0)
loophead.Font = Enum.Font.SourceSans
loophead.FontSize = Enum.FontSize.Size14
loophead.Text = "Loop Head"
loophead.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
loophead.TextScaled = true
loophead.TextSize = 14
loophead.TextWrapped = true

levitate.Name = "levitate"
levitate.Parent = Animations_SPOOKY
levitate.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
levitate.BorderSizePixel = 0
levitate.Position = UDim2.new(0, 0, 0.685619056, 0)
levitate.Size = UDim2.new(1, 0, 0.119000003, 0)
levitate.Font = Enum.Font.SourceSans
levitate.FontSize = Enum.FontSize.Size14
levitate.Text = "Levitate"
levitate.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
levitate.TextScaled = true
levitate.TextSize = 14
levitate.TextWrapped = true

headfloat.Name = "headfloat"
headfloat.Parent = Animations_SPOOKY
headfloat.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
headfloat.BorderSizePixel = 0
headfloat.Position = UDim2.new(0, 0, 0.834666669, 0)
headfloat.Size = UDim2.new(1, 0, 0.119000003, 0)
headfloat.Font = Enum.Font.SourceSans
headfloat.FontSize = Enum.FontSize.Size14
headfloat.Text = "Head Float"
headfloat.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
headfloat.TextScaled = true
headfloat.TextSize = 14
headfloat.TextWrapped = true

Character_backPAGE1.Name = "Character_backPAGE1"
Character_backPAGE1.Parent = Character_2
Character_backPAGE1.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Character_backPAGE1.BorderSizePixel = 0
Character_backPAGE1.Position = UDim2.new(0.0679230243, 0, 0.0439298227, 0)
Character_backPAGE1.Size = UDim2.new(0.113205045, 0, 0.109824568, 0)
Character_backPAGE1.Font = Enum.Font.SourceSansLight
Character_backPAGE1.FontSize = Enum.FontSize.Size24
Character_backPAGE1.Text = "Prev"
Character_backPAGE1.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Character_backPAGE1.TextSize = 22

Character_toPAGE1_IMAGE.Name = "Character_toPAGE1_IMAGE"
Character_toPAGE1_IMAGE.Parent = Character_backPAGE1
Character_toPAGE1_IMAGE.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Character_toPAGE1_IMAGE.BorderSizePixel = 0
Character_toPAGE1_IMAGE.Position = UDim2.new(-0.400293052, 0, 0, 0)
Character_toPAGE1_IMAGE.Size = UDim2.new(0, 25, 0, 25)
Character_toPAGE1_IMAGE.Image = "http://www.roblox.com/asset/?id=1282894968"

Animations_DANCE.Name = "Animations_DANCE"
Animations_DANCE.Parent = Character_2
Animations_DANCE.BackgroundColor3 = Color3.new(0.827451, 0.329412, 0)
Animations_DANCE.BorderSizePixel = 0
Animations_DANCE.Position = UDim2.new(0.407538146, 0, 0.263578951, 0)
Animations_DANCE.Size = UDim2.new(0.200000003, 0, 0.735000014, 0)

dancetitle.Name = "dancetitle"
dancetitle.Parent = Animations_DANCE
dancetitle.BackgroundColor3 = Color3.new(1, 1, 1)
dancetitle.BackgroundTransparency = 1
dancetitle.Position = UDim2.new(0, 0, 0.0298095234, 0)
dancetitle.Size = UDim2.new(0.96661669, 0, 0.149047628, 0)
dancetitle.Font = Enum.Font.SourceSansLight
dancetitle.FontSize = Enum.FontSize.Size28
dancetitle.Text = "Dance"
dancetitle.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
dancetitle.TextSize = 25

normal.Name = "normal"
normal.Parent = Animations_DANCE
normal.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
normal.BorderSizePixel = 0
normal.Position = UDim2.new(0, 0, 0.238476187, 0)
normal.Size = UDim2.new(1, 0, 0.119000003, 0)
normal.Font = Enum.Font.SourceSans
normal.FontSize = Enum.FontSize.Size14
normal.Text = "Normal"
normal.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
normal.TextScaled = true
normal.TextSize = 14
normal.TextWrapped = true

movingdance.Name = "movingdance"
movingdance.Parent = Animations_DANCE
movingdance.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
movingdance.BorderSizePixel = 0
movingdance.Position = UDim2.new(0, 0, 0.3875238, 0)
movingdance.Size = UDim2.new(1, 0, 0.119000003, 0)
movingdance.Font = Enum.Font.SourceSans
movingdance.FontSize = Enum.FontSize.Size14
movingdance.Text = "Moving Dance"
movingdance.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
movingdance.TextScaled = true
movingdance.TextSize = 14
movingdance.TextWrapped = true

insane.Name = "insane"
insane.Parent = Animations_DANCE
insane.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
insane.BorderSizePixel = 0
insane.Position = UDim2.new(0, 0, 0.834666669, 0)
insane.Size = UDim2.new(1, 0, 0.119000003, 0)
insane.Font = Enum.Font.SourceSans
insane.FontSize = Enum.FontSize.Size14
insane.Text = "Insane"
insane.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
insane.TextScaled = true
insane.TextSize = 14
insane.TextWrapped = true

happy.Name = "happy"
happy.Parent = Animations_DANCE
happy.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
happy.BorderSizePixel = 0
happy.Position = UDim2.new(0, 0, 0.536571383, 0)
happy.Size = UDim2.new(1, 0, 0.119000003, 0)
happy.Font = Enum.Font.SourceSans
happy.FontSize = Enum.FontSize.Size14
happy.Text = "Happy"
happy.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
happy.TextScaled = true
happy.TextSize = 14
happy.TextWrapped = true

spindance.Name = "spindance"
spindance.Parent = Animations_DANCE
spindance.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
spindance.BorderSizePixel = 0
spindance.Position = UDim2.new(0, 0, 0.685619056, 0)
spindance.Size = UDim2.new(1, 0, 0.119000003, 0)
spindance.Font = Enum.Font.SourceSans
spindance.FontSize = Enum.FontSize.Size14
spindance.Text = "Spin Dance"
spindance.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
spindance.TextScaled = true
spindance.TextSize = 14
spindance.TextWrapped = true

Animations_HEROIC.Name = "Animations_HEROIC"
Animations_HEROIC.Parent = Character_2
Animations_HEROIC.BackgroundColor3 = Color3.new(0.827451, 0.329412, 0)
Animations_HEROIC.BorderSizePixel = 0
Animations_HEROIC.Position = UDim2.new(0.713191807, 0, 0.263578951, 0)
Animations_HEROIC.Size = UDim2.new(0.200000003, 0, 0.735000014, 0)

heroictitle.Name = "heroictitle"
heroictitle.Parent = Animations_HEROIC
heroictitle.BackgroundColor3 = Color3.new(1, 1, 1)
heroictitle.BackgroundTransparency = 1
heroictitle.Position = UDim2.new(0, 0, 0.0298095234, 0)
heroictitle.Size = UDim2.new(0.96661669, 0, 0.149047628, 0)
heroictitle.Font = Enum.Font.SourceSansLight
heroictitle.FontSize = Enum.FontSize.Size28
heroictitle.Text = "Heroic"
heroictitle.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
heroictitle.TextSize = 25

swordstrike.Name = "swordstrike"
swordstrike.Parent = Animations_HEROIC
swordstrike.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
swordstrike.BorderSizePixel = 0
swordstrike.Position = UDim2.new(0, 0, 0.238476187, 0)
swordstrike.Size = UDim2.new(1, 0, 0.119000003, 0)
swordstrike.Font = Enum.Font.SourceSans
swordstrike.FontSize = Enum.FontSize.Size14
swordstrike.Text = "Sword Strike"
swordstrike.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
swordstrike.TextScaled = true
swordstrike.TextSize = 14
swordstrike.TextWrapped = true

jumpland.Name = "jumpland"
jumpland.Parent = Animations_HEROIC
jumpland.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
jumpland.BorderSizePixel = 0
jumpland.Position = UDim2.new(0, 0, 0.3875238, 0)
jumpland.Size = UDim2.new(1, 0, 0.119000003, 0)
jumpland.Font = Enum.Font.SourceSans
jumpland.FontSize = Enum.FontSize.Size14
jumpland.Text = "Jump Land"
jumpland.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
jumpland.TextScaled = true
jumpland.TextSize = 14
jumpland.TextWrapped = true

punches.Name = "punches"
punches.Parent = Animations_HEROIC
punches.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
punches.BorderSizePixel = 0
punches.Position = UDim2.new(0, 0, 0.834666669, 0)
punches.Size = UDim2.new(1, 0, 0.119000003, 0)
punches.Font = Enum.Font.SourceSans
punches.FontSize = Enum.FontSize.Size14
punches.Text = "Punches"
punches.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
punches.TextScaled = true
punches.TextSize = 14
punches.TextWrapped = true

swing.Name = "swing"
swing.Parent = Animations_HEROIC
swing.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
swing.BorderSizePixel = 0
swing.Position = UDim2.new(0, 0, 0.536571383, 0)
swing.Size = UDim2.new(1, 0, 0.119000003, 0)
swing.Font = Enum.Font.SourceSans
swing.FontSize = Enum.FontSize.Size14
swing.Text = "Swing"
swing.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
swing.TextScaled = true
swing.TextSize = 14
swing.TextWrapped = true

crawl.Name = "crawl"
crawl.Parent = Animations_HEROIC
crawl.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
crawl.BorderSizePixel = 0
crawl.Position = UDim2.new(0, 0, 0.685619056, 0)
crawl.Size = UDim2.new(1, 0, 0.119000003, 0)
crawl.Font = Enum.Font.SourceSans
crawl.FontSize = Enum.FontSize.Size14
crawl.Text = "Crawl"
crawl.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
crawl.TextScaled = true
crawl.TextSize = 14
crawl.TextWrapped = true

Char2_Image.Name = "Char2_Image"
Char2_Image.Parent = Character_2
Char2_Image.BackgroundColor3 = Color3.new(1, 1, 1)
Char2_Image.BackgroundTransparency = 1
Char2_Image.Position = UDim2.new(0.792435288, 0, 0.0219649114, 0)
Char2_Image.Size = UDim2.new(0.101884536, 0, 0.197684199, 0)
Char2_Image.Image = "http://www.roblox.com/asset/?id=1282931168"

Character_1.Name = "Character_1"
Character_1.Parent = Pages
Character_1.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Character_1.BorderSizePixel = 0
Character_1.Position = UDim2.new(11, 0, 0, 0)
Character_1.Size = UDim2.new(1, 0, 1, 0)

CharacterTitle_2.Name = "CharacterTitle"
CharacterTitle_2.Parent = Character_1
CharacterTitle_2.BackgroundColor3 = Color3.new(1, 1, 1)
CharacterTitle_2.BackgroundTransparency = 1
CharacterTitle_2.Position = UDim2.new(0.226410091, 0, 0, 0)
CharacterTitle_2.Size = UDim2.new(0.522657692, 0, 0.1364429, 0)
CharacterTitle_2.Font = Enum.Font.SourceSansBold
CharacterTitle_2.FontSize = Enum.FontSize.Size28
CharacterTitle_2.Text = "Character"
CharacterTitle_2.TextSize = 25

Char_Image_2.Name = "Char_Image"
Char_Image_2.Parent = Character_1
Char_Image_2.BackgroundColor3 = Color3.new(1, 1, 1)
Char_Image_2.BackgroundTransparency = 1
Char_Image_2.Position = UDim2.new(0.0792435333, 0, 0.109824568, 0)
Char_Image_2.Size = UDim2.new(0.0908969939, 0, 0.175596073, 0)
Char_Image_2.Image = "http://www.roblox.com/asset/?id=1281299598"

CharacterText_2.Name = "CharacterText"
CharacterText_2.Parent = Character_1
CharacterText_2.BackgroundColor3 = Color3.new(1, 1, 1)
CharacterText_2.BackgroundTransparency = 1
CharacterText_2.Position = UDim2.new(0.147166565, 0, 0.109824568, 0)
CharacterText_2.Size = UDim2.new(0.679230273, 0, 0.175719291, 0)
CharacterText_2.Font = Enum.Font.SourceSansItalic
CharacterText_2.FontSize = Enum.FontSize.Size24
CharacterText_2.Text = "Change your character's speed and other stats, give yourself fly, noclip and more!"
CharacterText_2.TextSize = 19
CharacterText_2.TextWrapped = true

TXTBOX_Stats.Name = "TXTBOX_Stats"
TXTBOX_Stats.Parent = Character_1
TXTBOX_Stats.BackgroundColor3 = Color3.new(0.956863, 0.968628, 0.972549)
TXTBOX_Stats.BorderColor3 = Color3.new(0.152941, 0.682353, 0.376471)
TXTBOX_Stats.BorderSizePixel = 6
TXTBOX_Stats.Position = UDim2.new(0.0905640349, 0, 0.373403519, 0)
TXTBOX_Stats.Size = UDim2.new(0.18112807, 0, 0.0878596455, 0)
TXTBOX_Stats.Font = Enum.Font.SourceSans
TXTBOX_Stats.FontSize = Enum.FontSize.Size14
TXTBOX_Stats.Text = "Number"
TXTBOX_Stats.TextScaled = true
TXTBOX_Stats.TextSize = 14
TXTBOX_Stats.TextWrapped = true

BackGroundChar.Name = "BackGroundChar"
BackGroundChar.Parent = Character_1
BackGroundChar.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
BackGroundChar.BorderSizePixel = 0
BackGroundChar.Position = UDim2.new(0.0769999996, 0, 0.48300001, 0)
BackGroundChar.Size = UDim2.new(0, 92, 0, 118)

HipHeight.Name = "HipHeight"
HipHeight.Parent = BackGroundChar
HipHeight.BackgroundColor3 = Color3.new(0.180392, 0.8, 0.443137)
HipHeight.BorderSizePixel = 0
HipHeight.Position = UDim2.new(0, 0, 0.679050863, 0)
HipHeight.Size = UDim2.new(0, 92, 0, 25)
HipHeight.Font = Enum.Font.SourceSans
HipHeight.FontSize = Enum.FontSize.Size24
HipHeight.Text = "HipHeight"
HipHeight.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
HipHeight.TextSize = 22

JumpHeight.Name = "JumpHeight"
JumpHeight.Parent = BackGroundChar
JumpHeight.BackgroundColor3 = Color3.new(0.180392, 0.8, 0.443137)
JumpHeight.BorderSizePixel = 0
JumpHeight.Position = UDim2.new(0, 0, 0.381966084, 0)
JumpHeight.Size = UDim2.new(0, 92, 0, 25)
JumpHeight.Font = Enum.Font.SourceSans
JumpHeight.FontSize = Enum.FontSize.Size24
JumpHeight.Text = "JumpHeight"
JumpHeight.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
JumpHeight.TextSize = 20

Speed.Name = "Speed"
Speed.Parent = BackGroundChar
Speed.BackgroundColor3 = Color3.new(0.180392, 0.8, 0.443137)
Speed.BorderSizePixel = 0
Speed.Position = UDim2.new(0, 0, 0.0848813578, 0)
Speed.Size = UDim2.new(0, 92, 0, 25)
Speed.Font = Enum.Font.SourceSans
Speed.FontSize = Enum.FontSize.Size24
Speed.Text = "Speed"
Speed.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Speed.TextSize = 22

TXTBOX_Chat.Name = "TXTBOX_Chat"
TXTBOX_Chat.Parent = Character_1
TXTBOX_Chat.BackgroundColor3 = Color3.new(0.956863, 0.968628, 0.972549)
TXTBOX_Chat.BorderColor3 = Color3.new(0.152941, 0.682353, 0.376471)
TXTBOX_Chat.BorderSizePixel = 6
TXTBOX_Chat.Position = UDim2.new(0.384897143, 0, 0.373403519, 0)
TXTBOX_Chat.Size = UDim2.new(0.520743191, 0, 0.0878596455, 0)
TXTBOX_Chat.Font = Enum.Font.SourceSans
TXTBOX_Chat.FontSize = Enum.FontSize.Size14
TXTBOX_Chat.Text = "Text for chatting"
TXTBOX_Chat.TextScaled = true
TXTBOX_Chat.TextSize = 14
TXTBOX_Chat.TextWrapped = true

BackGroundChar2.Name = "BackGroundChar2"
BackGroundChar2.Parent = Character_1
BackGroundChar2.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
BackGroundChar2.BorderSizePixel = 0
BackGroundChar2.Position = UDim2.new(0.370000005, 0, 0.48300001, 0)
BackGroundChar2.Size = UDim2.new(0, 242, 0, 40)

Chat.Name = "Chat"
Chat.Parent = BackGroundChar2
Chat.BackgroundColor3 = Color3.new(0.180392, 0.8, 0.443137)
Chat.BorderSizePixel = 0
Chat.Position = UDim2.new(0.0620288812, 0, 0.125200003, 0)
Chat.Size = UDim2.new(0, 92, 0, 25)
Chat.Font = Enum.Font.SourceSans
Chat.FontSize = Enum.FontSize.Size24
Chat.Text = "Chat"
Chat.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Chat.TextSize = 22

Spam_2.Name = "Spam"
Spam_2.Parent = BackGroundChar2
Spam_2.BackgroundColor3 = Color3.new(0.180392, 0.8, 0.443137)
Spam_2.BorderSizePixel = 0
Spam_2.Position = UDim2.new(0.558259964, 0, 0.125200003, 0)
Spam_2.Size = UDim2.new(0, 92, 0, 25)
Spam_2.Font = Enum.Font.SourceSans
Spam_2.FontSize = Enum.FontSize.Size24
Spam_2.Text = "Spam"
Spam_2.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Spam_2.TextSize = 22

BackGroundChar3.Name = "BackGroundChar3"
BackGroundChar3.Parent = Character_1
BackGroundChar3.BackgroundColor3 = Color3.new(0.0862745, 0.627451, 0.521569)
BackGroundChar3.BorderSizePixel = 0
BackGroundChar3.Position = UDim2.new(0.372000009, 0, 0.742999971, 0)
BackGroundChar3.Size = UDim2.new(0, 242, 0, 43)

Noclip.Name = "Noclip"
Noclip.Parent = BackGroundChar3
Noclip.BackgroundColor3 = Color3.new(0.101961, 0.737255, 0.611765)
Noclip.BorderSizePixel = 0
Noclip.Position = UDim2.new(0.558000028, 0, 0.208000004, 0)
Noclip.Size = UDim2.new(0, 92, 0, 25)
Noclip.Font = Enum.Font.SourceSans
Noclip.FontSize = Enum.FontSize.Size24
Noclip.Text = "Noclip"
Noclip.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Noclip.TextSize = 22

Fly.Name = "Fly"
Fly.Parent = BackGroundChar3
Fly.BackgroundColor3 = Color3.new(0.101961, 0.737255, 0.611765)
Fly.BorderSizePixel = 0
Fly.Position = UDim2.new(0.061999999, 0, 0.208000004, 0)
Fly.Size = UDim2.new(0, 92, 0, 25)
Fly.Font = Enum.Font.SourceSans
Fly.FontSize = Enum.FontSize.Size24
Fly.Text = "Fly"
Fly.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Fly.TextSize = 22

Character_toPAGE2.Name = "Character_toPAGE2"
Character_toPAGE2.Parent = Character_1
Character_toPAGE2.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Character_toPAGE2.BorderSizePixel = 0
Character_toPAGE2.Position = UDim2.new(0.819999993, 0, 0.0439999998, 0)
Character_toPAGE2.Size = UDim2.new(0.113205045, 0, 0.109824568, 0)
Character_toPAGE2.Font = Enum.Font.SourceSansLight
Character_toPAGE2.FontSize = Enum.FontSize.Size24
Character_toPAGE2.Text = "Next"
Character_toPAGE2.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Character_toPAGE2.TextSize = 22

Character_toPAGE2_IMAGE_2.Name = "Character_toPAGE2_IMAGE"
Character_toPAGE2_IMAGE_2.Parent = Character_toPAGE2
Character_toPAGE2_IMAGE_2.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Character_toPAGE2_IMAGE_2.BorderSizePixel = 0
Character_toPAGE2_IMAGE_2.Position = UDim2.new(0.900659323, 0, 0, 0)
Character_toPAGE2_IMAGE_2.Size = UDim2.new(0, 25, 0, 25)
Character_toPAGE2_IMAGE_2.Image = "http://www.roblox.com/asset/?id=1282737326"

Others_2.Name = "Others_2"
Others_2.Parent = Pages
Others_2.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Others_2.BorderSizePixel = 0
Others_2.Position = UDim2.new(1, 0, 0, 0)
Others_2.Size = UDim2.new(1, 0, 1, 0)

OthersTitle_2.Name = "OthersTitle"
OthersTitle_2.Parent = Others_2
OthersTitle_2.BackgroundColor3 = Color3.new(1, 1, 1)
OthersTitle_2.BackgroundTransparency = 1
OthersTitle_2.Position = UDim2.new(0.226410091, 0, 0, 0)
OthersTitle_2.Size = UDim2.new(0.522657692, 0, 0.1364429, 0)
OthersTitle_2.Font = Enum.Font.SourceSansBold
OthersTitle_2.FontSize = Enum.FontSize.Size28
OthersTitle_2.Text = "Others"
OthersTitle_2.TextSize = 25

Other_Image2.Name = "Other_Image2"
Other_Image2.Parent = Others_2
Other_Image2.BackgroundColor3 = Color3.new(1, 1, 1)
Other_Image2.BackgroundTransparency = 1
Other_Image2.Position = UDim2.new(0.0113205044, 0, 0.197684199, 0)
Other_Image2.Size = UDim2.new(0.101884536, 0, 0.197684199, 0)
Other_Image2.Image = "http://www.roblox.com/asset/?id=1284941440"

OthersText_2.Name = "OthersText"
OthersText_2.Parent = Others_2
OthersText_2.BackgroundColor3 = Color3.new(1, 1, 1)
OthersText_2.BackgroundTransparency = 1
OthersText_2.Position = UDim2.new(0.203769073, 0, 0.109824568, 0)
OthersText_2.Size = UDim2.new(0.577345729, 0, 0.175719291, 0)
OthersText_2.Font = Enum.Font.SourceSansItalic
OthersText_2.FontSize = Enum.FontSize.Size24
OthersText_2.Text = "Use rocket propulsion to push, fling, and annoy players!"
OthersText_2.TextSize = 19
OthersText_2.TextWrapped = true

TXTBOX_PlrName2.Name = "TXTBOX_PlrName2"
TXTBOX_PlrName2.Parent = Others_2
TXTBOX_PlrName2.BackgroundColor3 = Color3.new(0.956863, 0.968628, 0.972549)
TXTBOX_PlrName2.BorderColor3 = Color3.new(0.152941, 0.682353, 0.376471)
TXTBOX_PlrName2.BorderSizePixel = 0
TXTBOX_PlrName2.Position = UDim2.new(0.249051109, 0, 0.395368397, 0)
TXTBOX_PlrName2.Size = UDim2.new(0.520743191, 0, 0.0878596455, 0)
TXTBOX_PlrName2.ZIndex = 2
TXTBOX_PlrName2.Font = Enum.Font.SourceSans
TXTBOX_PlrName2.FontSize = Enum.FontSize.Size14
TXTBOX_PlrName2.Text = "Player"
TXTBOX_PlrName2.TextScaled = true
TXTBOX_PlrName2.TextSize = 14
TXTBOX_PlrName2.TextWrapped = true

othersBaseBackground2.Name = "othersBaseBackground2"
othersBaseBackground2.Parent = Others_2
othersBaseBackground2.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
othersBaseBackground2.BorderSizePixel = 0
othersBaseBackground2.Position = UDim2.new(0.124525554, 0, 0.351438582, 0)
othersBaseBackground2.Size = UDim2.new(0.769999981, 0, 0.649999976, 0)

Flatten.Name = "Flatten"
Flatten.Parent = othersBaseBackground2
Flatten.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
Flatten.BorderSizePixel = 0
Flatten.Position = UDim2.new(0.0588666238, 0, 0.27070269, 0)
Flatten.Size = UDim2.new(0, 92, 0, 25)
Flatten.Font = Enum.Font.SourceSans
Flatten.FontSize = Enum.FontSize.Size24
Flatten.Text = "Flatten"
Flatten.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Flatten.TextSize = 22

AimHead.Name = "AimHead"
AimHead.Parent = othersBaseBackground2
AimHead.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
AimHead.BorderSizePixel = 0
AimHead.Position = UDim2.new(0.367916405, 0, 0.27070269, 0)
AimHead.Size = UDim2.new(0, 92, 0, 25)
AimHead.Font = Enum.Font.SourceSans
AimHead.FontSize = Enum.FontSize.Size24
AimHead.Text = "Aim Head"
AimHead.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
AimHead.TextSize = 22

Float.Name = "Float"
Float.Parent = othersBaseBackground2
Float.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
Float.BorderSizePixel = 0
Float.Position = UDim2.new(0.0588666238, 0, 0.507567585, 0)
Float.Size = UDim2.new(0, 92, 0, 25)
Float.Font = Enum.Font.SourceSans
Float.FontSize = Enum.FontSize.Size24
Float.Text = "Float"
Float.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Float.TextSize = 22

Multiple.Name = "Multiple"
Multiple.Parent = othersBaseBackground2
Multiple.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
Multiple.BorderSizePixel = 0
Multiple.Position = UDim2.new(0.367916405, 0, 0.507567585, 0)
Multiple.Size = UDim2.new(0, 92, 0, 25)
Multiple.Font = Enum.Font.SourceSans
Multiple.FontSize = Enum.FontSize.Size24
Multiple.Text = "Multiple"
Multiple.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Multiple.TextSize = 22

Animated.Name = "Animated"
Animated.Parent = othersBaseBackground2
Animated.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
Animated.BorderSizePixel = 0
Animated.Position = UDim2.new(0.67696619, 0, 0.27070269, 0)
Animated.Size = UDim2.new(0, 92, 0, 25)
Animated.Font = Enum.Font.SourceSans
Animated.FontSize = Enum.FontSize.Size24
Animated.Text = "Animated"
Animated.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Animated.TextSize = 22

SlowAttract.Name = "SlowAttract"
SlowAttract.Parent = othersBaseBackground2
SlowAttract.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
SlowAttract.BorderSizePixel = 0
SlowAttract.Position = UDim2.new(0.67696619, 0, 0.507567585, 0)
SlowAttract.Size = UDim2.new(0, 92, 0, 25)
SlowAttract.Font = Enum.Font.SourceSans
SlowAttract.FontSize = Enum.FontSize.Size24
SlowAttract.Text = "SlowAttract"
SlowAttract.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
SlowAttract.TextSize = 22

WeirdOrbit.Name = "WeirdOrbit"
WeirdOrbit.Parent = othersBaseBackground2
WeirdOrbit.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
WeirdOrbit.BorderSizePixel = 0
WeirdOrbit.Position = UDim2.new(0.67696619, 0, 0.744432449, 0)
WeirdOrbit.Size = UDim2.new(0, 92, 0, 25)
WeirdOrbit.Font = Enum.Font.SourceSans
WeirdOrbit.FontSize = Enum.FontSize.Size24
WeirdOrbit.Text = "Weird Orbit"
WeirdOrbit.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
WeirdOrbit.TextSize = 22

Violent.Name = "Violent"
Violent.Parent = othersBaseBackground2
Violent.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
Violent.BorderSizePixel = 0
Violent.Position = UDim2.new(0.367916405, 0, 0.744432449, 0)
Violent.Size = UDim2.new(0, 92, 0, 25)
Violent.Font = Enum.Font.SourceSans
Violent.FontSize = Enum.FontSize.Size24
Violent.Text = "Violent"
Violent.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Violent.TextSize = 22

Max.Name = "Max"
Max.Parent = othersBaseBackground2
Max.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
Max.BorderSizePixel = 0
Max.Position = UDim2.new(0.0588666238, 0, 0.744432449, 0)
Max.Size = UDim2.new(0, 92, 0, 25)
Max.Font = Enum.Font.SourceSans
Max.FontSize = Enum.FontSize.Size24
Max.Text = "Max"
Max.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Max.TextSize = 22

Others_toPAGE3.Name = "Others_toPAGE3"
Others_toPAGE3.Parent = Others_2
Others_toPAGE3.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Others_toPAGE3.BorderSizePixel = 0
Others_toPAGE3.Position = UDim2.new(0.819999993, 0, 0.0439999998, 0)
Others_toPAGE3.Size = UDim2.new(0.113205045, 0, 0.109824568, 0)
Others_toPAGE3.Font = Enum.Font.SourceSansLight
Others_toPAGE3.FontSize = Enum.FontSize.Size24
Others_toPAGE3.Text = "Next"
Others_toPAGE3.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Others_toPAGE3.TextSize = 22

Character_toPAGE3_IMAGE.Name = "Character_toPAGE3_IMAGE"
Character_toPAGE3_IMAGE.Parent = Others_toPAGE3
Character_toPAGE3_IMAGE.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Character_toPAGE3_IMAGE.BorderSizePixel = 0
Character_toPAGE3_IMAGE.Position = UDim2.new(0.900659323, 0, 0, 0)
Character_toPAGE3_IMAGE.Size = UDim2.new(0, 25, 0, 25)
Character_toPAGE3_IMAGE.Image = "http://www.roblox.com/asset/?id=1282737326"

Others_backPAGE1.Name = "Others_backPAGE1"
Others_backPAGE1.Parent = Others_2
Others_backPAGE1.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Others_backPAGE1.BorderSizePixel = 0
Others_backPAGE1.Position = UDim2.new(0.0679230243, 0, 0.0439298227, 0)
Others_backPAGE1.Size = UDim2.new(0.113205045, 0, 0.109824568, 0)
Others_backPAGE1.Font = Enum.Font.SourceSansLight
Others_backPAGE1.FontSize = Enum.FontSize.Size24
Others_backPAGE1.Text = "Prev"
Others_backPAGE1.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Others_backPAGE1.TextSize = 22

Character_toPAGE1_IMAGE_2.Name = "Character_toPAGE1_IMAGE"
Character_toPAGE1_IMAGE_2.Parent = Others_backPAGE1
Character_toPAGE1_IMAGE_2.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Character_toPAGE1_IMAGE_2.BorderSizePixel = 0
Character_toPAGE1_IMAGE_2.Position = UDim2.new(-0.400293052, 0, 0, 0)
Character_toPAGE1_IMAGE_2.Size = UDim2.new(0, 25, 0, 25)
Character_toPAGE1_IMAGE_2.Image = "http://www.roblox.com/asset/?id=1282894968"

Extra_1.Name = "Extra_1"
Extra_1.Parent = Pages
Extra_1.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Extra_1.BorderSizePixel = 0
Extra_1.Position = UDim2.new(1, 0, 0, 0)
Extra_1.Size = UDim2.new(1, 0, 1, 0)

Extra_Image.Name = "Extra_Image"
Extra_Image.Parent = Extra_1
Extra_Image.BackgroundColor3 = Color3.new(1, 1, 1)
Extra_Image.BackgroundTransparency = 1
Extra_Image.Position = UDim2.new(0.0679230243, 0, 0.0439298227, 0)
Extra_Image.Size = UDim2.new(0.0908969939, 0, 0.175596073, 0)
Extra_Image.Image = "http://www.roblox.com/asset/?id=1281477720"

ExtraText.Name = "ExtraText"
ExtraText.Parent = Extra_1
ExtraText.BackgroundColor3 = Color3.new(1, 1, 1)
ExtraText.BackgroundTransparency = 1
ExtraText.Position = UDim2.new(0.158487067, 0, 0.109824568, 0)
ExtraText.Size = UDim2.new(0.65658927, 0, 0.0878596455, 0)
ExtraText.Font = Enum.Font.SourceSansItalic
ExtraText.FontSize = Enum.FontSize.Size24
ExtraText.Text = "Cool and unique commands for yourself!"
ExtraText.TextSize = 19
ExtraText.TextWrapped = true

ExtraBaseBackGround1.Name = "ExtraBaseBackGround1"
ExtraBaseBackGround1.Parent = Extra_1
ExtraBaseBackGround1.BackgroundColor3 = Color3.new(0.945098, 0.768628, 0.0588235)
ExtraBaseBackGround1.BorderSizePixel = 0
ExtraBaseBackGround1.Position = UDim2.new(0.0790000036, 0, 0.400000006, 0)
ExtraBaseBackGround1.Size = UDim2.new(0.25, 0, 0.600000024, 0)

CrouchRocket.Name = "CrouchRocket"
CrouchRocket.Parent = ExtraBaseBackGround1
CrouchRocket.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
CrouchRocket.BorderSizePixel = 0
CrouchRocket.Position = UDim2.new(0.0901560932, 0, 0.0731094852, 0)
CrouchRocket.Size = UDim2.new(0, 92, 0, 25)
CrouchRocket.Font = Enum.Font.SourceSans
CrouchRocket.FontSize = Enum.FontSize.Size18
CrouchRocket.Text = "Crouch Rocket"
CrouchRocket.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
CrouchRocket.TextSize = 17

ExtraBaseBackGround1Side.Name = "ExtraBaseBackGround1Side"
ExtraBaseBackGround1Side.Parent = ExtraBaseBackGround1
ExtraBaseBackGround1Side.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
ExtraBaseBackGround1Side.BorderSizePixel = 0
ExtraBaseBackGround1Side.Position = UDim2.new(0, 0, -0.109664232, 0)
ExtraBaseBackGround1Side.Size = UDim2.new(1, 0, 0.109999999, 0)

CloneIllusion.Name = "CloneIllusion"
CloneIllusion.Parent = ExtraBaseBackGround1
CloneIllusion.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
CloneIllusion.BorderSizePixel = 0
CloneIllusion.Position = UDim2.new(0.0901560932, 0, 0.292437941, 0)
CloneIllusion.Size = UDim2.new(0, 92, 0, 25)
CloneIllusion.Font = Enum.Font.SourceSans
CloneIllusion.FontSize = Enum.FontSize.Size18
CloneIllusion.Text = "Clone Illusion"
CloneIllusion.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
CloneIllusion.TextSize = 17

CoolSpin.Name = "CoolSpin"
CoolSpin.Parent = ExtraBaseBackGround1
CoolSpin.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
CoolSpin.BorderSizePixel = 0
CoolSpin.Position = UDim2.new(0.0901560932, 0, 0.511766434, 0)
CoolSpin.Size = UDim2.new(0, 92, 0, 25)
CoolSpin.Font = Enum.Font.SourceSans
CoolSpin.FontSize = Enum.FontSize.Size18
CoolSpin.Text = "Cool Spin"
CoolSpin.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
CoolSpin.TextSize = 17

JumpRocket.Name = "JumpRocket"
JumpRocket.Parent = ExtraBaseBackGround1
JumpRocket.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
JumpRocket.BorderSizePixel = 0
JumpRocket.Position = UDim2.new(0.0901560932, 0, 0.731094897, 0)
JumpRocket.Size = UDim2.new(0, 92, 0, 25)
JumpRocket.Font = Enum.Font.SourceSans
JumpRocket.FontSize = Enum.FontSize.Size18
JumpRocket.Text = "Jump Rocket"
JumpRocket.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
JumpRocket.TextSize = 17

Extra_toPAGE2.Name = "Extra_toPAGE2"
Extra_toPAGE2.Parent = Extra_1
Extra_toPAGE2.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Extra_toPAGE2.BorderSizePixel = 0
Extra_toPAGE2.Position = UDim2.new(0.819999993, 0, 0.0439999998, 0)
Extra_toPAGE2.Size = UDim2.new(0.113205045, 0, 0.109824568, 0)
Extra_toPAGE2.Font = Enum.Font.SourceSansLight
Extra_toPAGE2.FontSize = Enum.FontSize.Size24
Extra_toPAGE2.Text = "Next"
Extra_toPAGE2.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Extra_toPAGE2.TextSize = 22

Character_toPAGE2_IMAGE_3.Name = "Character_toPAGE2_IMAGE"
Character_toPAGE2_IMAGE_3.Parent = Extra_toPAGE2
Character_toPAGE2_IMAGE_3.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Character_toPAGE2_IMAGE_3.BorderSizePixel = 0
Character_toPAGE2_IMAGE_3.Position = UDim2.new(0.900659323, 0, 0, 0)
Character_toPAGE2_IMAGE_3.Size = UDim2.new(0, 25, 0, 25)
Character_toPAGE2_IMAGE_3.Image = "http://www.roblox.com/asset/?id=1282737326"

Extra_Title.Name = "Extra_Title"
Extra_Title.Parent = Extra_1
Extra_Title.BackgroundColor3 = Color3.new(1, 1, 1)
Extra_Title.BackgroundTransparency = 1
Extra_Title.Position = UDim2.new(0.226410091, 0, 0, 0)
Extra_Title.Size = UDim2.new(0.522657692, 0, 0.1364429, 0)
Extra_Title.Font = Enum.Font.SourceSansBold
Extra_Title.FontSize = Enum.FontSize.Size28
Extra_Title.Text = "Extra"
Extra_Title.TextSize = 25

ExtraBaseBackGround2.Name = "ExtraBaseBackGround2"
ExtraBaseBackGround2.Parent = Extra_1
ExtraBaseBackGround2.BackgroundColor3 = Color3.new(0.101961, 0.737255, 0.611765)
ExtraBaseBackGround2.BorderSizePixel = 0
ExtraBaseBackGround2.Position = UDim2.new(0.374000013, 0, 0.400000006, 0)
ExtraBaseBackGround2.Size = UDim2.new(0.25, 0, 0.600000024, 0)

NoLimbs.Name = "NoLimbs"
NoLimbs.Parent = ExtraBaseBackGround2
NoLimbs.BackgroundColor3 = Color3.new(0.0862745, 0.627451, 0.521569)
NoLimbs.BorderSizePixel = 0
NoLimbs.Position = UDim2.new(0.0901560932, 0, 0.0731094852, 0)
NoLimbs.Size = UDim2.new(0, 92, 0, 25)
NoLimbs.Font = Enum.Font.SourceSans
NoLimbs.FontSize = Enum.FontSize.Size18
NoLimbs.Text = "No Limbs"
NoLimbs.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
NoLimbs.TextSize = 17

FEGodmode.Name = "FE Godmode"
FEGodmode.Parent = ExtraBaseBackGround2
FEGodmode.BackgroundColor3 = Color3.new(0.0862745, 0.627451, 0.521569)
FEGodmode.BorderSizePixel = 0
FEGodmode.Position = UDim2.new(0.0901560932, 0, 0.292437941, 0)
FEGodmode.Size = UDim2.new(0, 92, 0, 25)
FEGodmode.Font = Enum.Font.SourceSans
FEGodmode.FontSize = Enum.FontSize.Size18
FEGodmode.Text = "FE Godmode"
FEGodmode.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
FEGodmode.TextSize = 17

BrickHats.Name = "BrickHats"
BrickHats.Parent = ExtraBaseBackGround2
BrickHats.BackgroundColor3 = Color3.new(0.0862745, 0.627451, 0.521569)
BrickHats.BorderSizePixel = 0
BrickHats.Position = UDim2.new(0.0901560932, 0, 0.511766434, 0)
BrickHats.Size = UDim2.new(0, 92, 0, 25)
BrickHats.Font = Enum.Font.SourceSans
BrickHats.FontSize = Enum.FontSize.Size18
BrickHats.Text = "Brick Hats"
BrickHats.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
BrickHats.TextSize = 17

RapidPunch.Name = "RapidPunch"
RapidPunch.Parent = ExtraBaseBackGround2
RapidPunch.BackgroundColor3 = Color3.new(0.0862745, 0.627451, 0.521569)
RapidPunch.BorderSizePixel = 0
RapidPunch.Position = UDim2.new(0.0901560932, 0, 0.731094897, 0)
RapidPunch.Size = UDim2.new(0, 92, 0, 25)
RapidPunch.Font = Enum.Font.SourceSans
RapidPunch.FontSize = Enum.FontSize.Size18
RapidPunch.Text = "RapidPunch"
RapidPunch.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
RapidPunch.TextSize = 17

ExtraBaseBackGround2Side.Name = "ExtraBaseBackGround2Side"
ExtraBaseBackGround2Side.Parent = ExtraBaseBackGround2
ExtraBaseBackGround2Side.BackgroundColor3 = Color3.new(0.0862745, 0.627451, 0.521569)
ExtraBaseBackGround2Side.BorderSizePixel = 0
ExtraBaseBackGround2Side.Position = UDim2.new(0, 0, -0.109664232, 0)
ExtraBaseBackGround2Side.Size = UDim2.new(1, 0, 0.109999999, 0)

ExtraBaseBackGround3.Name = "ExtraBaseBackGround3"
ExtraBaseBackGround3.Parent = Extra_1
ExtraBaseBackGround3.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
ExtraBaseBackGround3.BorderSizePixel = 0
ExtraBaseBackGround3.Position = UDim2.new(0.667999983, 0, 0.400000006, 0)
ExtraBaseBackGround3.Size = UDim2.new(0.25, 0, 0.600000024, 0)

PunchFollow.Name = "PunchFollow"
PunchFollow.Parent = ExtraBaseBackGround3
PunchFollow.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
PunchFollow.BorderSizePixel = 0
PunchFollow.Position = UDim2.new(0.0901560932, 0, 0.0731094852, 0)
PunchFollow.Size = UDim2.new(0, 92, 0, 25)
PunchFollow.Font = Enum.Font.SourceSans
PunchFollow.FontSize = Enum.FontSize.Size18
PunchFollow.Text = "Punch Follow"
PunchFollow.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
PunchFollow.TextSize = 17

ArmFollow.Name = "ArmFollow"
ArmFollow.Parent = ExtraBaseBackGround3
ArmFollow.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
ArmFollow.BorderSizePixel = 0
ArmFollow.Position = UDim2.new(0.0901560932, 0, 0.292437941, 0)
ArmFollow.Size = UDim2.new(0, 92, 0, 25)
ArmFollow.Font = Enum.Font.SourceSans
ArmFollow.FontSize = Enum.FontSize.Size18
ArmFollow.Text = "Arm Follow"
ArmFollow.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
ArmFollow.TextSize = 17

Spin.Name = "Spin"
Spin.Parent = ExtraBaseBackGround3
Spin.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
Spin.BorderSizePixel = 0
Spin.Position = UDim2.new(0.0901560932, 0, 0.511766434, 0)
Spin.Size = UDim2.new(0, 92, 0, 25)
Spin.Font = Enum.Font.SourceSans
Spin.FontSize = Enum.FontSize.Size18
Spin.Text = "Spin"
Spin.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Spin.TextSize = 17

Faint.Name = "Faint"
Faint.Parent = ExtraBaseBackGround3
Faint.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
Faint.BorderSizePixel = 0
Faint.Position = UDim2.new(0.0901560932, 0, 0.731094897, 0)
Faint.Size = UDim2.new(0, 92, 0, 25)
Faint.Font = Enum.Font.SourceSans
Faint.FontSize = Enum.FontSize.Size18
Faint.Text = "Faint"
Faint.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Faint.TextSize = 17

ExtraBaseBackGround3Side.Name = "ExtraBaseBackGround3Side"
ExtraBaseBackGround3Side.Parent = ExtraBaseBackGround3
ExtraBaseBackGround3Side.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
ExtraBaseBackGround3Side.BorderSizePixel = 0
ExtraBaseBackGround3Side.Position = UDim2.new(0, 0, -0.109664232, 0)
ExtraBaseBackGround3Side.Size = UDim2.new(1, 0, 0.109999999, 0)

Extra_2.Name = "Extra_2"
Extra_2.Parent = Pages
Extra_2.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Extra_2.BorderSizePixel = 0
Extra_2.Position = UDim2.new(1, 0, 0, 0)
Extra_2.Size = UDim2.new(1, 0, 1, 0)

Extra_Image_2.Name = "Extra_Image"
Extra_Image_2.Parent = Extra_2
Extra_Image_2.BackgroundColor3 = Color3.new(1, 1, 1)
Extra_Image_2.BackgroundTransparency = 1
Extra_Image_2.Position = UDim2.new(0.80375582, 0, 0.0439298227, 0)
Extra_Image_2.Size = UDim2.new(0.0908969939, 0, 0.175596073, 0)
Extra_Image_2.Image = "http://www.roblox.com/asset/?id=1282931168"

ExtraText_2.Name = "ExtraText"
ExtraText_2.Parent = Extra_2
ExtraText_2.BackgroundColor3 = Color3.new(1, 1, 1)
ExtraText_2.BackgroundTransparency = 1
ExtraText_2.Position = UDim2.new(0.158487067, 0, 0.109824568, 0)
ExtraText_2.Size = UDim2.new(0.65658927, 0, 0.175719291, 0)
ExtraText_2.Font = Enum.Font.SourceSansItalic
ExtraText_2.FontSize = Enum.FontSize.Size24
ExtraText_2.Text = "Cool and unique commands for other players!"
ExtraText_2.TextSize = 19
ExtraText_2.TextWrapped = true

Extra_Title_2.Name = "Extra_Title"
Extra_Title_2.Parent = Extra_2
Extra_Title_2.BackgroundColor3 = Color3.new(1, 1, 1)
Extra_Title_2.BackgroundTransparency = 1
Extra_Title_2.Position = UDim2.new(0.226410091, 0, 0, 0)
Extra_Title_2.Size = UDim2.new(0.522657692, 0, 0.1364429, 0)
Extra_Title_2.Font = Enum.Font.SourceSansBold
Extra_Title_2.FontSize = Enum.FontSize.Size28
Extra_Title_2.Text = "Extra"
Extra_Title_2.TextSize = 25

ExtraBaseBackGround2_2.Name = "ExtraBaseBackGround2"
ExtraBaseBackGround2_2.Parent = Extra_2
ExtraBaseBackGround2_2.BackgroundColor3 = Color3.new(0.180392, 0.8, 0.443137)
ExtraBaseBackGround2_2.BorderSizePixel = 0
ExtraBaseBackGround2_2.Position = UDim2.new(0.158000007, 0, 0.38499999, 0)
ExtraBaseBackGround2_2.Size = UDim2.new(0.667909801, 0, 0.615017533, 0)

CrouchAttack.Name = "CrouchAttack"
CrouchAttack.Parent = ExtraBaseBackGround2_2
CrouchAttack.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
CrouchAttack.BorderSizePixel = 0
CrouchAttack.Position = UDim2.new(0.576693356, 0, 0.321942836, 0)
CrouchAttack.Size = UDim2.new(0, 92, 0, 25)
CrouchAttack.Font = Enum.Font.SourceSans
CrouchAttack.FontSize = Enum.FontSize.Size18
CrouchAttack.Text = "Crouch Attack"
CrouchAttack.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
CrouchAttack.TextSize = 17

WalkThrough.Name = "WalkThrough"
WalkThrough.Parent = ExtraBaseBackGround2_2
WalkThrough.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
WalkThrough.BorderSizePixel = 0
WalkThrough.Position = UDim2.new(0.118730992, 0, 0.536571443, 0)
WalkThrough.Size = UDim2.new(0, 92, 0, 25)
WalkThrough.Font = Enum.Font.SourceSans
WalkThrough.FontSize = Enum.FontSize.Size18
WalkThrough.Text = "Walk Through"
WalkThrough.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
WalkThrough.TextSize = 17

CreepyWatch.Name = "CreepyWatch"
CreepyWatch.Parent = ExtraBaseBackGround2_2
CreepyWatch.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
CreepyWatch.BorderSizePixel = 0
CreepyWatch.Position = UDim2.new(0.118730992, 0, 0.321942836, 0)
CreepyWatch.Size = UDim2.new(0, 92, 0, 25)
CreepyWatch.Font = Enum.Font.SourceSans
CreepyWatch.FontSize = Enum.FontSize.Size18
CreepyWatch.Text = "Creepy Watch"
CreepyWatch.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
CreepyWatch.TextSize = 17

SpinAttack.Name = "SpinAttack"
SpinAttack.Parent = ExtraBaseBackGround2_2
SpinAttack.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
SpinAttack.BorderSizePixel = 0
SpinAttack.Position = UDim2.new(0.576693356, 0, 0.536571443, 0)
SpinAttack.Size = UDim2.new(0, 92, 0, 25)
SpinAttack.Font = Enum.Font.SourceSans
SpinAttack.FontSize = Enum.FontSize.Size18
SpinAttack.Text = "Spin Attack"
SpinAttack.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
SpinAttack.TextSize = 17

ExtraBaseBackGround2Side_2.Name = "ExtraBaseBackGround2Side"
ExtraBaseBackGround2Side_2.Parent = ExtraBaseBackGround2_2
ExtraBaseBackGround2Side_2.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
ExtraBaseBackGround2Side_2.BorderSizePixel = 0
ExtraBaseBackGround2Side_2.Position = UDim2.new(0, 0, -0.109664232, 0)
ExtraBaseBackGround2Side_2.Size = UDim2.new(1, 0, 0.109999999, 0)

TXTBOX_PlrNameEXTRA.Name = "TXTBOX_PlrNameEXTRA"
TXTBOX_PlrNameEXTRA.Parent = ExtraBaseBackGround2_2
TXTBOX_PlrNameEXTRA.BackgroundColor3 = Color3.new(0.956863, 0.968628, 0.972549)
TXTBOX_PlrNameEXTRA.BorderColor3 = Color3.new(0.152941, 0.682353, 0.376471)
TXTBOX_PlrNameEXTRA.BorderSizePixel = 0
TXTBOX_PlrNameEXTRA.Position = UDim2.new(0.22050041, 0, 0.0715428591, 0)
TXTBOX_PlrNameEXTRA.Size = UDim2.new(0.559731781, 0, 0.143085718, 0)
TXTBOX_PlrNameEXTRA.ZIndex = 2
TXTBOX_PlrNameEXTRA.Font = Enum.Font.SourceSans
TXTBOX_PlrNameEXTRA.FontSize = Enum.FontSize.Size14
TXTBOX_PlrNameEXTRA.Text = "Player"
TXTBOX_PlrNameEXTRA.TextScaled = true
TXTBOX_PlrNameEXTRA.TextSize = 14
TXTBOX_PlrNameEXTRA.TextWrapped = true

_18.Name = "18+"
_18.Parent = ExtraBaseBackGround2_2
_18.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
_18.BorderSizePixel = 0
_18.Position = UDim2.new(0.576693356, 0, 0.75120002, 0)
_18.Size = UDim2.new(0, 92, 0, 25)
_18.Font = Enum.Font.SourceSans
_18.FontSize = Enum.FontSize.Size18
_18.Text = "18+"
_18.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
_18.TextSize = 17

SlamPropulsion.Name = "SlamPropulsion"
SlamPropulsion.Parent = ExtraBaseBackGround2_2
SlamPropulsion.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
SlamPropulsion.BorderSizePixel = 0
SlamPropulsion.Position = UDim2.new(0.118730992, 0, 0.75120002, 0)
SlamPropulsion.Size = UDim2.new(0, 92, 0, 25)
SlamPropulsion.Font = Enum.Font.SourceSans
SlamPropulsion.FontSize = Enum.FontSize.Size18
SlamPropulsion.Text = "Slam Propulsion"
SlamPropulsion.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
SlamPropulsion.TextSize = 15
SlamPropulsion.TextWrapped = true

Extra_backPAGE1.Name = "Extra_backPAGE1"
Extra_backPAGE1.Parent = Extra_2
Extra_backPAGE1.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Extra_backPAGE1.BorderSizePixel = 0
Extra_backPAGE1.Position = UDim2.new(0.0679230243, 0, 0.0439298227, 0)
Extra_backPAGE1.Size = UDim2.new(0.113205045, 0, 0.109824568, 0)
Extra_backPAGE1.Font = Enum.Font.SourceSansLight
Extra_backPAGE1.FontSize = Enum.FontSize.Size24
Extra_backPAGE1.Text = "Prev"
Extra_backPAGE1.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Extra_backPAGE1.TextSize = 22

Character_toPAGE1_IMAGE_3.Name = "Character_toPAGE1_IMAGE"
Character_toPAGE1_IMAGE_3.Parent = Extra_backPAGE1
Character_toPAGE1_IMAGE_3.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Character_toPAGE1_IMAGE_3.BorderSizePixel = 0
Character_toPAGE1_IMAGE_3.Position = UDim2.new(-0.400293052, 0, 0, 0)
Character_toPAGE1_IMAGE_3.Size = UDim2.new(0, 25, 0, 25)
Character_toPAGE1_IMAGE_3.Image = "http://www.roblox.com/asset/?id=1282894968"

Others_3.Name = "Others_3"
Others_3.Parent = Pages
Others_3.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Others_3.BorderSizePixel = 0
Others_3.Position = UDim2.new(1, 0, 0, 0)
Others_3.Size = UDim2.new(1, 0, 1, 0)

OthersTitle_3.Name = "OthersTitle"
OthersTitle_3.Parent = Others_3
OthersTitle_3.BackgroundColor3 = Color3.new(1, 1, 1)
OthersTitle_3.BackgroundTransparency = 1
OthersTitle_3.Position = UDim2.new(0.226410091, 0, 0, 0)
OthersTitle_3.Size = UDim2.new(0.522657692, 0, 0.1364429, 0)
OthersTitle_3.Font = Enum.Font.SourceSansBold
OthersTitle_3.FontSize = Enum.FontSize.Size28
OthersTitle_3.Text = "Others"
OthersTitle_3.TextSize = 25

Other_Image3.Name = "Other_Image3"
Other_Image3.Parent = Others_3
Other_Image3.BackgroundColor3 = Color3.new(1, 1, 1)
Other_Image3.BackgroundTransparency = 1
Other_Image3.Position = UDim2.new(0.124525554, 0, 0.219649136, 0)
Other_Image3.Size = UDim2.new(0.101884536, 0, 0.197684199, 0)
Other_Image3.Image = "http://www.roblox.com/asset/?id=1281286925"

OthersText_3.Name = "OthersText"
OthersText_3.Parent = Others_3
OthersText_3.BackgroundColor3 = Color3.new(1, 1, 1)
OthersText_3.BackgroundTransparency = 1
OthersText_3.Position = UDim2.new(0.237730592, 0, 0.197684199, 0)
OthersText_3.Size = UDim2.new(0.65658927, 0, 0.219649136, 0)
OthersText_3.Font = Enum.Font.SourceSansItalic
OthersText_3.FontSize = Enum.FontSize.Size24
OthersText_3.Text = "Warning! You require tools in your inventory to use these. Some games/tools do not work."
OthersText_3.TextSize = 19
OthersText_3.TextWrapped = true

TXTBOX_PlrNameOTHER3.Name = "TXTBOX_PlrNameOTHER3"
TXTBOX_PlrNameOTHER3.Parent = Others_3
TXTBOX_PlrNameOTHER3.BackgroundColor3 = Color3.new(0.956863, 0.968628, 0.972549)
TXTBOX_PlrNameOTHER3.BorderColor3 = Color3.new(0.152941, 0.682353, 0.376471)
TXTBOX_PlrNameOTHER3.BorderSizePixel = 0
TXTBOX_PlrNameOTHER3.Position = UDim2.new(0.249051109, 0, 0.571087658, 0)
TXTBOX_PlrNameOTHER3.Size = UDim2.new(0.520743191, 0, 0.0878596455, 0)
TXTBOX_PlrNameOTHER3.ZIndex = 2
TXTBOX_PlrNameOTHER3.Font = Enum.Font.SourceSans
TXTBOX_PlrNameOTHER3.FontSize = Enum.FontSize.Size14
TXTBOX_PlrNameOTHER3.Text = "Player"
TXTBOX_PlrNameOTHER3.TextScaled = true
TXTBOX_PlrNameOTHER3.TextSize = 14
TXTBOX_PlrNameOTHER3.TextWrapped = true

othersBaseBackground3.Name = "othersBaseBackground3"
othersBaseBackground3.Parent = Others_3
othersBaseBackground3.BackgroundColor3 = Color3.new(0.752941, 0.223529, 0.168627)
othersBaseBackground3.BorderSizePixel = 0
othersBaseBackground3.Position = UDim2.new(0.125, 0, 0.518999994, 0)
othersBaseBackground3.Size = UDim2.new(0.769794285, 0, 0.483228087, 0)

FreeFall.Name = "FreeFall"
FreeFall.Parent = othersBaseBackground3
FreeFall.BackgroundColor3 = Color3.new(0.905882, 0.298039, 0.235294)
FreeFall.BorderSizePixel = 0
FreeFall.Position = UDim2.new(0.367916405, 0, 0.364218175, 0)
FreeFall.Size = UDim2.new(0, 92, 0, 25)
FreeFall.Font = Enum.Font.SourceSans
FreeFall.FontSize = Enum.FontSize.Size24
FreeFall.Text = "Free Fall"
FreeFall.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
FreeFall.TextSize = 22

Attach.Name = "Attach"
Attach.Parent = othersBaseBackground3
Attach.BackgroundColor3 = Color3.new(0.905882, 0.298039, 0.235294)
Attach.BorderSizePixel = 0
Attach.Position = UDim2.new(0.67696619, 0, 0.364218175, 0)
Attach.Size = UDim2.new(0, 92, 0, 25)
Attach.Font = Enum.Font.SourceSans
Attach.FontSize = Enum.FontSize.Size24
Attach.Text = "Attach"
Attach.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Attach.TextSize = 22

Bring.Name = "Bring"
Bring.Parent = othersBaseBackground3
Bring.BackgroundColor3 = Color3.new(0.905882, 0.298039, 0.235294)
Bring.BorderSizePixel = 0
Bring.Position = UDim2.new(0.67696619, 0, 0.682909131, 0)
Bring.Size = UDim2.new(0, 92, 0, 25)
Bring.Font = Enum.Font.SourceSans
Bring.FontSize = Enum.FontSize.Size24
Bring.Text = "Bring"
Bring.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Bring.TextSize = 22

SafeKill.Name = "SafeKill"
SafeKill.Parent = othersBaseBackground3
SafeKill.BackgroundColor3 = Color3.new(0.905882, 0.298039, 0.235294)
SafeKill.BorderSizePixel = 0
SafeKill.Position = UDim2.new(0.367916405, 0, 0.682909131, 0)
SafeKill.Size = UDim2.new(0, 92, 0, 25)
SafeKill.Font = Enum.Font.SourceSans
SafeKill.FontSize = Enum.FontSize.Size24
SafeKill.Text = "SafeKill"
SafeKill.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
SafeKill.TextSize = 22

SuperSpin.Name = "SuperSpin"
SuperSpin.Parent = othersBaseBackground3
SuperSpin.BackgroundColor3 = Color3.new(0.905882, 0.298039, 0.235294)
SuperSpin.BorderSizePixel = 0
SuperSpin.Position = UDim2.new(0.0588666238, 0, 0.682909131, 0)
SuperSpin.Size = UDim2.new(0, 92, 0, 25)
SuperSpin.Font = Enum.Font.SourceSans
SuperSpin.FontSize = Enum.FontSize.Size24
SuperSpin.Text = "SuperSpin"
SuperSpin.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
SuperSpin.TextSize = 22

Kill.Name = "Kill"
Kill.Parent = othersBaseBackground3
Kill.BackgroundColor3 = Color3.new(0.905882, 0.298039, 0.235294)
Kill.BorderSizePixel = 0
Kill.Position = UDim2.new(0.0588666238, 0, 0.364218175, 0)
Kill.Size = UDim2.new(0, 92, 0, 25)
Kill.Font = Enum.Font.SourceSans
Kill.FontSize = Enum.FontSize.Size24
Kill.Text = "Kill"
Kill.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Kill.TextSize = 22

Others_backPAGE2.Name = "Others_backPAGE2"
Others_backPAGE2.Parent = Others_3
Others_backPAGE2.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Others_backPAGE2.BorderSizePixel = 0
Others_backPAGE2.Position = UDim2.new(0.0679230243, 0, 0.0439298227, 0)
Others_backPAGE2.Size = UDim2.new(0.113205045, 0, 0.109824568, 0)
Others_backPAGE2.Font = Enum.Font.SourceSansLight
Others_backPAGE2.FontSize = Enum.FontSize.Size24
Others_backPAGE2.Text = "Prev"
Others_backPAGE2.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Others_backPAGE2.TextSize = 22

Character_toPAGE1_IMAGE_4.Name = "Character_toPAGE1_IMAGE"
Character_toPAGE1_IMAGE_4.Parent = Others_backPAGE2
Character_toPAGE1_IMAGE_4.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Character_toPAGE1_IMAGE_4.BorderSizePixel = 0
Character_toPAGE1_IMAGE_4.Position = UDim2.new(-0.400293052, 0, 0, 0)
Character_toPAGE1_IMAGE_4.Size = UDim2.new(0, 25, 0, 25)
Character_toPAGE1_IMAGE_4.Image = "http://www.roblox.com/asset/?id=1282894968"

Games.Name = "Games"
Games.Parent = Pages
Games.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Games.BorderSizePixel = 0
Games.Position = UDim2.new(1, 0, 0, 0)
Games.Size = UDim2.new(1, 0, 1, 0)

Games_IMAGE.Name = "Games_IMAGE"
Games_IMAGE.Parent = Games
Games_IMAGE.BackgroundColor3 = Color3.new(1, 1, 1)
Games_IMAGE.BackgroundTransparency = 1
Games_IMAGE.Position = UDim2.new(0.0679230243, 0, 0.109824568, 0)
Games_IMAGE.Size = UDim2.new(0.0908969939, 0, 0.175596073, 0)
Games_IMAGE.Image = "http://www.roblox.com/asset/?id=1281454262"

GamesText.Name = "GamesText"
GamesText.Parent = Games
GamesText.BackgroundColor3 = Color3.new(1, 1, 1)
GamesText.BackgroundTransparency = 1
GamesText.Position = UDim2.new(0.158487067, 0, 0.109824568, 0)
GamesText.Size = UDim2.new(0.65658927, 0, 0.175719291, 0)
GamesText.Font = Enum.Font.SourceSansItalic
GamesText.FontSize = Enum.FontSize.Size24
GamesText.Text = "Not a completed part, I will be updating with more games."
GamesText.TextSize = 19
GamesText.TextWrapped = true

Games_TITLE.Name = "Games_TITLE"
Games_TITLE.Parent = Games
Games_TITLE.BackgroundColor3 = Color3.new(1, 1, 1)
Games_TITLE.BackgroundTransparency = 1
Games_TITLE.Position = UDim2.new(0.226410091, 0, 0, 0)
Games_TITLE.Size = UDim2.new(0.522657692, 0, 0.1364429, 0)
Games_TITLE.Font = Enum.Font.SourceSansBold
Games_TITLE.FontSize = Enum.FontSize.Size28
Games_TITLE.Text = "Games"
Games_TITLE.TextSize = 25

Games_IMAGE2.Name = "Games_IMAGE2"
Games_IMAGE2.Parent = Games
Games_IMAGE2.BackgroundColor3 = Color3.new(1, 1, 1)
Games_IMAGE2.BackgroundTransparency = 1
Games_IMAGE2.Position = UDim2.new(0.815076292, 0, 0.109824568, 0)
Games_IMAGE2.Size = UDim2.new(0.0908969939, 0, 0.175596073, 0)
Games_IMAGE2.Image = "http://www.roblox.com/asset/?id=1281454262"

SwordFightingTournament.Name = "SwordFightingTournament"
SwordFightingTournament.Parent = Games
SwordFightingTournament.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
SwordFightingTournament.BorderSizePixel = 0
SwordFightingTournament.Position = UDim2.new(0.350935638, 0, 0.329473704, 0)
SwordFightingTournament.Size = UDim2.new(0.283012629, 0, 0.109824568, 0)
SwordFightingTournament.Font = Enum.Font.SourceSans
SwordFightingTournament.FontSize = Enum.FontSize.Size14
SwordFightingTournament.Text = "Sword Fighting Tournament"
SwordFightingTournament.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
SwordFightingTournament.TextScaled = true
SwordFightingTournament.TextSize = 14
SwordFightingTournament.TextWrapped = true

PlatesOfFateMayhem.Name = "PlatesOfFateMayhem"
PlatesOfFateMayhem.Parent = Games
PlatesOfFateMayhem.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
PlatesOfFateMayhem.BorderSizePixel = 0
PlatesOfFateMayhem.Position = UDim2.new(0.350935638, 0, 0.483228087, 0)
PlatesOfFateMayhem.Size = UDim2.new(0.283012629, 0, 0.109824568, 0)
PlatesOfFateMayhem.Font = Enum.Font.SourceSans
PlatesOfFateMayhem.FontSize = Enum.FontSize.Size14
PlatesOfFateMayhem.Text = "Plates of Fate: Mayhem"
PlatesOfFateMayhem.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
PlatesOfFateMayhem.TextScaled = true
PlatesOfFateMayhem.TextSize = 14
PlatesOfFateMayhem.TextWrapped = true

GamesText2.Name = "GamesText2"
GamesText2.Parent = Games
GamesText2.BackgroundColor3 = Color3.new(1, 1, 1)
GamesText2.BackgroundTransparency = 1
GamesText2.Position = UDim2.new(0.0679230243, 0, 0.768771946, 0)
GamesText2.Size = UDim2.new(0.871678829, 0, 0.175719291, 0)
GamesText2.Font = Enum.Font.SourceSansItalic
GamesText2.FontSize = Enum.FontSize.Size24
GamesText2.Text = "Since games update, buttons can sometimes not work. If they do not work, please let me know so I can update."
GamesText2.TextSize = 19
GamesText2.TextWrapped = true

Frappe.Name = "Frappe"
Frappe.Parent = Games
Frappe.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Frappe.BorderSizePixel = 0
Frappe.Position = UDim2.new(0.350935638, 0, 0.636982441, 0)
Frappe.Size = UDim2.new(0.283012629, 0, 0.109824568, 0)
Frappe.Font = Enum.Font.SourceSans
Frappe.FontSize = Enum.FontSize.Size14
Frappe.Text = "Frappe"
Frappe.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Frappe.TextScaled = true
Frappe.TextSize = 14
Frappe.TextWrapped = true

Frappe_2.Name = "Frappe"
Frappe_2.Parent = Games
Frappe_2.BackgroundColor3 = Color3.new(0.203922, 0.286275, 0.368627)
Frappe_2.BorderSizePixel = 0
Frappe_2.Position = UDim2.new(0.667909801, 0, 0.329473704, 0)
Frappe_2.Size = UDim2.new(0.283012629, 0, 0.109824568, 0)
Frappe_2.Font = Enum.Font.SourceSans
Frappe_2.FontSize = Enum.FontSize.Size14
Frappe_2.Text = "Frappe"
Frappe_2.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Frappe_2.TextScaled = true
Frappe_2.TextSize = 14
Frappe_2.TextWrapped = true

MenuFrame.Name = "MenuFrame"
MenuFrame.Parent = MainFrame
MenuFrame.BackgroundColor3 = Color3.new(0.741176, 0.764706, 0.780392)
MenuFrame.BorderSizePixel = 0
MenuFrame.Position = UDim2.new(-0.38499999, 0, 0.075000003, 0)
MenuFrame.Size = UDim2.new(0, 170, 0, 271)

Welcome.Name = "Welcome"
Welcome.Parent = MenuFrame
Welcome.BackgroundColor3 = Color3.new(1, 1, 1)
Welcome.BackgroundTransparency = 1
Welcome.Position = UDim2.new(0.0294333119, 0, 0.0184797049, 0)
Welcome.Size = UDim2.new(0.941865981, 0, 0.0739188194, 0)
Welcome.Font = Enum.Font.SourceSansLight
Welcome.FontSize = Enum.FontSize.Size14
Welcome.Text = "Welcome,"
Welcome.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Welcome.TextScaled = true
Welcome.TextSize = 14
Welcome.TextWrapped = true

NameOfPlayer.Name = "NameOfPlayer"
NameOfPlayer.Parent = MenuFrame
NameOfPlayer.BackgroundColor3 = Color3.new(1, 1, 1)
NameOfPlayer.BackgroundTransparency = 1
NameOfPlayer.Position = UDim2.new(0, 0, 0.0923985243, 0)
NameOfPlayer.Size = UDim2.new(0.971299291, 0, 0.0739188194, 0)
NameOfPlayer.Font = Enum.Font.SourceSansItalic
NameOfPlayer.FontSize = Enum.FontSize.Size14
NameOfPlayer.Text = "PlayerName"
NameOfPlayer.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
NameOfPlayer.TextScaled = true
NameOfPlayer.TextSize = 14
NameOfPlayer.TextWrapped = true

T_Information.Name = "T_Information"
T_Information.Parent = MenuFrame
T_Information.BackgroundColor3 = Color3.new(0.584314, 0.647059, 0.65098)
T_Information.BorderSizePixel = 0
T_Information.Position = UDim2.new(0, 0, 0.221756458, 0)
T_Information.Size = UDim2.new(1.00073266, 0, 0.0923985243, 0)
T_Information.Font = Enum.Font.SourceSans
T_Information.FontSize = Enum.FontSize.Size18
T_Information.Text = "Information"
T_Information.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
T_Information.TextSize = 16
T_Information.TextXAlignment = Enum.TextXAlignment.Left

T_InfoImage.Name = "T_InfoImage"
T_InfoImage.Parent = T_Information
T_InfoImage.BackgroundColor3 = Color3.new(1, 1, 1)
T_InfoImage.BackgroundTransparency = 1
T_InfoImage.Position = UDim2.new(0.79469943, 0, -0.400639981, 0)
T_InfoImage.Size = UDim2.new(0.176599875, 0, 1.20192003, 0)
T_InfoImage.Image = "http://www.roblox.com/asset/?id=1281284684"

T_Character.Name = "T_Character"
T_Character.Parent = MenuFrame
T_Character.BackgroundColor3 = Color3.new(0.584314, 0.647059, 0.65098)
T_Character.BorderSizePixel = 0
T_Character.Position = UDim2.new(0, 0, 0.388073802, 0)
T_Character.Size = UDim2.new(1.00073266, 0, 0.0923985243, 0)
T_Character.Font = Enum.Font.SourceSans
T_Character.FontSize = Enum.FontSize.Size18
T_Character.Text = "Character"
T_Character.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
T_Character.TextSize = 16
T_Character.TextXAlignment = Enum.TextXAlignment.Left

T_CharImage.Name = "T_CharImage"
T_CharImage.Parent = T_Character
T_CharImage.BackgroundColor3 = Color3.new(1, 1, 1)
T_CharImage.BackgroundTransparency = 1
T_CharImage.Position = UDim2.new(0.79469943, 0, -0.400639981, 0)
T_CharImage.Size = UDim2.new(0.176599875, 0, 1.20192003, 0)
T_CharImage.Image = "http://www.roblox.com/asset/?id=1281299598"

T_Games.Name = "T_Games"
T_Games.Parent = MenuFrame
T_Games.BackgroundColor3 = Color3.new(0.584314, 0.647059, 0.65098)
T_Games.BorderSizePixel = 0
T_Games.Position = UDim2.new(0, 0, 0.498952031, 0)
T_Games.Size = UDim2.new(1.00073266, 0, 0.0923985243, 0)
T_Games.Font = Enum.Font.SourceSans
T_Games.FontSize = Enum.FontSize.Size18
T_Games.Text = "Games"
T_Games.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
T_Games.TextSize = 16
T_Games.TextXAlignment = Enum.TextXAlignment.Left

T_GameImage.Name = "T_GameImage"
T_GameImage.Parent = T_Games
T_GameImage.BackgroundColor3 = Color3.new(1, 1, 1)
T_GameImage.BackgroundTransparency = 1
T_GameImage.Position = UDim2.new(0.79469943, 0, -0.400639981, 0)
T_GameImage.Size = UDim2.new(0.176599875, 0, 1.20192003, 0)
T_GameImage.Image = "http://www.roblox.com/asset/?id=1281454262"

T_Others.Name = "T_Others"
T_Others.Parent = MenuFrame
T_Others.BackgroundColor3 = Color3.new(0.584314, 0.647059, 0.65098)
T_Others.BorderSizePixel = 0
T_Others.Position = UDim2.new(0, 0, 0.60983026, 0)
T_Others.Size = UDim2.new(1.00073266, 0, 0.0923985243, 0)
T_Others.Font = Enum.Font.SourceSans
T_Others.FontSize = Enum.FontSize.Size18
T_Others.Text = "Others"
T_Others.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
T_Others.TextSize = 16
T_Others.TextXAlignment = Enum.TextXAlignment.Left

T_OtherImage.Name = "T_OtherImage"
T_OtherImage.Parent = T_Others
T_OtherImage.BackgroundColor3 = Color3.new(1, 1, 1)
T_OtherImage.BackgroundTransparency = 1
T_OtherImage.Position = UDim2.new(0.795000017, 0, -0.351000011, 0)
T_OtherImage.Size = UDim2.new(0, 30, 0, 30)
T_OtherImage.Image = "http://www.roblox.com/asset/?id=1281476978"

T_Extra.Name = "T_Extra"
T_Extra.Parent = MenuFrame
T_Extra.BackgroundColor3 = Color3.new(0.584314, 0.647059, 0.65098)
T_Extra.BorderSizePixel = 0
T_Extra.Position = UDim2.new(0, 0, 0.720708489, 0)
T_Extra.Size = UDim2.new(1.00073266, 0, 0.0923985243, 0)
T_Extra.Font = Enum.Font.SourceSans
T_Extra.FontSize = Enum.FontSize.Size18
T_Extra.Text = "Extra"
T_Extra.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
T_Extra.TextSize = 16
T_Extra.TextXAlignment = Enum.TextXAlignment.Left

T_ExtraImage.Name = "T_ExtraImage"
T_ExtraImage.Parent = T_Extra
T_ExtraImage.BackgroundColor3 = Color3.new(1, 1, 1)
T_ExtraImage.BackgroundTransparency = 1
T_ExtraImage.Position = UDim2.new(0.79469943, 0, -0.400639981, 0)
T_ExtraImage.Size = UDim2.new(0.176599875, 0, 1.20192003, 0)
T_ExtraImage.Image = "http://www.roblox.com/asset/?id=1281477720"

DeleteGUI.Name = "DeleteGUI"
DeleteGUI.Parent = MenuFrame
DeleteGUI.BackgroundColor3 = Color3.new(0.752941, 0.223529, 0.168627)
DeleteGUI.BorderSizePixel = 0
DeleteGUI.Position = UDim2.new(0, 0, 0.887025833, 0)
DeleteGUI.Size = UDim2.new(1.00073266, 0, 0.0923985243, 0)
DeleteGUI.Font = Enum.Font.SourceSans
DeleteGUI.FontSize = Enum.FontSize.Size18
DeleteGUI.Text = "Delete GUI"
DeleteGUI.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
DeleteGUI.TextSize = 16
DeleteGUI.TextXAlignment = Enum.TextXAlignment.Left

DELETEIMAGE.Name = "DELETEIMAGE"
DELETEIMAGE.Parent = DeleteGUI
DELETEIMAGE.BackgroundColor3 = Color3.new(1, 1, 1)
DELETEIMAGE.BackgroundTransparency = 1
DELETEIMAGE.Position = UDim2.new(0.853566051, 0, 0, 0)
DELETEIMAGE.Size = UDim2.new(0.14716655, 0, 1.00160003, 0)
DELETEIMAGE.Image = "http://www.roblox.com/asset/?id=1281475635"

Darkness.Name = "Darkness"
Darkness.Parent = MainFrame
Darkness.BackgroundColor3 = Color3.new(0.180392, 0.192157, 0.176471)
Darkness.BackgroundTransparency = 0.8
Darkness.BorderSizePixel = 0
Darkness.Position = UDim2.new(0.38499999, 0, 0.075000003, 0)
Darkness.Size = UDim2.new(0, 272, 0, 271)
Darkness.Visible = false
Darkness.ZIndex = 7
Darkness.Font = Enum.Font.SourceSans
Darkness.FontSize = Enum.FontSize.Size14
Darkness.Text = ""
Darkness.TextSize = 14

-----------------------------------------------------------------
-----------------------------------------------------------------
NameOfPlayer.Text = game.Players.LocalPlayer.Name
if game.Workspace.FilteringEnabled == true then
	Image_FE_ENABLED.Visible = true
	Image_FE_DISABLED.Visible = false
	Text_FE_ENABLED.Visible = true
	Text_FE_DISABLED.Visible = false
else
	Image_FE_ENABLED.Visible = false
	Image_FE_DISABLED.Visible = true
	Text_FE_ENABLED.Visible = false
	Text_FE_DISABLED.Visible = true
end

function GetPlayer(String) -- Credit to Timeless/xFunnieuss
    local Found = {}
    local strl = String:lower()
    if strl == "all" then
        for i,v in pairs(game.Players:GetPlayers()) do
            table.insert(Found,v)
        end
    elseif strl == "others" then
        for i,v in pairs(game.Players:GetPlayers()) do
            if v.Name ~= game.Players.LocalPlayer.Name then
                table.insert(Found,v)
            end
        end    
    else
        for i,v in pairs(game.Players:GetPlayers()) do
            if v.Name:lower():sub(1, #String) == String:lower() then
                table.insert(Found,v)
            end
        end    
    end
    return Found    
end

OpenMenu.MouseButton1Click:connect(function()
	MenuFrame:TweenPosition(UDim2.new(0, 0, 0.075, 0), "Out", "Sine", 0.7)
	MenuEnterFrame:TweenPosition(UDim2.new(0, 170, 0.075, 0), "Out", "Sine", 0.7)
	Pages:TweenPosition(UDim2.new(0, 170, 0.223, 0), "Out", "Sine", 0.7)
	wait(0.7)
	Darkness.Visible = true
	Darkness.BackgroundTransparency = 0.8
end)

Darkness.MouseButton1Click:connect(function()
	MenuFrame:TweenPosition(UDim2.new(-0.385, 0, 0.075, 0), "Out", "Sine", 0.7)
	MenuEnterFrame:TweenPosition(UDim2.new(0, 0, 0.074, 0), "Out", "Sine", 0.7)
	Pages:TweenPosition(UDim2.new(0, 0, 0.223, 0), "Out", "Sine", 0.7)
	Darkness.Visible = false
end)

closedgui = true
CloseGUI.MouseButton1Click:connect(function()
	wait(0.3)
	if closedgui then
		Pages.Position = UDim2.new(0, 0, 0.223, 0)
		OpenMenu.Position = UDim2.new(0, 0, 0, 0)
		MenuFrame.Position = UDim2.new(-0.38499999, 0, 0.075000003, 0)
		MenuEnterFrame.Position = UDim2.new(0, 0, 0.0741975307, 0)
		Darkness.Visible = false
		Pages:TweenPosition(UDim2.new(0, 0, -0.786, 0), "Out", "Sine", 1.5)
		OpenMenu:TweenPosition(UDim2.new(-0.102, 0, 0, 0), "Out", "Sine", 1.5)
		wait(1.6)
		MenuFrame.Position = UDim2.new(-0.38499999, 0, 0.075000003, 0)
		Darkness.Visible = false
		MenuEnterFrame.Position = UDim2.new(0, 0, 0.0741975307, 0)
		closedgui = false
	else
		Pages:TweenPosition(UDim2.new(0, 0, 0.223, 0), "Out", "Sine", 1.5)
		wait(1.5)
		OpenMenu:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
		wait(0.6)
		closedgui = true
	end
end)

DeleteGUI.MouseButton1Click:connect(function()
	game.CoreGui.OPFinality:Destroy()
end)

T_Character.MouseButton1Click:connect(function()
	MenuFrame:TweenPosition(UDim2.new(-0.385, 0, 0.075, 0), "Out", "Sine", 0.5)
	MenuEnterFrame:TweenPosition(UDim2.new(0, 0, 0.074, 0), "Out", "Sine", 0.5)
	Pages:TweenPosition(UDim2.new(0, 0, 0.223, 0), "Out", "Sine", 0.5)
	Darkness.Visible = false
	wait(0.5)
	Character_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Extra_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Extra_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Games:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Information:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_3:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Character_1:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)

T_Extra.MouseButton1Click:connect(function()
	MenuFrame:TweenPosition(UDim2.new(-0.385, 0, 0.075, 0), "Out", "Sine", 0.5)
	MenuEnterFrame:TweenPosition(UDim2.new(0, 0, 0.074, 0), "Out", "Sine", 0.5)
	Pages:TweenPosition(UDim2.new(0, 0, 0.223, 0), "Out", "Sine", 0.5)
	Darkness.Visible = false
	wait(0.5)
	Character_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Character_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Extra_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Games:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Information:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_3:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Extra_1:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)

T_Games.MouseButton1Click:connect(function()
	MenuFrame:TweenPosition(UDim2.new(-0.385, 0, 0.075, 0), "Out", "Sine", 0.5)
	MenuEnterFrame:TweenPosition(UDim2.new(0, 0, 0.074, 0), "Out", "Sine", 0.5)
	Pages:TweenPosition(UDim2.new(0, 0, 0.223, 0), "Out", "Sine", 0.5)
	Darkness.Visible = false
	wait(0.5)
	Character_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Character_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Extra_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Extra_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Information:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_3:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Games:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)

T_Information.MouseButton1Click:connect(function()
	MenuFrame:TweenPosition(UDim2.new(-0.385, 0, 0.075, 0), "Out", "Sine", 0.5)
	MenuEnterFrame:TweenPosition(UDim2.new(0, 0, 0.074, 0), "Out", "Sine", 0.5)
	Pages:TweenPosition(UDim2.new(0, 0, 0.223, 0), "Out", "Sine", 0.5)
	Darkness.Visible = false
	wait(0.5)
	Character_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Character_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Extra_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Games:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Extra_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_3:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Information:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)

T_Others.MouseButton1Click:connect(function()
	MenuFrame:TweenPosition(UDim2.new(-0.385, 0, 0.075, 0), "Out", "Sine", 0.5)
	MenuEnterFrame:TweenPosition(UDim2.new(0, 0, 0.074, 0), "Out", "Sine", 0.5)
	Pages:TweenPosition(UDim2.new(0, 0, 0.223, 0), "Out", "Sine", 0.5)
	Darkness.Visible = false
	wait(0.5)
	Character_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Character_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Extra_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Games:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Information:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Extra_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	Others_3:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Others_1:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)

Character_toPAGE2.MouseButton1Click:connect(function()
	Character_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Character_2:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)
Character_backPAGE1.MouseButton1Click:connect(function()
	Character_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Character_1:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)
Extra_toPAGE2.MouseButton1Click:connect(function()
	Extra_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Extra_2:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)
Extra_backPAGE1.MouseButton1Click:connect(function()
	Extra_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Extra_1:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)
Others_toPAGE2.MouseButton1Click:connect(function()
	Others_1:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Others_2:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)
Others_toPAGE3.MouseButton1Click:connect(function()
	Others_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Others_3:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)
Others_backPAGE1.MouseButton1Click:connect(function()
	Others_2:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Others_1:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)
Others_backPAGE2.MouseButton1Click:connect(function()
	Others_3:TweenPosition(UDim2.new(1, 0, 0, 0), "Out", "Sine", 0.5)
	wait(0.5)
	Others_2:TweenPosition(UDim2.new(0, 0, 0, 0), "Out", "Sine", 0.5)
end)

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

HipHeight.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.Humanoid.HipHeight = TXTBOX_Stats.Text
end)
Speed.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = TXTBOX_Stats.Text
end)
JumpHeight.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.Humanoid.JumpPower = TXTBOX_Stats.Text
end)
Chat.MouseButton1Click:connect(function()
	game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer(TXTBOX_Chat.Text, "All")
end)
SpammingChar = false
Spam_2.MouseButton1Click:connect(function()
	SpammingChar = not SpammingChar
end)

local flying = false
Fly.MouseButton1Click:connect(function()
flying = not flying
repeat wait()
until game.Players.LocalPlayer and game.Players.LocalPlayer.Character and game.Players.LocalPlayer.Character:findFirstChild("Torso") and game.Players.LocalPlayer.Character:findFirstChild("Humanoid")
local mouse = game.Players.LocalPlayer:GetMouse()
repeat wait() until mouse
local plr = game.Players.LocalPlayer
local torso = plr.Character.Torso
local deb = true
local ctrl = {f = 0, b = 0, l = 0, r = 0}
local lastctrl = {f = 0, b = 0, l = 0, r = 0}
local maxspeed = 80
local speed = 0
if flying then
	Fly.BackgroundColor3 = Color3.new(0.201961, 0.837255, 0.711765)
else
	Fly.BackgroundColor3 = Color3.new(0.101961, 0.737255, 0.611765)
end
 
function FlyFunction()
local bg = Instance.new("BodyGyro", torso)
bg.P = 9e4
bg.maxTorque = Vector3.new(9e9, 9e9, 9e9)
bg.cframe = torso.CFrame
local bv = Instance.new("BodyVelocity", torso)
bv.velocity = Vector3.new(0,0.1,0)
bv.maxForce = Vector3.new(9e9, 9e9, 9e9)
repeat wait()
plr.Character.Humanoid.PlatformStand = true
if ctrl.l + ctrl.r ~= 0 or ctrl.f + ctrl.b ~= 0 then
speed = speed+.5+(speed/maxspeed)
if speed > maxspeed then
speed = maxspeed
end
elseif not (ctrl.l + ctrl.r ~= 0 or ctrl.f + ctrl.b ~= 0) and speed ~= 0 then
speed = speed-1
if speed < 0 then
speed = 0
end
end
if (ctrl.l + ctrl.r) ~= 0 or (ctrl.f + ctrl.b) ~= 0 then
bv.velocity = ((game.Workspace.CurrentCamera.CoordinateFrame.lookVector * (ctrl.f+ctrl.b)) + ((game.Workspace.CurrentCamera.CoordinateFrame * CFrame.new(ctrl.l+ctrl.r,(ctrl.f+ctrl.b)*.2,0).p) - game.Workspace.CurrentCamera.CoordinateFrame.p))*speed
lastctrl = {f = ctrl.f, b = ctrl.b, l = ctrl.l, r = ctrl.r}
elseif (ctrl.l + ctrl.r) == 0 and (ctrl.f + ctrl.b) == 0 and speed ~= 0 then
bv.velocity = ((game.Workspace.CurrentCamera.CoordinateFrame.lookVector * (lastctrl.f+lastctrl.b)) + ((game.Workspace.CurrentCamera.CoordinateFrame * CFrame.new(lastctrl.l+lastctrl.r,(lastctrl.f+lastctrl.b)*.2,0).p) - game.Workspace.CurrentCamera.CoordinateFrame.p))*speed
else
bv.velocity = Vector3.new(0,0.1,0)
end
bg.cframe = game.Workspace.CurrentCamera.CoordinateFrame * CFrame.Angles(-math.rad((ctrl.f+ctrl.b)*50*speed/maxspeed),0,0)
until not flying
ctrl = {f = 0, b = 0, l = 0, r = 0}
lastctrl = {f = 0, b = 0, l = 0, r = 0}
speed = 0
bg:Destroy()
bv:Destroy()
plr.Character.Humanoid.PlatformStand = false
end
mouse.KeyDown:connect(function(key)
if key:lower() == "w" then
ctrl.f = 1
elseif key:lower() == "s" then
ctrl.b = -1
elseif key:lower() == "a" then
ctrl.l = -1
elseif key:lower() == "d" then
ctrl.r = 1
end
end)
mouse.KeyUp:connect(function(key)
if key:lower() == "w" then
ctrl.f = 0
elseif key:lower() == "s" then
ctrl.b = 0
elseif key:lower() == "a" then
ctrl.l = 0
elseif key:lower() == "d" then
ctrl.r = 0
end
end)
FlyFunction()
end)

clip = true
Noclip.MouseButton1Click:connect(function()
	clip = not clip
	game:GetService('RunService').Stepped:connect(function()
		if not clip then
			Noclip.BackgroundColor3 = Color3.new(0.201961, 0.837255, 0.711765)
			game.Players.LocalPlayer.Character.Head.CanCollide = false
			game.Players.LocalPlayer.Character.Torso.CanCollide = false
			game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
			game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
		else
			Noclip.BackgroundColor3 = Color3.new(0.101961, 0.737255, 0.611765)
		end
	end)
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://33169583"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local armsareoff = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    armsareoff = false
	armsoff.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
armsoff.MouseButton1Click:connect(function()
	armsareoff = not armsareoff
	if armsareoff then
		armsoff.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if armsareoff then
				track:Play(.1, 1, 1e6)
			end
		 end
		end
	else
		track:Stop()
		armsoff.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://121572214"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
headfloatACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    headfloatACTIVE = false
	headfloat.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
headfloat.MouseButton1Click:connect(function()
	headfloatACTIVE = not headfloatACTIVE
	if headfloatACTIVE then
		headfloat.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if headfloatACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		headfloat.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://35154961"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local headthrowACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    headthrowACTIVE = false
	headthrow.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
headthrow.MouseButton1Click:connect(function()
	headthrowACTIVE = not headthrowACTIVE
	if headthrowACTIVE then
		headthrow.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if headthrowACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		headthrow.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://35154961"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local loopheadACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    loopheadACTIVE = false
	loophead.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
loophead.MouseButton1Click:connect(function()
	loopheadACTIVE = not loopheadACTIVE
	if loopheadACTIVE then
		loophead.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if loopheadACTIVE then
				track:Play(.1, 1, 1e6)
			end
		 end
		end
	else
		track:Stop()
		loophead.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://313762630"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local levitateACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    levitateACTIVE = false
	levitate.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
levitate.MouseButton1Click:connect(function()
	levitateACTIVE = not levitateACTIVE
	if levitateACTIVE then
		levitate.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if levitateACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		levitate.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://282574440"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local crawlACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    crawlACTIVE = false
	crawl.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
crawl.MouseButton1Click:connect(function()
	crawlACTIVE = not crawlACTIVE
	if crawlACTIVE then
		crawl.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if crawlACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		crawl.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://184574340"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local jumplandACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    jumplandACTIVE = false
	jumpland.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
jumpland.MouseButton1Click:connect(function()
	jumplandACTIVE = not jumplandACTIVE
	if jumplandACTIVE then
		jumpland.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if jumplandACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		jumpland.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://126753849"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local punchesACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    punchesACTIVE = false
	punches.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
punches.MouseButton1Click:connect(function()
	punchesACTIVE = not punchesACTIVE
	if punchesACTIVE then
		punches.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if punchesACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		punches.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://204062532"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local swingACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    swingACTIVE = false
	swing.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
swing.MouseButton1Click:connect(function()
	swingACTIVE = not swingACTIVE
	if swingACTIVE then
		swing.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if swingACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		swing.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://204295235"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local swordstrikeACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    swordstrikeACTIVE = false
	swordstrike.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
swordstrike.MouseButton1Click:connect(function()
	swordstrikeACTIVE = not swordstrikeACTIVE
	if swordstrikeACTIVE then
		swordstrike.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if swordstrikeACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		swordstrike.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://45834924"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local happyACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    happyACTIVE = false
	happy.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
happy.MouseButton1Click:connect(function()
	happyACTIVE = not happyACTIVE
	if happyACTIVE then
		happy.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if happyACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		happy.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://33796059"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local insaneACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    insaneACTIVE = false
	insane.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
insane.MouseButton1Click:connect(function()
	insaneACTIVE = not insaneACTIVE
	if insaneACTIVE then
		insane.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if insaneACTIVE then
				track:Play(.1, 1, 1e6)
			end
		 end
		end
	else
		track:Stop()
		insane.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://429703734"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local movingdanceACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    movingdanceACTIVE = false
	movingdance.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
movingdance.MouseButton1Click:connect(function()
	movingdanceACTIVE = not movingdanceACTIVE
	if movingdanceACTIVE then
		movingdance.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if movingdanceACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		movingdance.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://35654637"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local normalACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    normalACTIVE = false
	normal.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
normal.MouseButton1Click:connect(function()
	normalACTIVE = not normalACTIVE
	if normalACTIVE then
		normal.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if normalACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		normal.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://186934910"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local spindanceACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    spindanceACTIVE = false
	spindance.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
end)
spindance.MouseButton1Click:connect(function()
	spindanceACTIVE = not spindanceACTIVE
	if spindanceACTIVE then
		spindance.BackgroundColor3 = Color3.new(0.851961, 0.694118, 0.333333)
		while wait() do
		 if track.IsPlaying == false then
			if spindanceACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		spindance.BackgroundColor3 = Color3.new(0.901961, 0.494118, 0.133333)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://215384594"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local CloneIllusionACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    CloneIllusionACTIVE = false
	CloneIllusion.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
end)
CloneIllusion.MouseButton1Click:connect(function()
	CloneIllusionACTIVE = not CloneIllusionACTIVE
	if CloneIllusionACTIVE then
		CloneIllusion.BackgroundColor3 = Color3.new(0.992941, 0.811765, 0.2705882)
		while wait() do
		 if track.IsPlaying == false then
			if CloneIllusionACTIVE then
				track:Play(.1, 1, 1e6)
			end
		 end
		end
	else
		track:Stop()
		CloneIllusion.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
	end
end)

spinning = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    spinning = false
	CoolSpin.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
end)
CoolSpin.MouseButton1Click:connect(function()
	spinning = not spinning
	if spinning then
		local p = Instance.new("RocketPropulsion")
		p.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		p.Name = "CrazySpin"
		p.Target = game.Players.LocalPlayer.Character["Left Arm"]
		p:Fire()
		CoolSpin.BackgroundColor3 = Color3.new(0.992941, 0.811765, 0.2705882)
	else
		game.Players.LocalPlayer.Character.HumanoidRootPart.CrazySpin:Destroy()
		CoolSpin.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://180612465"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local ScaredACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    ScaredACTIVE = false
	CrouchRocket.BackgroundColor3 = Color3.new(0.952941, 0.711765, 0.1705882)
end)
CrouchRocket.MouseButton1Click:connect(function()
	ScaredACTIVE = not ScaredACTIVE
	if ScaredACTIVE then
		local u = Instance.new("RocketPropulsion")
		u.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		u.Name = "CrouchRocket"
		u.Target = game.Players.LocalPlayer.Character.Head
		u:Fire()
		CrouchRocket.BackgroundColor3 = Color3.new(0.992941, 0.811765, 0.2705882)
		while wait() do
		 if track.IsPlaying == false then
			if ScaredACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		CrouchRocket.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
		game.Players.LocalPlayer.Character.HumanoidRootPart.CrouchRocket:Destroy()
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://184574340"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local jumprocketnow = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    jumprocketnow = false
	JumpRocket.BackgroundColor3 = Color3.new(0.952941, 0.711765, 0.1705882)
end)
JumpRocket.MouseButton1Click:connect(function()
	jumprocketnow = not jumprocketnow
	if jumprocketnow then
		local u = Instance.new("RocketPropulsion")
		u.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		u.Name = "JumpRocket"
		u.Target = game.Players.LocalPlayer.Character.Head
		u:Fire()
		JumpRocket.BackgroundColor3 = Color3.new(0.992941, 0.811765, 0.2705882)
		while wait() do
		 if track.IsPlaying == false then
			if jumprocketnow then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		JumpRocket.BackgroundColor3 = Color3.new(0.952941, 0.611765, 0.0705882)
		game.Players.LocalPlayer.Character.HumanoidRootPart.JumpRocket:Destroy()
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://126753849"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local RapidPunchACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    RapidPunchACTIVE = false
	RapidPunch.BackgroundColor3 = Color3.new(0.0862745, 0.627451, 0.521569)
end)
RapidPunch.MouseButton1Click:connect(function()
	RapidPunchACTIVE = not RapidPunchACTIVE
	if RapidPunchACTIVE then
		RapidPunch.BackgroundColor3 = Color3.new(0.1962745, 0.827451, 0.721569)
		while wait() do
		 if track.IsPlaying == false then
			if RapidPunchACTIVE then
				track:Play(.1, 1, 10)
			end
		 end
		end
	else
		track:Stop()
		RapidPunch.BackgroundColor3 = Color3.new(0.0862745, 0.627451, 0.521569)
	end
end)

FEGodmode.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.Humanoid.Name = 1
	local l = game.Players.LocalPlayer.Character["1"]:Clone()
	l.Parent = game.Players.LocalPlayer.Character
	l.Name = "Humanoid"
	wait(0.1)
	game.Players.LocalPlayer.Character["1"]:Destroy()
	game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
	game.Players.LocalPlayer.Character.Animate.Disabled = true
	wait(0.1)
	game.Players.LocalPlayer.Character.Animate.Disabled = false
	game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
end)

NoLimbs.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character["Left Leg"]:Destroy()
	game.Players.LocalPlayer.Character["Left Arm"]:Destroy()
	game.Players.LocalPlayer.Character["Right Leg"]:Destroy()
	game.Players.LocalPlayer.Character["Right Arm"]:Destroy()
end)

BrickHats.MouseButton1Click:connect(function() 
	for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
		if (v:IsA("Accessory")) then
			v.Handle.Mesh:Destroy()
		end
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://181525546"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local FaintACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    FaintACTIVE = false
	Faint.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
end)
Faint.MouseButton1Click:connect(function()
	FaintACTIVE = not FaintACTIVE
	if FaintACTIVE then
		Faint.BackgroundColor3 = Color3.new(0.756863, 0.466667, 0.878431)
		while wait() do
		 if track.IsPlaying == false then
			if FaintACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		Faint.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://188632011"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local SpinACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    SpinACTIVE = false
	Spin.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
end)
Spin.MouseButton1Click:connect(function()
	SpinACTIVE = not SpinACTIVE
	if SpinACTIVE then
		Spin.BackgroundColor3 = Color3.new(0.756863, 0.466667, 0.878431)
		while wait() do
		 if track.IsPlaying == false then
			if SpinACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		Spin.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://33169583"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local ArmFollowACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    ArmFollowACTIVE = false
	ArmFollow.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
end)
ArmFollow.MouseButton1Click:connect(function()
	ArmFollowACTIVE = not ArmFollowACTIVE
	if ArmFollowACTIVE then
		local u = Instance.new("RocketPropulsion")
		u.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		u.Name = "ArmFollow"
		u.Target = game.Players.LocalPlayer.Character["Right Arm"]
		u:Fire()
		ArmFollow.BackgroundColor3 = Color3.new(0.756863, 0.466667, 0.878431)
		while wait() do
		 if track.IsPlaying == false then
			if ArmFollowACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		ArmFollow.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
		game.Players.LocalPlayer.Character.HumanoidRootPart.ArmFollow:Destroy()
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://126753849"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local PunchFollowACTIVE = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    PunchFollowACTIVE = false
	PunchFollow.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
end)
PunchFollow.MouseButton1Click:connect(function()
	PunchFollowACTIVE = not PunchFollowACTIVE
	if PunchFollowACTIVE then
		local u = Instance.new("RocketPropulsion")
		u.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		u.Name = "PunchFollow"
		u.Target = game.Players.LocalPlayer.Character["Right Arm"]
		u:Fire()
		PunchFollow.BackgroundColor3 = Color3.new(0.756863, 0.466667, 0.878431)
		while wait() do
		 if track.IsPlaying == false then
			if PunchFollowACTIVE then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		PunchFollow.BackgroundColor3 = Color3.new(0.556863, 0.266667, 0.678431)
		game.Players.LocalPlayer.Character.HumanoidRootPart.PunchFollow:Destroy()
	end
end)

AnimationId = "148840371"
local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://"..AnimationId
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
_18active = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    _18active = false
	_18.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
end)
_18.MouseButton1Click:connect(function()
	_18active = not _18active
	if _18active then
		_18.BackgroundColor3 = Color3.new(0.352941, 0.882353, 0.576471)
		for i,v in pairs(GetPlayer(TXTBOX_PlrNameEXTRA.Text))do
			track:Play()
			while wait() do
				if _18active then
					game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				end
			end
		end
	else
		track:Stop()
		_18.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://180612465"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local crouchattacking = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    crouchattacking = false
	CrouchAttack.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
end)
CrouchAttack.MouseButton1Click:connect(function()
	crouchattacking = not crouchattacking
	if crouchattacking then
		local u = Instance.new("RocketPropulsion")
		u.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		u.Name = "CrouchAttack"
		for i,v in pairs(GetPlayer(TXTBOX_PlrNameEXTRA.Text))do
			u.Target = game.Players[v.Name].Character.HumanoidRootPart
		end
		u:Fire()
		CrouchAttack.BackgroundColor3 = Color3.new(0.352941, 0.882353, 0.576471)
		while wait() do
		 if track.IsPlaying == false then
			if crouchattacking then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		CrouchAttack.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
		game.Players.LocalPlayer.Character.HumanoidRootPart.CrouchAttack:Destroy()
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://184574340"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local SlamPropulsioning = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    SlamPropulsioning = false
	SlamPropulsion.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
end)
SlamPropulsion.MouseButton1Click:connect(function()
	SlamPropulsioning = not SlamPropulsioning
	if SlamPropulsioning then
		local u = Instance.new("RocketPropulsion")
		u.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		u.Name = "SlamPropulsion"
		for i,v in pairs(GetPlayer(TXTBOX_PlrNameEXTRA.Text))do
			u.Target = game.Players[v.Name].Character.HumanoidRootPart
		end
		u:Fire()
		SlamPropulsion.BackgroundColor3 = Color3.new(0.352941, 0.882353, 0.576471)
		while wait() do
		 if track.IsPlaying == false then
			if SlamPropulsioning then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		SlamPropulsion.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
		game.Players.LocalPlayer.Character.HumanoidRootPart.SlamPropulsion:Destroy()
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://429730430"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local SpinAttacking = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    SpinAttacking = false
	SpinAttack.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
end)
SpinAttack.MouseButton1Click:connect(function()
	SpinAttacking = not SpinAttacking
	if SpinAttacking then
		local u = Instance.new("RocketPropulsion")
		u.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		u.Name = "SpinAttack"
		for i,v in pairs(GetPlayer(TXTBOX_PlrNameEXTRA.Text))do
			u.Target = game.Players[v.Name].Character.HumanoidRootPart
		end
		u:Fire()
		SpinAttack.BackgroundColor3 = Color3.new(0.352941, 0.882353, 0.576471)
		while wait() do
		 if track.IsPlaying == false then
			if SpinAttacking then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		SpinAttack.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
		game.Players.LocalPlayer.Character.HumanoidRootPart.SpinAttack:Destroy()
	end
end)

watching = false
CreepyWatch.MouseButton1Click:connect(function()
	watching = not watching
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://215384594"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
walkingthrough = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    walkingthrough = false
	WalkThrough.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
	track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
end)
WalkThrough.MouseButton1Click:connect(function()
	walkingthrough = not walkingthrough
	if walkingthrough then
		WalkThrough.BackgroundColor3 = Color3.new(0.352941, 0.882353, 0.576471)
		while wait() do
			if walkingthrough then
			for i,v in pairs(GetPlayer(TXTBOX_PlrNameEXTRA.Text))do
				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				if track.IsPlaying == false then
					if walkingthrough then
						track:Play(.1, 1, 1e6)
					end
				end
			end
			end
		end
	else
		WalkThrough.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
		track:Stop()
	end
end)

annoying = false
Annoy.MouseButton1Click:connect(function()
	annoying = not annoying
end)
local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://282574440"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
local crawlACTIVE = false
Carpett = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    Carpett = false
	Carpet.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
end)
Carpet.MouseButton1Click:connect(function()
	Carpett = not Carpett
	if Carpett then
		Carpet.BackgroundColor3 = Color3.new(0.403922, 0.796078, 0.858824)
		while wait() do
		 if track.IsPlaying == false then
			if Carpett then
				track:Play(.1, 1, 1)
			end
		 end
		end
	else
		track:Stop()
		Carpet.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
	end
end)
following = false
Follow.MouseButton1Click:connect(function()
	following = not following
end)
headwalking = false
HeadWalk.MouseButton1Click:connect(function()
	headwalking = not headwalking
end)
Spammer = false
Spam.MouseButton1Click:connect(function()
	Spammer = not Spammer
end)
stuck = false
Stick.MouseButton1Click:connect(function()
	stuck = not stuck
end)
TeleportTo.MouseButton1Click:connect(function()
	for i,v in pairs(GetPlayer(TXTBOX_PlrName.Text))do
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
	end
end)

orbital = false
Orbit.MouseButton1Click:connect(function()
	orbital = not orbital
	if orbital then
		Orbit.BackgroundColor3 = Color3.new(0.403922, 0.796078, 0.858824)
		local o = Instance.new("RocketPropulsion")
		o.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		o.Name = "Orbit"
		for i,v in pairs(GetPlayer(TXTBOX_PlrName.Text))do
			o.Target = game.Players[v.Name].Character.HumanoidRootPart
			o:Fire()
			game:GetService('RunService').Stepped:connect(function()
				if orbital then
					game.Players.LocalPlayer.Character.Head.CanCollide = false
					game.Players.LocalPlayer.Character.Torso.CanCollide = false
					game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
					game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
				end
			end)
		end
	else
		game.Players.LocalPlayer.Character.HumanoidRootPart.Orbit:Destroy()
		Orbit.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
	end
end)

currentview = false
View.MouseButton1Click:connect(function()
	currentview = not currentview
	for i,v in pairs(GetPlayer(TXTBOX_PlrName.Text))do
		if currentview then
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
			View.BackgroundColor3 = Color3.new(0.403922, 0.796078, 0.858824)
		else
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character.Head
			View.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
		end
	end
end)

floating = false
Float.MouseButton1Click:connect(function()
	floating = not floating
	if floating then
		Float.BackgroundColor3 = Color3.new(0.707843, 0.54902, 0.813726)
		local y = Instance.new("RocketPropulsion")
		y.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		y.CartoonFactor = 1
		y.MaxThrust = 50000
		y.MaxSpeed = 1000
		y.ThrustP = 50000
		y.Name = "Float"
		for i,v in pairs(GetPlayer(TXTBOX_PlrName2.Text))do
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
			y.Target = game.Players[v.Name].Character.Head
			y:Fire()
			game:GetService('RunService').Stepped:connect(function()
				if floating then
					game.Players.LocalPlayer.Character.Head.CanCollide = false
					game.Players.LocalPlayer.Character.Torso.CanCollide = false
					game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
					game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
				end
			end)
			while wait(0.3) do
				if floating then
					game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Leg"].CFrame
				end
			end
		end
	else
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.HumanoidRootPart.Float:Destroy()
		Float.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://282574440"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
flattening = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    flattening = false
	Flatten.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
end)
Flatten.MouseButton1Click:connect(function()
	flattening = not flattening
	if flattening then
		Flatten.BackgroundColor3 = Color3.new(0.707843, 0.54902, 0.813726)
		local y = Instance.new("RocketPropulsion")
		y.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		y.CartoonFactor = 1
		y.MaxThrust = 50000
		y.MaxSpeed = 1000
		y.ThrustP = 50000
		y.Name = "Flatten"
		for i,v in pairs(GetPlayer(TXTBOX_PlrName2.Text))do
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
			y.Target = game.Players[v.Name].Character["Left Leg"]
			y:Fire()
			track:Play(.1, 1, 1)
			game:GetService('RunService').Stepped:connect(function()
				if flattening then
					game.Players.LocalPlayer.Character.Head.CanCollide = false
					game.Players.LocalPlayer.Character.Torso.CanCollide = false
					game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
					game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
				end
			end)
			while wait(0.3) do
				if flattening then
					game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame + Vector3.new(0,2,0)
				end
			end
		end
	else
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.HumanoidRootPart.Flatten:Destroy()
		track:Stop()
		Flatten.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
	end
end)

SlowAttracting = false
SlowAttract.MouseButton1Click:connect(function()
	SlowAttracting = not SlowAttracting
	if SlowAttracting then
		SlowAttract.BackgroundColor3 = Color3.new(0.707843, 0.54902, 0.813726)
		local b = Instance.new("RocketPropulsion")
		b.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		b.TurnD = 5000
		b.MaxThrust = 5000
		b.MaxSpeed = 200
		b.ThrustP = 5000
		b.CartoonFactor = 1
		b.Name = "SlowAttract"
		for i,v in pairs(GetPlayer(TXTBOX_PlrName2.Text))do
			b.Target = game.Players[v.Name].Character.HumanoidRootPart
			b:Fire()
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
			game:GetService('RunService').Stepped:connect(function()
				if SlowAttracting then
					game.Players.LocalPlayer.Character.Head.CanCollide = false
					game.Players.LocalPlayer.Character.Torso.CanCollide = false
					game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
					game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
				end
			end)
		end
	else
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.HumanoidRootPart.SlowAttract:Destroy()
		SlowAttract.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
	end
end)

AimHeading = false
AimHead.MouseButton1Click:connect(function()
	AimHeading = not AimHeading
	if AimHeading then
		AimHead.BackgroundColor3 = Color3.new(0.707843, 0.54902, 0.813726)
		local b = Instance.new("RocketPropulsion")
		b.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		b.TurnP = 2500
		b.MaxThrust = 50000
		b.MaxSpeed = 1000
		b.ThrustP = 50000
		b.CartoonFactor = 1
		b.Name = "AimHead"
		for i,v in pairs(GetPlayer(TXTBOX_PlrName2.Text))do
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
			b.Target = game.Players[v.Name].Character.Head
			b:Fire()
			game:GetService('RunService').Stepped:connect(function()
				if AimHeading then
					game.Players.LocalPlayer.Character.Head.CanCollide = false
					game.Players.LocalPlayer.Character.Torso.CanCollide = false
					game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
					game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
				end
			end)
		end
	else
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.HumanoidRootPart.AimHead:Destroy()
		AimHead.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
	end
end)

Multipleing = false
Multiple.MouseButton1Click:connect(function()
	Multipleing = not Multipleing
	if Multipleing then
		Multiple.BackgroundColor3 = Color3.new(0.707843, 0.54902, 0.813726)
		local t1 = Instance.new("RocketPropulsion")
		t1.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		t1.TurnP = 30000
		t1.MaxThrust = 30000
		t1.MaxSpeed = 1000
		t1.ThrustP = 30000
		t1.CartoonFactor = 1
		t1.Name = "one"
		local t2 = Instance.new("RocketPropulsion")
		t2.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		t2.TurnP = 30000
		t2.MaxThrust = 30000
		t2.MaxSpeed = 1000
		t2.ThrustP = 30000
		t2.CartoonFactor = 1
		t2.Name = "two"
		local t3 = Instance.new("RocketPropulsion")
		t3.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		t3.TurnP = 30000
		t3.MaxThrust = 30000
		t3.MaxSpeed = 1000
		t3.ThrustP = 30000
		t3.CartoonFactor = 1
		t3.Name = "three"
		for i,v in pairs(GetPlayer(TXTBOX_PlrName2.Text))do
			t1.Target = game.Players[v.Name].Character.Torso
			t1:Fire()
			t2.Target = game.Players[v.Name].Character["Right Leg"]
			t2:Fire()
			t3.Target = game.Players[v.Name].Character["Left Arm"]
			t3:Fire()
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
			game:GetService('RunService').Stepped:connect(function()
				if Multipleing then
					game.Players.LocalPlayer.Character.Head.CanCollide = false
					game.Players.LocalPlayer.Character.Torso.CanCollide = false
					game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
					game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
				end
			end)
		end
	else
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.HumanoidRootPart.one:Destroy()
		game.Players.LocalPlayer.Character.HumanoidRootPart.two:Destroy()
		game.Players.LocalPlayer.Character.HumanoidRootPart.three:Destroy()
		Multiple.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://215384594"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
Violenting = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    Violenting = false
	Violent.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
end)
Violent.MouseButton1Click:connect(function()
	Violenting = not Violenting
	if Violenting then
		Violent.BackgroundColor3 = Color3.new(0.707843, 0.54902, 0.813726)
		local y = Instance.new("RocketPropulsion")
		y.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		y.CartoonFactor = 1
		y.MaxThrust = 50000
		y.MaxSpeed = 1000
		y.ThrustP = 50000
		y.Name = "Violent"
		for i,v in pairs(GetPlayer(TXTBOX_PlrName2.Text))do
			y.Target = game.Players[v.Name].Character.HumanoidRootPart
			y:Fire()
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
			track:Play(.1, 1, 10)
			game:GetService('RunService').Stepped:connect(function()
				if Violenting then
					game.Players.LocalPlayer.Character.Head.CanCollide = false
					game.Players.LocalPlayer.Character.Torso.CanCollide = false
					game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
					game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
				end
			end)
		end
	else
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.HumanoidRootPart.Violent:Destroy()
		track:Stop()
		Violent.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://215384594"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
Violenting = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    Violenting = false
	Violent.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
end)
Violent.MouseButton1Click:connect(function()
	Violenting = not Violenting
	if Violenting then
		Violent.BackgroundColor3 = Color3.new(0.707843, 0.54902, 0.813726)
		local y = Instance.new("RocketPropulsion")
		y.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		y.CartoonFactor = 1
		y.MaxThrust = 500000
		y.MaxSpeed = 1000
		y.ThrustP = 50000
		y.Name = "Violent"
		for i,v in pairs(GetPlayer(TXTBOX_PlrName2.Text))do
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
			y.Target = game.Players[v.Name].Character.HumanoidRootPart
			y:Fire()
			track:Play(.1, 1, 10)
			game:GetService('RunService').Stepped:connect(function()
				if Violenting then
					game.Players.LocalPlayer.Character.Head.CanCollide = false
					game.Players.LocalPlayer.Character.Torso.CanCollide = false
					game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
					game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
				end
			end)
		end
	else
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.HumanoidRootPart.Violent:Destroy()
		track:Stop()
		Violent.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
	end
end)

WeirdOrbital = false
WeirdOrbit.MouseButton1Click:connect(function()
	WeirdOrbital = not WeirdOrbital
	if WeirdOrbital then
		WeirdOrbit.BackgroundColor3 = Color3.new(0.707843, 0.54902, 0.813726)
		local o = Instance.new("RocketPropulsion")
		o.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		o.TurnD = 50000
		o.Name = "WeirdOrbit"
		for i,v in pairs(GetPlayer(TXTBOX_PlrName.Text))do
			o.Target = game.Players[v.Name].Character.HumanoidRootPart
			o:Fire()
			game:GetService('RunService').Stepped:connect(function()
				if WeirdOrbital then
					game.Players.LocalPlayer.Character.Head.CanCollide = false
					game.Players.LocalPlayer.Character.Torso.CanCollide = false
					game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
					game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
				end
			end)
		end
	else
		game.Players.LocalPlayer.Character.HumanoidRootPart.WeirdOrbit:Destroy()
		WeirdOrbit.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
	end
end)

Maxing = false
Max.MouseButton1Click:connect(function()
	Maxing = not Maxing
	if Maxing then
		Max.BackgroundColor3 = Color3.new(0.707843, 0.54902, 0.813726)
		local t1 = Instance.new("RocketPropulsion")
		t1.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		t1.TurnP = 100000
		t1.MaxThrust = 100000
		t1.MaxSpeed = 5000
		t1.ThrustP = 100000
		t1.CartoonFactor = 1
		t1.Name = "onee"
		local t2 = Instance.new("RocketPropulsion")
		t2.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		t2.TurnP = 100000
		t2.MaxThrust = 100000
		t2.MaxSpeed = 5000
		t2.ThrustP = 100000
		t2.CartoonFactor = 1
		t2.Name = "twoo"
		local t3 = Instance.new("RocketPropulsion")
		t3.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		t3.TurnP = 100000
		t3.MaxThrust = 100000
		t3.MaxSpeed = 5000
		t3.ThrustP = 100000
		t3.CartoonFactor = 1
		t3.Name = "threee"
		local t4 = Instance.new("RocketPropulsion")
		t4.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		t4.TurnP = 100000
		t4.MaxThrust = 100000
		t4.MaxSpeed = 5000
		t4.ThrustP = 100000
		t4.CartoonFactor = 1
		t4.Name = "fourr"
		local t5 = Instance.new("RocketPropulsion")
		t5.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		t5.TurnP = 100000
		t5.MaxThrust = 100000
		t5.MaxSpeed = 5000
		t5.ThrustP = 100000
		t5.CartoonFactor = 1
		t5.Name = "fivee"
		local t6 = Instance.new("RocketPropulsion")
		t6.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		t6.TurnP = 100000
		t6.MaxThrust = 100000
		t6.MaxSpeed = 5000
		t6.ThrustP = 100000
		t6.CartoonFactor = 1
		t6.Name = "sixx"
		for i,v in pairs(GetPlayer(TXTBOX_PlrName2.Text))do
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
			t1.Target = game.Players[v.Name].Character.Torso
			t1:Fire()
			t2.Target = game.Players[v.Name].Character["Right Leg"]
			t2:Fire()
			t3.Target = game.Players[v.Name].Character["Left Arm"]
			t3:Fire()
			t4.Target = game.Players[v.Name].Character["Left Leg"]
			t4:Fire()
			t5.Target = game.Players[v.Name].Character["Right Arm"]
			t5:Fire()
			t6.Target = game.Players[v.Name].Character.Head
			t6:Fire()
			game:GetService('RunService').Stepped:connect(function()
				if Maxing then
					game.Players.LocalPlayer.Character.Head.CanCollide = false
					game.Players.LocalPlayer.Character.Torso.CanCollide = false
					game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
					game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
				end
			end)
		end
	else
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.HumanoidRootPart.onee:Destroy()
		game.Players.LocalPlayer.Character.HumanoidRootPart.twoo:Destroy()
		game.Players.LocalPlayer.Character.HumanoidRootPart.threee:Destroy()
		game.Players.LocalPlayer.Character.HumanoidRootPart.fourr:Destroy()
		game.Players.LocalPlayer.Character.HumanoidRootPart.fivee:Destroy()
		game.Players.LocalPlayer.Character.HumanoidRootPart.sixx:Destroy()
		Max.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
	end
end)

local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://184574340"
local track = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
Animateding = false
game.Players.LocalPlayer.CharacterAdded:Connect(function(character)
    track = character:WaitForChild("Humanoid"):LoadAnimation(Anim)
    Animateding = false
	Animated.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
end)
Animated.MouseButton1Click:connect(function()
	Animateding = not Animateding
	if Animateding then
		Animated.BackgroundColor3 = Color3.new(0.707843, 0.54902, 0.813726)
		local y = Instance.new("RocketPropulsion")
		y.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
		y.CartoonFactor = 1
		y.MaxThrust = 200000
		y.MaxSpeed = 1000
		y.ThrustP = 50000
		y.Name = "Animated"
		for i,v in pairs(GetPlayer(TXTBOX_PlrName2.Text))do
			game.Workspace.CurrentCamera.CameraSubject = game.Players[v.Name].Character.Head
			y.Target = game.Players[v.Name].Character.HumanoidRootPart
			y:Fire()
			track:Play(.1, 1, 10)
			game:GetService('RunService').Stepped:connect(function()
				if Animateding then
					game.Players.LocalPlayer.Character.Head.CanCollide = false
					game.Players.LocalPlayer.Character.Torso.CanCollide = false
					game.Players.LocalPlayer.Character["Left Leg"].CanCollide = false
					game.Players.LocalPlayer.Character["Right Leg"].CanCollide = false
				end
			end)
		end
	else
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.HumanoidRootPart.Animated:Destroy()
		track:Stop()
		Animated.BackgroundColor3 = Color3.new(0.607843, 0.34902, 0.713726)
	end
end)

Attach.MouseButton1Click:connect(function()
	for i,v in pairs(GetPlayer(TXTBOX_PlrNameOTHER3.Text))do
		game.Players.LocalPlayer.Character.Humanoid.Name = 1
		local l = game.Players.LocalPlayer.Character["1"]:Clone()
		l.Parent = game.Players.LocalPlayer.Character
		l.Name = "Humanoid"
		wait(0.1)
		game.Players.LocalPlayer.Character["1"]:Destroy()
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.Animate.Disabled = true
		wait(0.1)
		game.Players.LocalPlayer.Character.Animate.Disabled = false
		game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
		for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
		game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
		end
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
	end
end)

superspinning = false
SuperSpin.MouseButton1Click:connect(function()
	superspinning = not superspinning
	if superspinning then
		SuperSpin.BackgroundColor3 = Color3.new(0.905882, 0.498039, 0.435294)
		for i,v in pairs(GetPlayer(TXTBOX_PlrNameOTHER3.Text))do
			game.Players.LocalPlayer.Character.Humanoid.Name = 1
			local l = game.Players.LocalPlayer.Character["1"]:Clone()
			l.Parent = game.Players.LocalPlayer.Character
			l.Name = "Humanoid"
			wait(0.1)
			game.Players.LocalPlayer.Character["1"]:Destroy()
			game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
			game.Players.LocalPlayer.Character.Animate.Disabled = true
			wait(0.1)
			game.Players.LocalPlayer.Character.Animate.Disabled = false
			game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
			for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
			game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
			end
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character["Left Arm"].CFrame
			wait(1)
			while wait() do
				if superspinning then
					game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
				end
			end
		end
	else
		SuperSpin.BackgroundColor3 = Color3.new(0.905882, 0.298039, 0.235294)
	end
end)

Kill.MouseButton1Click:connect(function()
	for i,v in pairs(GetPlayer(TXTBOX_PlrNameOTHER3.Text))do
		game.Players.LocalPlayer.Character.Humanoid.Name = 1
		local l = game.Players.LocalPlayer.Character["1"]:Clone()
		l.Parent = game.Players.LocalPlayer.Character
		l.Name = "Humanoid"
		wait(0.1)
		game.Players.LocalPlayer.Character["1"]:Destroy()
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.Animate.Disabled = true
		wait(0.1)
		game.Players.LocalPlayer.Character.Animate.Disabled = false
		game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
		for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
		game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
		end
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
		wait(0.2)
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
		wait(0.4)
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(Vector3.new(100000, 0, 100000))
	end
end)

SafeKill.MouseButton1Click:connect(function()
	local NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
	game.Players.LocalPlayer.Character.Humanoid.Name = 1
	local l = game.Players.LocalPlayer.Character["1"]:Clone()
	l.Parent = game.Players.LocalPlayer.Character
	l.Name = "Humanoid"
	wait(0.1)
	game.Players.LocalPlayer.Character["1"]:Destroy()
	game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
	game.Players.LocalPlayer.Character.Animate.Disabled = true
	wait(0.1)
	game.Players.LocalPlayer.Character.Animate.Disabled = false
	game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
	for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
	game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
	end
	local function tp(player,player2)
	local char1,char2=player.Character,player2.Character
	if char1 and char2 then
	char1:MoveTo(char2.Head.Position)
	end
	end
	for i,v in pairs(GetPlayer(TXTBOX_PlrNameOTHER3.Text))do
	wait(0.1)
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
	wait(0.2)
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
	wait(0.2)
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(Vector3.new(-100000,0,-100000))
	wait(0.7)
	tp(game.Players.LocalPlayer,game.Players[v.Name])
	wait(0.7)
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
	end
end)

Bring.MouseButton1Click:connect(function()
	local NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
	game.Players.LocalPlayer.Character.Humanoid.Name = 1
	local l = game.Players.LocalPlayer.Character["1"]:Clone()
	l.Parent = game.Players.LocalPlayer.Character
	l.Name = "Humanoid"
	wait(0.1)
	game.Players.LocalPlayer.Character["1"]:Destroy()
	game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
	game.Players.LocalPlayer.Character.Animate.Disabled = true
	wait(0.1)
	game.Players.LocalPlayer.Character.Animate.Disabled = false
	game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
	for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
	game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
	end
	
	local function tp(player,player2)
	local char1,char2=player.Character,player2.Character
	if char1 and char2 then
	char1.HumanoidRootPart.CFrame = char2.HumanoidRootPart.CFrame
	end
	end
	
	local function getout(player,player2)
	local char1,char2=player.Character,player2.Character
	if char1 and char2 then
	char1:MoveTo(char2.Head.Position)
	end
	end
	
	for i,v in pairs(GetPlayer(TXTBOX_PlrNameOTHER3.Text))do
	tp(game.Players[v.Name], game.Players.LocalPlayer)
	wait(0.2)
	tp(game.Players[v.Name], game.Players.LocalPlayer)
	wait(0.5)
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
	wait(0.5)
	getout(game.Players.LocalPlayer, game.Players[v.Name])
	wait(0.3)
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
	end
end)

FreeFall.MouseButton1Click:connect(function()
		local NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
		game.Players.LocalPlayer.Character.Humanoid.Name = 1
		local l = game.Players.LocalPlayer.Character["1"]:Clone()
		l.Parent = game.Players.LocalPlayer.Character
		l.Name = "Humanoid"
		wait(0.1)
		game.Players.LocalPlayer.Character["1"]:Destroy()
		game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
		game.Players.LocalPlayer.Character.Animate.Disabled = true
		wait(0.1)
		game.Players.LocalPlayer.Character.Animate.Disabled = false
		game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
		for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
		game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
		end
		for i,v in pairs(GetPlayer(TXTBOX_PlrNameOTHER3.Text))do
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
		wait(0.2)
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
		wait(0.6)
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
		wait(0.6)
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(0,50000,0)
	end
end)

while wait() do
	if SpammingChar then
		game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer(TXTBOX_Chat.Text, "All")
		Spam_2.BackgroundColor3 = Color3.new(0.280392, 0.9, 0.543137)
		wait(0.5)
	else
		Spam_2.BackgroundColor3 = Color3.new(0.180392, 0.8, 0.443137)
	end
	if annoying then
		for i,v in pairs(GetPlayer(TXTBOX_PlrName.Text))do
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			Annoy.BackgroundColor3 = Color3.new(0.403922, 0.796078, 0.858824)
		end
	else
		Annoy.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
	end
	if Carpett then
		for i,v in pairs(GetPlayer(TXTBOX_PlrName.Text))do
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame
			Carpet.BackgroundColor3 = Color3.new(0.403922, 0.796078, 0.858824)
		end
	else
		Carpet.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
	end
	if following then
		for i,v in pairs(GetPlayer(TXTBOX_PlrName.Text))do
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.HumanoidRootPart.CFrame + Vector3.new(5,0,0)
			Follow.BackgroundColor3 = Color3.new(0.403922, 0.796078, 0.858824)
		end
	else
		Follow.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
	end
	if headwalking then
		for i,v in pairs(GetPlayer(TXTBOX_PlrName.Text))do
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Players[v.Name].Character.Head.CFrame
			HeadWalk.BackgroundColor3 = Color3.new(0.403922, 0.796078, 0.858824)
		end
	else
		HeadWalk.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
	end
	if Spammer then
		for i,v in pairs(GetPlayer(TXTBOX_PlrName.Text))do
			game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("/w "..v.Name.." @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@", "All")
			Spam.BackgroundColor3 = Color3.new(0.403922, 0.796078, 0.858824)
			wait(0.5)
		end
	else
		Spam.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
	end
	if watching then
		for i,v in pairs(GetPlayer(TXTBOX_PlrName.Text))do
			CreepyWatch.BackgroundColor3 = Color3.new(0.352941, 0.882353, 0.576471)
			game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(game.Players.LocalPlayer.Character.Torso.Position, game.Players[v.Name].Character.Torso.Position)
		end
	else
		CreepyWatch.BackgroundColor3 = Color3.new(0.152941, 0.682353, 0.376471)
	end
end