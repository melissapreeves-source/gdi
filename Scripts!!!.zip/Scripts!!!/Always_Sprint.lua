game.Players.LocalPlayer.PlayerGui.HitEqualsYouDie.WalkspeedEdit:Remove()
game.Players.LocalPlayer.PlayerGui.HitEqualsYouDie.JumpLimiter:Remove()
game.Workspace["Abdulwahabksa"].Humanoid.WalkSpeed.Value = 25