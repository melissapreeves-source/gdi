local car = game.Workspace.Vehicles["Humvee"]

car.Stats.MaxSpeed.Offroad.Value = 200
car.Stats.MaxSpeed.Value = 200