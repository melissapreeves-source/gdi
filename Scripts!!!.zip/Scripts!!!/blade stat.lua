getglobal game
getfield -1 Workspace
getfield -1 ServerEvents
getfield -1 SetStat
getfield -1 FireServer
pushvalue -2
pushstring BladeLevel
pushnumber LEVEL HERE
pcall 3 1 0